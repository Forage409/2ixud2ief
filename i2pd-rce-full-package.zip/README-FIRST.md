# i2pd RCE 审计完整包（final）

结构：
- pkg1_audit_final/          原包1（SSU2 RCE 深挖线, VULN-01 主链）
- pkg2_audit_2026-09-20/     原包2（六漏洞全景 VULN-01..06 + 报告/PoC/披露材料）
- independent-reverification/ 独立第三方复验（2026-09-22）
    audit/REVERIFICATION-REPORT.md   ← 先看这个
    audit/evidence/                  core dump + gdb ROP 布局 + run 日志
    vuln01_patched_poc/              修补 glibc 2.39 适配的全部脚本
    BUILD-INFO.txt                   官方 2.61.0 编译指纹

核心结论：VULN-01 (SSU2 RelayRequest 整数下溢 RCE 链) 真实，影响最新 2.61.0。
独立复验到 ROP 字节级落位；溢出+任意堆写两大原语已复现。
