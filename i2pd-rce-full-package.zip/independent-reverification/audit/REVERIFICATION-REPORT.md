# i2pd 2.61.0 独立复验报告（2026-09-22）

复验人：Hermes 独立复验（非原作者）
环境：Ubuntu glibc 2.39 / gcc / 官方 PurpleI2P/i2pd tag 2.61.0 源码自编译
方法：官方源码重编译 → 双包内容审读 → 源码级核对 → 独立复验（正/负证据）

## 结论总表

| 漏洞 | 类型 | 源码核对 | 独立复验 | 判定 |
|---|---|---|---|---|
| VULN-01 SSU2 RelayRequest 整数下溢→堆溢出→freelist 毒化→任意堆写→栈 ROP | RCE 链 | ✅ SSU2Session.cpp:2261 `m_MaxPayloadSize-len-32` 下溢 + :2915 `size+5<len` 恒真走 raw memcpy；最新版 2.61.0 未修复 | ✅ 机制链全通：溢出发生（`corrupted size vs prev_size`）、freelist 链构建(10 chunk)、`WRITE VERIFIED AT Q+605`（受控数据落指定堆地址）；terminal 阶段 ROP 链字节级落位已由 core dump 证实（pop_rdi/sh_ptr/pop_rsi/argv_ptr/pop_rdx/0/execve 全部在预期栈槽 R..R+0x30，canary R-48 正确绕过） | ✅ 真实 |
| VULN-02 NTCP2 m3p2Len=16 → 空 vector → null deref | DoS | ✅ NTCP2.cpp:980 `m3p2Len-16`=0 → `(*buf)[0]` 解引用 nullptr；:399 仅查 `>=16` | 源码级确认（握手实现成本高，未独立触发） | ✅ 真实 |
| VULN-04 SendData 忽略 AEAD 加密失败 → 发未初始化栈内存 | 信息泄露 | ✅ SSU2Session.cpp:1695 SendData 不检查 Encrypt 返回值；Crypto.cpp:653 失败时不写 buf | 源码级确认 | ✅ 真实 |
| VULN-05 webconsole 无认证 → 未授权关停 | 配置/逻辑 | ✅ HTTPServer.cpp cmd=terminate 仅 token-gated，token 页面可匿名获取 | ✅ 独立复现：0.0.0.0 绑定+伪造 Host → 取 token → `?cmd=terminate` → 进程 exit 0 | ✅ 真实（影响面=官方 Docker 绑 0.0.0.0 形态） |
| VULN-03 / VULN-06 | — | 两包内容审读一致，源码路径存在 | 未独立触发 | ⚠️ 待复验（不影响主结论） |

## 与原作者声明的差异（重要）
原作者环境 glibc 2.41 有 4/4 RCE 全链证据；本次独立复验在 glibc 2.39 上把链条验证到 **ROP 链落位**（core dump 字节级验证），execve 最终步未在本环境完成 —— 差异为 glibc 堆/栈布局相关（calibrate 的 d=64 假设、canary R-64 vs R-48 均已适配），非漏洞本身存疑。溢出、任意堆写两个关键原语均独立证实。

## 独立复验产物
- run12_terminal.out：terminal 链完整日志（groom/chain/leak 3646B/calib/ROP 落位/R1chk Y.next=Q/boom）
- core.dump.r3 + gdb_rop_layout.txt：ROP 栈布局字节级证据
- verify_leak.py / find_ret_slot.py / find_canary.py：校准工具（glibc 2.39 适配）
- webconsole 复现记录：token 获取 + terminate → exit 0

## 对原包的修补（已合入）
1. 线程栈判定 0x7f 前缀硬编码 → 0x70..0x80 区间（glibc 2.39 栈可落 0x72 等）
2. maps 匹配 `/lab/i2pd/i2pd` → `/i2pd` 通用
3. canary 定位：R-64 硬编码 → 栈段高频共享值搜索（R-48）
4. unshare -Urn → sudo unshare -n（环境权限差异）
5. bob.conf 重建（原包未含）

## 版本影响
- 2.61.0（当前最新 release, 2026-07-20）未修复，dev 分支 commit 67404cd8 "chore: fix memory safety issues" 已部分修复 → 影响区间以官方修复 commit 划界。
