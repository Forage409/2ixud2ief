#!/bin/bash
# Lab environment common: netns setup, Bob launch/wait — sourced or exec'd inside `unshare -Urn`.
# FOR MAINTAINER REPRODUCTION ONLY — targets are loopback lab addresses (45.45.45.1/.2).
set -u
LAB=/home/agentuser/i2pd-lab/lab
BOB_BIN="${BOB_BIN:-$LAB/i2pd/i2pd}"
BOB_DATA="$LAB/bob-data"

netns_up() {
  ip link set lo up
  ip addr add 45.45.45.1/24 dev lo 2>/dev/null || true
  ip addr add 45.45.45.2/24 dev lo 2>/dev/null || true
  ip link set lo mtu 1500 2>/dev/null || true
  ip route add local 45.45.45.0/24 dev lo 2>/dev/null || true
  echo "[lab] netns ready: $(ip -4 addr show lo | grep inet | tr -s ' ' | cut -d' ' -f3 | tr '\n' ' ')"
}

bob_start() {
  rm -rf "$BOB_DATA"; mkdir -p "$BOB_DATA"
  "$BOB_BIN" --conf="$LAB/bob.conf" --datadir="$BOB_DATA" &
  BOB_PID=$!
  echo "[lab] bob pid=$BOB_PID binary=$BOB_BIN"
  # wait for SSU2 up + router.info written
  for i in $(seq 1 100); do
    if [ -f "$BOB_DATA/router.info" ] && grep -q "SSU2: Start listening on" "$BOB_DATA/i2pd.log" 2>/dev/null; then
      echo "[lab] bob ready after ${i}x0.2s"; return 0
    fi
    sleep 0.2
  done
  echo "[lab] bob NOT ready in 20s"; tail -20 "$BOB_DATA/i2pd.log" 2>/dev/null; return 1
}

bob_stop() {
  [ -n "${BOB_PID:-}" ] && kill "$BOB_PID" 2>/dev/null
  wait "${BOB_PID:-0}" 2>/dev/null
}
