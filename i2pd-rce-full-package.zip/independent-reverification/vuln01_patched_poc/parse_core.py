#!/usr/bin/env python3
"""parse_core.py — extract crashing-thread registers + stack from ELF core."""
import sys, struct

CORE = "/home/agentuser/i2pd-lab/lab/core"
data = open(CORE, "rb").read()

# parse ELF64 program headers (PT_NOTE) + PT_LOAD segments
e_phoff, e_phentsize, e_phnum = struct.unpack_from("<Q", data, 0x20)[0], \
    struct.unpack_from("<H", data, 0x36)[0], struct.unpack_from("<H", data, 0x38)[0]

loads = []   # (vaddr, filesz, offset)
notes = []   # (offset, size)
for i in range(e_phnum):
    off = e_phoff + i * e_phentsize
    p_type, p_flags = struct.unpack_from("<II", data, off)
    p_offset, p_vaddr, _, p_filesz = struct.unpack_from("<QQQQ", data, off + 8)[:4]
    if p_type == 1: loads.append((p_vaddr, p_filesz, p_offset))
    elif p_type == 4: notes.append((p_offset, p_filesz))

# walk notes: find NT_PRSTATUS entries with pid; siginfo shows si_addr
# prstatus: pid @ 32 (int), regs: r15..gs at 112.. (26*8), rsp @ ..., rip @ ...
threads = []
for noff, nsz in notes:
    p = noff
    end = noff + nsz
    while p < end:
        namesz, descsz, ntype = struct.unpack_from("<III", data, p)
        name = data[p+12:p+12+namesz].rstrip(b"\0")
        desc = p + 12 + ((namesz + 3) & ~3)
        if ntype == 1 and name == b"CORE":
            # elf_prstatus (x86_64): struct elf_siginfo(16) + short pr_cursig@16
            # pid @ 32, ppid 36, pgrp 40, sid 44; regs start @ 112
            pid = struct.unpack_from("<i", data, desc + 32)[0]
            sig = struct.unpack_from("<H", data, desc + 12)[0]
            r = {}
            names = ["r15","r14","r13","r12","rbp","rbx","r11","r10","r9","r8",
                     "rax","rcx","rdx","rsi","rdi","orig_rax","rip","cs",
                     "eflags","rsp","ss","fs_base","gs_base","ds","es","fs","gs"]
            for k, nm in enumerate(names):
                r[nm] = struct.unpack_from("<Q", data, desc + 112 + k*8)[0]
            threads.append((pid, sig, r))
        p = desc + ((descsz + 3) & ~3)

print("threads in core: %d" % len(threads))
for pid, sig, r in threads:
    print("pid=%d sig=%d rip=%#x rsp=%#x" % (pid, sig, r["rip"], r["rsp"]))

def memread(addr, n):
    for v, fsz, off in loads:
        if v <= addr < v + fsz:
            d = addr - v
            if d + n <= fsz:
                return data[off+d:off+d+n]
    return None

# find the crashing thread: sig == 11 or 7 (SIGSEGV/SIGBUS)
for pid, sig, r in threads:
    if sig in (7, 11, 4):
        print("\n=== CRASH THREAD pid=%d sig=%d ===" % (pid, sig))
        for k in ["rip","rsp","rbp","rax","rbx","rcx","rdx","rsi","rdi",
                  "r8","r9","r10","r11","r12","r13","r14","r15"]:
            print("  %-5s = %#018x" % (k, r[k]))
        rsp = r["rsp"]
        st = memread(rsp - 128, 512)
        if st:
            print("  stack around rsp:")
            for i in range(0, 512, 8):
                a = rsp - 128 + i
                v = struct.unpack("<Q", st[i:i+8])[0]
                mark = " <-- rsp" if a == rsp else ""
                print("    %#x: %#018x%s" % (a, v, mark))
        # instructions at rip
        rip = r["rip"]
        code = memread(rip - 32, 96)
        if code:
            print("  code at rip-32:")
            print("   ", code.hex())
