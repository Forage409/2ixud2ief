#!/bin/bash
# run_in_lab.sh — run one experiment inside the unshare -Urn lab namespace.
# Usage: run_in_lab.sh <script.py> [args...]
# stdout+stderr tee'd to /home/agentuser/i2pd-lab/lab/ev/last_run.out; Bob log copied out.
set -u
LAB=/home/agentuser/i2pd-lab/lab
SCRIPT="$1"; shift || true
OUT="${OUT:-/home/agentuser/i2pd-lab/lab/ev/last_run.out}"

sudo unshare -n bash -c 'ulimit -c unlimited; 
  set -u
  LAB="'"$LAB"'"
  SCRIPT="'"$SCRIPT"'"
  ARGS="'"$*"'"
  . /home/agentuser/i2pd-lab/lab/scripts/lab_common.sh
  netns_up || exit 1
  bob_start || exit 1
  python3 "$SCRIPT" $ARGS
  RC=$?
  cp "$LAB/bob-data/i2pd.log" "$LAB/ev/bob_last.log" 2>/dev/null
  bob_stop
  exit $RC
' 2>&1 | tee "$OUT"
echo "[runner] done, output in $OUT, bob log in $LAB/ev/bob_last.log"
