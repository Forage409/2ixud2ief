i2pd SSU2 SECURITY AUDIT — FINAL PACKAGE
=========================================
Independent security audit of PurpleI2P/i2pd 2.43.0-2.61.0 (SSU2 transport).
Coordinated-disclosure evidence bundle. Everything herein targets ONLY the
loopback laboratory addresses 45.45.45.1 / 45.45.45.2 inside an `unshare -Urn`
sandbox on the auditor's own machine; no scanning, targeting or weaponization
capability against public hosts exists anywhere in this package.

HEADLINE RESULT
---------------
Two independent unauthenticated-UDP-to-root RCE reproductions on the hardened
glibc build (PIE + full RELRO + canaries + NX + FORTIFY), 0.3 s from final
trigger packet to forensic evidence (`uid=0(root)`). Musl build: carried to
the poison primitive; terminal stack write blocked (environmental + structural
blockers documented honestly — no RCE claimed). Every release 2.43.0-2.61.0
affected; dev fixed at 67404cd8 (2026-08-18), unreleased at audit time.

PACKAGE STRUCTURE
-----------------
report/            English report (report.md + report.pdf): executive summary,
                   VULN-01..06 (trigger conditions, root cause, affected
                   functions, severity), full exploit-engineering chapter,
                   impact matrix, fixes, disclosure plan.
poc/               Per-vulnerability reproduction. All scripts self-contained.
  vuln01/          Protocol library (ssu2lib.py) + smoke1/smoke2 (handshake,
                   leak) + atk_chain_v1.py (groom->poison->pop->write rig,
                   heap-scratch) + atk_p6_terminal.py (TERMINAL chain, glibc,
                   --run N for independent runs) + atk_p7_musl.py (musl port to
                   the last verified step; blockers documented) + lab_common.sh
                   + run_in_lab.sh (sandbox runner) + parse_core.py.
  vuln02_03/       Static pattern-proof verifier (same underflow at the two
                   HandlePeerTest sinks). Exploitation NOT performed — stated.
  vuln04/06/       READMEs pointing at the reproducing scripts above.
chain/             run_full_chain.sh — one command, zero to root RCE.
evidence/          Both RCE forensic bundles (marker files with id/whoami,
                   full stdout timelines, target logs, leaks, calibration
                   records), leak corpus, heap-geometry probes, crash-analysis
                   notes, and the complete audit worklog.
disclosure/        letter.md (cover letter to maintainers) + advisories.md
                   (per-CVE drafts; VULN-01 primary fully written).
summary-zh.md      Plain-Chinese walkthrough of the entire chain.

BUILD COMMANDS (large artifacts are intentionally NOT shipped)
--------------------------------------------------------------
Hardened glibc target (from the 2.61.0 release tarball):
  cd i2pd && make -j2 USE_UPNP=no DEBUG=0 \
     LDFLAGS="-pie -Wl,-z,relro,-z,now" \
     CXXFLAGS="-O2 -g -fPIE -fstack-protector-strong -D_FORTIFY_SOURCE=2"
  # verify: readelf -d i2pd | grep -E "BIND_NOW|FLAGS_1"; check canary via
  # nm(1) __stack_chk_fail presence. (Audit build: ~150 MB with symbols.)

Musl target: extract from the official Docker image (registry API), e.g.
  docker pull purplei2p/i2pd:release-2.61.0 && docker create ... && docker cp
  # requires a musl userland to execute (see atk_p7_musl.py blockers)

Laboratory bring-up (needs unshare, rootless):
  python3 poc/vuln01/ssu2lib.py --make-seed lab/seed.zip   # offline reseed
  bash chain/run_full_chain.sh 1                            # full chain, run 1

Per-script usage: python3 <script> (each header documents flags; the runner
`run_in_lab.sh <script.py> [args]` handles the namespace + target lifecycle
and tees output to lab/ev/last_run.out).

HONESTY NOTES (zero-false-positive discipline)
----------------------------------------------
- The two glibc root RCE runs are independent instances (fresh process/ASLR/
  heap), evidence archived under evidence/rce_run1/ and rce_run2/.
- VULN-02/03 are source-audit findings (pattern-identical sinks); not
  exploited end-to-end.
- The musl chain is NOT claimed as RCE: blockers are documented in
  atk_p7_musl.py and report Section 4.7.
- /proc/<pid>/mem and /proc/<pid>/maps are used only as maintainer-side
  calibration instruments; all runtime exploit inputs derive from the network
  leak (see report Section 2.2).
