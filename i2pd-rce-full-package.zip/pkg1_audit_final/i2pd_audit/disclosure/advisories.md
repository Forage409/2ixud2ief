# Draft Advisory — VULN-01 (primary)

**Title:** Unauthenticated UDP heap overflow in i2pd SSU2 `HandleRelayRequest`
leading to remote code execution as the service user

**Affected:** PurpleI2P/i2pd 2.43.0 – 2.61.0 (all releases); fixed in dev at
commit 67404cd8 (2026-08-18), no fixed release at advisory time

**CVE:** requested (placeholder VULN-01)

**CVSS 3.1 (preliminary):** 9.8 — AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H

## Summary

`SSU2Session::HandleRelayRequest` (libi2pd/SSU2Session.cpp:2261 in 2.61.0)
subtracts the attacker-controlled RelayRequest block length from the session's
maximum payload size without validation:

```cpp
packet->payloadSize = r ?
    CreateRouterInfoBlock (packet->payload, m_MaxPayloadSize - len - 32, r) : 0;
```

A RelayRequest block with `len > m_MaxPayloadSize - 32` (1408 bytes at
MTU 1500) underflows the size_t. `CreateRouterInfoBlock`'s guard
(`size + 5 < len`) then passes trivially and the **full uncompressed
RouterInfo** — previously stored by the attacker via the data-phase RI update
path — is memcpy'd into a 1500-byte `MemoryPool<SSU2SentPacket>` buffer,
overflowing it by an attacker-chosen length (up to ~3.5 KB demonstrated).

The same unsigned-subtraction pattern exists at two adjacent sinks:
`HandlePeerTest` message 1 (SSU2Session.cpp:2503) and message 3 (:2622).

## Attack preconditions

The attacker opens two ordinary SSU2 sessions with the target and obtains a
relay tag through a RelayTagRequest on the second. This requires the target
to accept tunnels and publish an SSU2 introducer address — default router
behavior. No authentication, floodfill status, or prior relationship is
required.

## Impact

Demonstrated end-to-end in an isolated laboratory on a hardened build
(PIE + full RELRO + canaries + NX + FORTIFY): a stack disclosure of ~3–4.3 KB
(`SendData` transmits uninitialized stack when the AEAD helper fails) defeats
ASLR and reveals the canary; overflow into a freed pool chunk poisons the
`MemoryPool` freelist; the next allocations return an attacker-chosen stack
address, and the RouterInfo memcpy becomes an arbitrary write that lands a
ret-sled + `execve("/bin/sh", ["-c", cmd])` chain on the return path. Two
independent runs produced `uid=0(root)` command execution 0.3 s after the
final trigger packet.

## Fix

In each affected handler, validate the block length before computing
remaining capacity (reject `len > m_MaxPayloadSize - 32`), and make
`CreateRouterInfoBlock` refuse the raw-copy branch when the RouterInfo does
not fit, falling back to gzip or fragmentation as capacity genuinely allows.
Recommended hardening companions: check the AEAD return value in `SendData`
(currently a separate information-disclosure issue, VULN-04), freelist
provenance validation in `MemoryPool`, and a stored-RouterInfo size ceiling.

## References

- Full audit report and reproduction rig: attached package (lab-only targets)
- Dev fix commit: 67404cd8 (2026-08-18)

---

# Draft Advisory — VULN-04 (secondary)

**Title:** i2pd SSU2 `SendData` transmits uninitialized stack memory when
payload encryption fails

**Affected:** PurpleI2P/i2pd 2.43.0 – 2.61.0 (release line; present in dev at
audit time unless already changed alongside 67404cd8)

**CVE:** requested (placeholder VULN-04)

## Summary

`SSU2Session::SendData` (libi2pd/SSU2Session.cpp:1695-1718) ignores the
boolean return of `AEADChaCha20Poly1305Encrypt`. When the payload length
exceeds the 1500-byte stack buffer (as happens with the VULN-01 overflow, or
any path that produces an oversized payload), the helper returns false
without touching the output buffer, and `SendData` transmits
`payload[len + 16]` regardless — emitting the uninitialized contents of its
own stack frame and everything above it (caller locals, saved registers,
return addresses, stack canary) to the packet's destination.

In the audit's reproduction this yields 4292–4295 bytes per trigger
(containing 26 PIE, 14 libc, 10 heap pointers plus thread-stack pointers with
a 2816-byte RouterInfo; 3.6 KB with the terminal 2170-byte RouterInfo),
sufficient to recover the PIE base, the stack canary and return-slot contents
without any other primitive.

## Impact

Remote information disclosure defeating ASLR/PIE and revealing stack canary
values. Standalone severity High; Critical when chained with VULN-01 (the
disclosure and the overflow are triggered by the same oversized-relay
mechanism).

## Fix

Check the AEAD helper's return value; on failure, drop the packet, log a
warning, and terminate the session rather than transmitting uninitialized
memory.

---

# Draft Advisory — VULN-02 / VULN-03 (merged variant, maintainer's choice)

**Title:** Same unsigned-underflow pattern at `HandlePeerTest` (msg 1 and msg 3)

**Affected:** PurpleI2P/i2pd 2.43.0 – 2.61.0

**Summary:** `SSU2Session::HandlePeerTest` computes remaining capacity with
the same `m_MaxPayloadSize - len - 32` unsigned subtraction at the msg-1
(SSU2Session.cpp:2503) and msg-3 (:2622) sinks. An oversized PeerTest block
underflows the subtraction and reaches the same unbounded RouterInfo copy as
VULN-01. These variants require the respective PeerTest role preconditions
and were identified in source audit; end-to-end reproduction was performed
only for the strictly more accessible relay path (VULN-01). The fix is
identical (length validation before the subtraction); upstream may reasonably
merge this with the VULN-01 advisory.

---

# Draft Advisory — VULN-05 / VULN-06 (hardening companions to VULN-01)

**VULN-05:** `libi2pd/util.h` `MemoryPool<T>` (used for `SSU2SentPacket`)
performs no validation of freelist pointers: `Release` stores the link in the
freed block's first bytes and `Acquire` returns `m_Head` unchecked. Any
overflow reaching a free block's link therefore controls subsequent
allocation addresses — the arbitrary-write amplifier used in the VULN-01
chain. Fix: provenance validation (side bitmap / generation counter), or at
minimum link-field poisoning in debug builds.

**VULN-06:** the data-phase RouterInfo update path (`HandleRouterInfo`,
SSU2Session.cpp:1965-1996) imposes no effective ceiling on stored RI size,
and `PopulateRouterInfoBuffer` later serves the stored bytes to the VULN-01
sink — giving the attacker full control of overflow length and content.
Fix: enforce a protocol-consistent maximum stored RI size.

Both are recommended to be folded into the primary advisory as amplification
factors rather than tracked separately.
