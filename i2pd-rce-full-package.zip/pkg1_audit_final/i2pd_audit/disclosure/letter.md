# Draft Disclosure Letter to PurpleI2P Maintainers

**From:** independent security auditor
**To:** PurpleI2P/i2pd maintainers (GitHub Security Advisory channel)
**Subject:** Critical: unauthenticated SSU2 heap overflow → root RCE in i2pd 2.43.0–2.61.0

Dear maintainers,

I completed an independent security audit of i2pd's SSU2 transport and found a
critical, remotely exploitable vulnerability chain that I have reproduced end-
to-end in an isolated laboratory: a single unauthenticated UDP packet leads to
arbitrary command execution as the i2pd process user, demonstrated twice as
root against a build with PIE, full RELRO, stack canaries, NX and FORTIFY
enabled.

**Primary finding (VULN-01).** `SSU2Session::HandleRelayRequest`
(libi2pd/SSU2Session.cpp:2261 in 2.61.0) computes the remaining buffer size as
`m_MaxPayloadSize - len - 32` where `len` is the attacker-controlled
RelayRequest block length. Any block larger than `m_MaxPayloadSize - 32`
(1408 bytes at MTU 1500) underflows the size_t, and `CreateRouterInfoBlock`
then memcpy's the full uncompressed RouterInfo — previously delivered by the
attacker through the ordinary RI-update path — into a 1500-byte
MemoryPool buffer. Two additional sinks share the same pattern
(`HandlePeerTest` msg1 :2503, msg3 :2622).

**Amplifiers that make this critical.** (a) `SendData` ignores the AEAD
helper's return value and transmits uninitialized stack memory when
payloadSize exceeds the buffer, disclosing ~3–4.3 KB of stack (return
addresses, canary, heap pointers) to the attacker — this defeats ASLR in the
same packet. (b) The overflowed buffer belongs to `MemoryPool<SSU2SentPacket>`
whose freelist does no pointer validation, so the overflow can poison the
freelist into returning an arbitrary address (the stack), turning a bounded
overflow into a write-what-where. (c) The RI acceptance path imposes no
effective size ceiling on stored RouterInfos, letting the attacker control
both overflow length and byte content.

**Affected versions.** Every release from 2.43.0 through 2.61.0. The dev
branch fixed the underflow on 2026-08-18 (commit 67404cd8) but no fixed
release has shipped; Docker `latest` (dev) is fixed, all release-tag images
are vulnerable.

**Evidence.** The attached package contains a full English report, a
self-contained reproduction rig (Python protocol library + exploit scripts)
that runs only against loopback laboratory addresses, forensic bundles from
two independent root-RCE runs (`uid=0(root)` output, marker files, complete
packet timelines), and draft advisories. Every script's header declares it is
for maintainer reproduction only; nothing targets public hosts.

**Suggested remediation.** Validate block length before the subtraction in
all three handlers; refuse the raw-copy branch in `CreateRouterInfoBlock`
when the RouterInfo does not fit remaining capacity; check the AEAD return in
`SendData` and drop the packet on failure; consider freelist provenance
validation in `MemoryPool` and a stored-RI size ceiling.

**Disclosure timeline proposal.** I will keep all details embargoed for 90
days from your acknowledgment, publish earlier if you ship a fixed release
sooner, or extend by mutual agreement. I am happy to coordinate on CVE
assignment (I suggest one advisory for the underflow family, one for the
`SendData` disclosure), to re-test candidate patches with the included rig,
and to credit any co-discoverers you are aware of.

Thank you for maintaining i2pd — I am at your disposal for any reproduction
support.

Respectfully,
[independent security auditor]
