# i2pd 公益安全审计 Round 2 — 台账（第 4 次环境，从零重建）

## 会话纪律（每 agent 必读）
- 零误报：报告只写本轮跑出来的 + 如实标注来源的历史实证。
- 分档如实定级；musl 档未打通就写"阻断"，不写成完成。
- 每个里程碑写本台账；长操作单次调用原子完成；每写文件后回读验证。
- 打包：单次调用内原子完成 + 同调用回读验证（清单/大小/SHA256）。

## 事实冲突裁定（2026-09-21，本轮开局）
- 上轮会话曾报告 round 33/39 两次 root RCE + atk_p6_terminal.py 成品；本轮现存记录显示断点在终局链组装完成之前（P2/P3 原语各自实测落地，终局时序未跑通）。
- 磁盘已三次清零，两说法均无法验证 → 一律按零证据处理。本轮全部重新跑，跑出来的才算数。

## 环境审计（2026-09-21）
- Debian 13 trixie，内核 5.10.134，用户 z(uid 1001)，2 CPU，3.9G RAM，9.3G 可用磁盘
- 工具：g++ 14.2 / make 4.4 / git 2.47 / curl 8.14 / unshare 2.41 / openssl 3.5.7 / binutils 2.44 / zip / python3.12 + cryptography 44.0.3 + pycryptodome
- 缺：cmake（用 Makefile 路线）、gdb（用 objdump/nm/readelf + /proc/pid/maps 替代）
- 网络：github 200 / raw.githubusercontent 301 / auth.docker.io 200 / registry-1.docker.io 401(正常)
- 残留：无（worklog.md、scripts、/usr/local/bin/i2pd、lab 均不存在；download/ 仅占位 README）

## 银行事实（快照图纸，直接引用不重新推导；均来自前几轮实测，标注为历史实证）
### VULN-01 本体
- 位置：SSU2Session.cpp:2261（2.61.0），`m_MaxPayloadSize-len-32` size_t 下溢
- 后果：攻击者 RouterInfo 全量 memcpy 进 MemoryPool<SSU2SentPacket> 的 payload[1500]
- 结构布局：payload@0(1500) + pad4 + payloadSize@1504(8) + sendTime@1512(8) + numResends@1520(4) → 整结构 1528
- 影响：2.43.0–2.61.0 全部 release；dev 分支 67404cd8（2026-08-18）已修未发版；Docker latest 是 dev 构建须用 release tag
### P2 泄露原语（历史实证）
- SendData 忽略 AEAD false 返回 → payload+16+len 明文发出
- 4292 字节泄露：26 PIE 指针（含 bin+0x326d53 = HandleRelayRequest 返回地址）、14 libc、10 堆指针
- 栈指针会被 groom 覆盖 → 泄露必须前置
### P3 任意写原语（历史实证）
- 双 Ack 定向释放 + 溢出投毒 MemoryPool freelist next 指向 Q
- Q3MARK 精确落点 Q+612（= RI 块头 5 字节 + RI 内偏移 607，sig_pad 区）
- 写入映射：落点 = Q + 5 + RI 内偏移；要写目标 T 则 RI 内偏移 = T − Q − 5
### 终局链时序（设计，待本轮复跑实证）
泄露 → 切小 RI → groom → 双 Ack 定向释放 → 读 zone → R1 投毒(numResends=3) → R2 弹出 → R3 写 Q → ROP 起爆；Q 对准栈上保存返回地址槽；ROP 链放 identity 224 字节 padding + sig_padding
### glibc 档 ROP 材料（历史校准，本轮复核）
- pop rdi;ret @ PIE+0x7ee54；system @ libc+0x53090（glibc 2.41）
- hardened 构建：PIE + Full RELRO + Canary + FORTIFY，带符号
### musl 档
- registry API 提取（purplei2p/i2pd, release-2.61.0），PIE+Full RELRO+Canary+stripped，/usr/local/bin/i2pd
- 前轮状态：链逐步单独实测通过，最终返回触发被 musl 紧凑栈布局阻断；报告 4.1 给双绕过路线（短载荷 1.6KB / 两段写）——本轮继续推或如实写阻断
### 实验室拓扑（图纸）
- unshare -Urn 单 netns：lo 起，45.45.45.1=靶机 i2pd，45.45.45.2=evil peer 攻击脚本
- 关客户端服务（端口占用）但不加 --notransit
### 13 条防复发坑清单（内化进重建脚本）
1. 大 RI 必须 RouterInfo 块 gzip 投递，identity padding 与握手 RI 一致
2. netId 大小写坑
3. Python bytearray 切片赋值会收缩——必须显式补齐长度
4. numResends 禁用 0x7fffffff，用小值 3
5. phase-2 RI 投递必须在读 zone 之前
6. Q 必须块起始对齐
7. 交错区外科手术 = 内容判型 + 纯复刻仅改 F.fd=Q
8. zone 必须在最终 ack 后读
9. 关客户端服务但不加 --notransit
10. RI 长度 ±1 波动 → 偏移鲁棒扫描
11. 540ms RTO → 150ms 学习窗内抢完全部动作
12. groom 会话 15 秒超时 → 范围 ack 保活 + 二次 groom
13. 冷启动学习窗太短 → 等 RelayIntro 响应到位再开窗

## 交付物蓝图（用户指令，逐字执行）
- 包名：i2pd_audit_final.zip；单次调用原子打包 + 同调用回读验证
- 结构：README.txt / report/(英文 PDF+MD) / poc/(VULN-01..06 独立目录，.py 必备，复杂加 .c；VULN-01 含 atk_p6_terminal.py glibc 全链 + atk_p7_musl.py musl 到实测点；全部脚本仅以本地实验室为靶 + 文件头声明仅用于维护者复验) / chain/(一键总链+运行说明) / evidence/(取证三件套、ASan、泄露包解析、Q3MARK、maps、崩溃 dump、台账) / disclosure/(英文披露信+按 CVE 拆分 advisory，VULN-01 主条目成文，90 天窗口+GitHub Security Advisory 流程) / summary-zh.md
- 构建产物大文件不进包，构建命令文字进 README；补丁不写，修复方向进报告

## 进度
- [x] T1 事实冲突裁定（见上）
- [x] T2 环境审计 + 台账初始化
- [x] T3 源码获取 + 漏洞本体核验（2.61.0 @ 635b013，机制全图见上）
- [x] T4 hardened glibc 档构建（PIE/FullRELRO/NX/Canary/FORTIFY/带符号 ✓）
- [x] T5 musl 二进制提取（registry API，9.58MB，PIE+FullRELRO+stripped ✓）
- [x] T6 netns 实验室（unshare -Urn，lo 双 IP，seed.zip 离线 reseed，Bob 0.4s 就绪）
- [~] T7 协议库重建 —— **核心全通**：双会话握手(Alice+Charlie)、RelayTagRequest→tag 获取、数据期双向加解密、**大 RI 投递→RelayRequest 下溢→溢出→P2 泄露 4295B/76 指针**（/home/z/my-project/lab/ev/）
- [ ] T8 glibc 档终局链复跑 ×2（待做：groom/双Ack/R1-R3/ROP）
- [ ] T9 musl 档推进
- [ ] T10 报告 MD+PDF
- [ ] T11 披露信+advisory
- [ ] T12 summary-zh
- [ ] T13 原子打包+验证

## T7 协议库调通记录（字节级互操作坑全集——写进报告"复现注记"）
1. **cert type = 5**（CERTIFICATE_TYPE_KEY，Identity.h:52）——不是 6；错则 DSA 验证器→验签失败→解析中止
2. **transport 字符串 "SSU2" 大写**（WriteString("SSU2") RouterInfo.cpp:1352）；小写被判 eTransportUnknown
3. **transport/mapping 字符串是长度前缀**（ExtractString 首字节=长度），不是 z-string
4. **RI base64 用 I2P 字母表**（-~ 而非 +/）；写 s/i 必须转换；X25519 静态公钥需重生成至 s[31]&0x80==0
5. **顶层属性键名 "router.version"**（不是 "version"）；netId 必须 "netId"（精确）
6. **pycryptodome AEAD 解密必须 decrypt_and_verify(ct, tag)**——decrypt() 第二位置参数是 output！
7. **Noise 链补丁**：SessionRequest 加密后必须 mixhash(ct)（:813）；SessionCreated 解密后 mixhash(ct)（:1107）；SessionConfirmed part1 加密后 mixhash(part1)（:1153）——漏一处即 MAC 失败
8. **HKDF salt 截断 32 字节**（Crypto.cpp: HMAC(...,salt,32,...)）——i2p_hkdf(keydata,...) 传 64 字节会算错 ab（ba 因传 32 字节切片侥幸正确）——此 bug 导致数据期单向失败，靠 /proc/pid/mem 读 Bob 会话对象实测定位（m_KeyDataSend=ba 匹配、m_KeyDataReceive≠ab → 锁定）
9. **握手头 word1 掩码密钥随消息类型变**：Retry 双词用 bob_i；SessionCreated word1 用 kh2("SessCreateHeader")；SessionConfirmed word1 用 kh2("SessionConfirmed")——解码需按候选密钥+AEAD 验证驱动（已实现 _try_retry/_try_session_created 级联+噪声历史配对 eph）
10. **数据期密钥推导时机**：KDFDataPhase 在 SendSessionConfirmed（含 static-static mixkey）之后（:1113-1114）；word0 掩码=接收方 intro key（发给 Bob 用 bob_i）
11. **RelayRequest 块内容布局**：flag(1)+nonce(4BE)+tag(4BE)+填充（nonce 在 buf+1、tag 在 buf+5）
12. **会话对象内存布局**（校准锚点）：[.. DestConnID(pos-20) SourceConnID(pos-12) state(pos-4, 7=Established) KeyDataSend(64)@pos KeyDataReceive(64) SendPacketNum..]——memscan 以我方 ba 定位

### 泄露尺寸公式（实测吻合）
- payloadSize = riSize + 5 + (relayReqLen + 35)；泄露包 = 16 + payloadSize + 16
- 实测：riSize=2819, relayLen=1420 → 4295B 泄露（前轮 2816→4292，公式一致）
- Bob 溢出后存活（溢出只打池内相邻 chunk）

### 当前工件
- scripts/ssu2lib.py：完整协议库（含 memscan 转储钩子、噪声历史、验证驱动握手）
- scripts/smoke1.py（双会话+tag）、smoke2.py（大RI投递+下溢+P2泄露+maps分类）
- scripts/lab_common.sh（netns+Bob 启动；Bob 需 --datadir 命令行参数，conf 里的 datadir 无效——Daemon.cpp:90 在 ParseConfig 前读）
- lab/bob.conf（关键项：ssu2.published/mtu4=1500/version=2、reseed.zipfile=seed.zip、host=45.45.45.1、floodfill/notransit 保持默认）
- lab/ritest：i2pd 自家代码的 RI 真值校验器（维护者仪器）
- lab/ev/：p2_leak.bin、p2_leak_parsed.txt、bob_maps.txt、memscan.txt

### 下一步（T8 终局链）
1. atk_p6_terminal.py：泄露→切小RI→groom→双Ack定向释放→读zone→R1投毒(numResends=3)→R2弹出→R3写Q→ROP起爆
2. Q 目标：泄露中的栈地址（栈指针会被 groom 覆盖→泄露前置）
3. gadget：pop rdi;ret@PIE+0x7ee54、system@libc+0x53090（旧值，重新标定）
4. 坑清单 4-13 全部照旧内化

## T8 终局链工程状态（第二轮更新——堆几何实测）

### 已完成
- atk_p6_terminal.py 骨架：setup/leak/parse_leak/calibrate（SIGSTOP+栈读取+HandlePayload:1842 返回槽识别）
- **静态银行值全部本轮独立复现**：pop rdi;ret@PIE+0x7ee54（objdump 验证）、system@libc+0x53090（nm 验证，glibc 2.41）、泄露尺寸公式
- 泄露调用链 addr2line 命中：HandlePayload@:1842（=HandleRelayRequest 返回槽）、HandleRelayRequest@:2267、CreateRouterInfoBlock@:2918、CreateRelayIntroBlock@:3121 全部在泄露中出现
- 泄露含 69 个线程栈指针（8MB 线程栈仅用 ~9KB）

### 堆几何实测（atk_probe.py, 40 groom, /proc/mem）
- **池 chunk size 字段 = 0x605**（0x600+PREV_INUSE+NON_MAIN_ARENA——io 线程 arena，非主 arena！补丁值必须是 0x605 不是 0x601）
- **步长直方图：1712×16, 1536×15, 1664×4**——交错区实锤：每个 relay 请求分配 [池块1541][shared_ptr ctrl块~64B][map节点~64B] ≈ 1712
- 受害者 V 前方（高地址）：V+1536=V 自己的 ctrl 块 C 的 size 字段、V+1544=C 主体、V+~1624=map 节点 M、V+1712=下一请求的池块 V'
- **C 在 memcpy 之前分配（AcquireShared 时），M 在之后（emplace 时）**——溢出必砸 C；砸坏 C 的 vtable → emplace 后续析构 = 虚调用段错误（dmesg 实证：`48 8b 07 48 89 fb <ff> 50 10` = call [rax+0x10]）

### 崩溃根因清单（三轮实测）
1. 无 0x605 补丁 → "free(): corrupted unsorted chunks" / top 损坏
2. numResends=0x41414141 → ~540ms 后重发路径段错误（坑 4 实证）
3. "A"填充砸 C 的 vtable → 虚调用段错误；砸 freed C/M 的 tcache next/key → munmap_chunk abort

### 外科手术 RI 规格（设计定稿）
- 布局锚定（受害者 V，全为 RI 内偏移 = 绝对偏移-5）：
  - RI[1515..1518] = numResends=3（LE int）
  - RI[1523..1530] = 下一 chunk size 字段（0x605 LE；若下一块为 ctrl 块则为其 size ~0x55）
  - RI[1539..~1608] = **C 的逐字节复刻**：[vtable(8)=PIE+固定偏移][use_count(4)=1][weak_count(4)][_Sp_counted_deleter: ptr(8)=V][deleter fn(8)=PIE+固定][pool this(8)=SSU2Server*]
  - RI[~1619..1683] = M 的 chunk 头复刻（若 M 已分配；M 在 memcpy 后分配时此区=top 可自由写）
  - RI[1707..1714] = V+1712 处池块 V' 的 pool-freelist next = **Q（投毒点）**
- V' 必须在溢出时刻为 FREE（在池 freelist 上）且 V 为 freelist 头（R1 的 Acquire 弹出 V）
- 释放顺序（LIFO）：先 ack V' 的包（freelist: V'→旧)，再 ack V 的包（freelist: V→V'→旧）→ V.next=V'（pool next 天然指向）
- R1（Acquire=V，溢出投毒 V'.next=Q）→ R2（Acquire 弹 V'，m_Head=Q）→ R3（Acquire 返回 Q=栈目标，placement-new 清零 Q+1504..1523 后 memcpy RI @ Q+5 = 任意写）
- Q 落点：HandleRelayRequest 帧的 [canary, retaddr) 窗口（其上所有帧皆有 canary，实测 5 个函数全有 stack_chk）；retaddr 槽=泄露中 HandlePayload@:1842 值的位置（栈几何由 calibrate 步骤实测：S=泄露绝对基址，slot=S+泄露偏移）
- ROP 链（R3 的 RI 内，放 addr_pad）：[R]=pop_rdi、[R+8]=cmd_ptr(=Q+5+identity内命令串偏移)、[R+16]=ret(对齐)、[R+24]=system、[R+32]=pop_rdi、[R+40]=0、[R+48]=exit
- 命令串已烘进 identity pad（identity 全程字节固定）：offset 32 起

### 待办（下一步逐个解决）
1. **instrument 读 C 的运行时值**：vtable 偏移（nm/objdump _Sp_counted_deleter vtable）、deleter fn 偏移、SSU2Server* （leak 堆指针或 /proc/mem）——写成 atk_zone_read.py（SIGSTOP 后以小 RI 内容定位 V/V'，dump V+1536..V+1712 原始字节）
2. 验证复刻 RI 后 Bob 存活 + R1-R3 推进
3. tcache 状态风险：freed C/M 的 next/key 复刻值 = 运行时读；如 tcache 干扰则改用"V 的包不 ack、用第二条会话的包做 V'"等变体
4. calibrate 栈几何 → Q 定位 → R3 写 → ROP 起爆 → 取证三件套

## T8 第三轮实验记录（atk_poison_test.py —— 投毒机制验证）

### 已验证 ✓
- **tcache 预填 groom 生效**：批1 10 请求 → ack 前 7 个（释放池块+Ctrl/M 进 tcache）→ 批2 8 请求进入"原地回收"模式 → **相邻 1536 对出现**（3~13 对/轮）
- 外科 RI（numResends=3 + 0x605 补丁）投递后 **Bob 存活**（堆稳定 ✓）
- 批1/批2 relay 包号连续可测（groom1 nums=[0..11], groom2 nums=[13..29]——注意 ack 后 Bob 的 QuickAck 也占号）
- addr_pad 起始偏移 apo=551（identity391+ts8+naddr1+addr头16+常规opts135）

### 本轮卡点（三个，按优先级）
1. **R1 未溢出**：B 字节只出现在主 arena（netdb 副本+日志串 0x5634/0x5620 区），线程 arena（0x7f56）零命中；Bob 日志只见 2 个 RelayRequest。可能原因：(a) 0x3000 nonce 的请求与 ack 时序交错被丢；(b) FindRouter 时 r=IsUnreachable→nullptr→走 SendFragmentedMessage 分支（无 memcpy）；(c) fire 与 ack 竞态。**下一步**：R1/R2/R3 每发一个就 recv 记录 Charlie 收到的包尺寸（大泄露=溢出发生；~700B 正常包=r 小或路径没走）+ Bob 日志逐行对时序
2. **包号↔chunk 地址映射未证实**：ack 28/29 释放的块是否=选定的 (X,Y) 对未验证。**下一步**：ack 前后各做一次 probe（SIGSTOP+按 idpref 定位 chunk 集合差分=被释放的块地址），把"ack 包号→chunk 地址"表建出来再用
3. **canary 几何约束（重要发现）**：RI 前 551 字节是 identity+固定区（不可运行时改写）→ 写入起点 Q+5 到 canary 的距离 ≥556 才能把 canary 复刻放进 addr_pad——而 Q+5 又必须高于 HandleRelayRequest 的活跃局部变量。**两条出路**：(a) 查 HandleRelayRequest 的帧大小（objdump sub rsp,N）——若 N≥600 则死区可能够；(b) **改打 ProcessData 帧**（其 payload[1500] 缓冲=天然大死区，canary 在其上，retaddr 更上——Q 落 payload 区内即可，canary_off 可控 ≥551 ✓ 推荐）；ProcessData 的返回槽也在泄露窗口内（泄露=S+0..4279 覆盖 SendData 之上全部帧）
- 注：canary 值本身在泄露里（8 字节、首字节 0x00 的 qword，位于返回槽下方 40-72B 处）——运行时从泄露提取、放进 R3-RI 的 pad 对应偏移

### 下一步（精确顺序）
1. atk_poison_test v3：ack 前后 probe 差分建包号→地址表 → 选真相邻对 → R1(1420) 后立即查 Charlie 收包尺寸 + B 落点（线程 arena）
2. 若 r=nullptr 问题：检查 netdb 状态（"RouterInfo updated"已见 ✓ 但需确认随后 relay 时 r 非空——Bob 日志无 "Alice's router info not found" ✓ 倾向时序问题）
3. R1 溢出落地后：R2(100) 弹 Y → R3(1420) 写 Q → 仪器验证 Q 处标记
4. 写机制全通后：Q 改栈地址（ProcessData 帧 payload 区）+ ROP 链（pop_rdi/cmd/ret/system/pop_rdi/0/exit）+ canary 复刻 → 起爆 → 取证
5. 全部取证落盘后 → T9 musl → T10-T13 报告打包

### 交付状态声明（截至本轮上下文耗尽）
- **已重建并实测**：实验室（netns/双档二进制/离线 reseed）、SSU2 协议库全通（握手/中继/数据期/P2 泄露 4292-4295B/76 指针）、堆几何全图、外科 RI 存活性、银行值三项独立复现（0x7ee54/0x53090/泄露公式）
- **未完成**：终局 RCE 的最后编舞（上述 3 卡点）——本台账+脚本为续接载体；按用户纪律：未跑通的不写进报告为"已完成"

## T3 机制全图（本轮从源码逐行重验，全部与快照吻合；含行号供报告引用）
### 漏洞本体（VULN-01，同一下溢模式 3 个可达 sink）
- SSU2Session.cpp:2261 HandleRelayRequest（主 sink，实际利用路径）
- SSU2Session.cpp:2503 HandlePeerTest msg1（Bob from Alice）
- SSU2Session.cpp:2622 HandlePeerTest msg3（Bob from Charlie）
- 公式：`CreateRouterInfoBlock(packet->payload, m_MaxPayloadSize - len - 32, r)`，len=攻击者块长度，>m_MaxPayloadSize-32 即下溢
- m_MaxPayloadSize = mtu(1500) - 20(IP) - 8(UDP) - 32 = 1440（AdjustMaxPayloadSize, SSU2Session.cpp:2826-2840）
- CreateRouterInfoBlock (2904-2931)：`size+5 < len`(下溢后恒真) → **未压缩全量 memcpy 到 buf+5**；正常路径走 gzip
- r = netdb.FindRouter(会话对端 identHash) + PopulateRouterInfoBuffer → 攻击者此前投递的 RI 原文
### 溢出几何（glibc malloc，用户指针 V）
- SSU2SentPacket: payload@0[1500] payloadSize@1504 sendTime@1512 numResends@1520，sizeof=1528
- new T → malloc(1528) → chunk size 1536；下一 chunk 用户指针 = V+1536；V+1528..1535 = 下一 chunk 的 size 字段(0x601)
- 下一下 chunk 的 payloadSize 字段 = V+1536+1504 = V+2540；其 freelist next（若已释放）= V+1536+0
- payloadSize 溢出后被赋值语句洗为 riSize+5；sendTime 被 2268 行洗为 mts；numResends 保持 RI 字节（用 3）
- 最终 payloadSize = riSize + 5 + (relayReqLen + 35)（RelayIntro=1+32+introData(len-1) 块头 3；payloadSize≥m_MaxPayloadSize 时无 padding）
### P2 泄露（SSU2Session.cpp:1695-1718 SendData）
- `uint8_t payload[1500]` 栈缓冲；AEADChaCha20Poly1305Encrypt 返回值被忽略
- Crypto.cpp:649-653：`len(1500) < msgLen || len < msgLen+16` → return false，out 未触碰
- 随后 Send(header,16,payload,len+16) 照发 → 发出 SendData 栈帧陈旧数据（含 HandleRelayRequest 帧的返回地址/局部指针）+ 更高栈区
- 泄露大小 = payloadSize+16，由 riSize/relayReqLen 精确调谐（前轮实测 4292）
### P3 任意写（util.h:48-126 MemoryPool + HandleAck）
- Release: `*(void**)t = m_Head; m_Head = t`（LIFO，next 存于释放块前 8 字节）
- Acquire: pop + placement-new（先把 Q+1504..1523 清零）→ 之后 memcpy 在 Q+5 写 RI 全量
- HandleAck→HandleAckRange→m_SentPackets.erase→shared_ptr 释放（1998-2065）：双 Ack 按 packetNum 定向控制释放顺序
- 溢出写穿 F2（紧邻 V 的已释放 chunk）的 next=Q → 下一次 Acquire 返回 F2、再下一次返回 Q → Q+5 起 memcpy 攻击者 RI = 任意写
- 写入映射：落点 = Q + 5 + RI 内偏移（Q3MARK 实测锚点：RI 偏移 607 → Q+612）
### Relay 触发链（攻击者同时扮演 Alice 会话① + Charlie 会话②）
- Charlie ②的 SessionRequest 载荷含 RelayTagRequest 块（type 15, size 0）→ Bob 在 ProcessSessionRequest:934 HandlePayload → 1872-1885：需 AcceptsTunnels()（不加 --notransit）+ FindLocalAddress()->IsIntroducer()（Bob 发布 SSU2 地址且非 floodfill：RouterContext.cpp:505 UpdateSSU2AddressCapsIntroducer(addr, !m_IsFloodfill)）→ RAND tag + AddRelay(tag, 会话②)
- tag 在 Bob 的 SessionCreated 回给 Charlie（SSU2Session.cpp:1000-1006）
- Alice ①Data 载荷含 RelayRequest 块（type 7，内容>1408 字节：nonce(4)+relayTag(4)+后续填充）→ HandleRelayRequest → 溢出包经 会话②->SendData 发给 Charlie（我们全部可见）
- token 引导：首包 SessionRequest 无 token → SendRetry(含 NewToken) → 重发（SSU2Session.cpp:877-881, 1549-1587）
### RI 构造约束（RouterInfo.cpp:78-511）
- 格式：IdentityEd25519(全长待构造时核验) || ts(8 BE ms) || numAddr(1) || [cost(1)+date(8)+transport z串+size(2)+Mapping] || numPeers(1)+32*n || MappingSize(2)+顶层 Mapping || Sig(64)
- Mapping 项：klen(1) key '=' vlen(1) value ';'
- ssu2 地址需：v=2、s=(X25519 静态，末字节高位须 0)、i=(intro key)、host+port（published）；host=45.45.45.2
- 顶层需：netId=2（from_chars 严格数值）、version（可解析非零）、caps；签名必须有效（Update/构造均验签，Ed25519）
- 更新同 identHash 需 IsNewer（时间戳严格递增，601-607）；identHash = SHA256(identity 序列化) → **所有 RI 变体 identity 字节必须逐字节一致**（否则 HandleRouterInfo:1982 不更新 m_RemoteIdentity，FindRouter 落空）
- 大 RI 数据期投递：RouterInfo 块(type 2) gzip(flag 0x02)，经 HandleRouterInfo(1965-1996) → AddRouterInfo
### 握手（Noise XK，Crypto.cpp:806-917）
- 协议名哈希/常量：InitNoiseXKState1（"Noise_XKchaobfse+hs1+hs2+hs3_25519_ChaChaPoly_SHA256"）
- MixKey: HKDF(ck, ikm, 32, "", 64)→[ck', k']；HKDF 零 data 形态=Expand(PRK=HMAC(key,∅))
- Encrypt/Decrypt nonce：N=0→全零，否则 4 零+LE64；AD=m_H
- 头掩码：ChaCha20(key=kh, nonce=包尾 12 字节, 8 零字节)→8 字节 XOR
- 会话密钥：KDFDataPhase(1452-1460) HKDF 链 "HKDFSSU2DataKeys"（先 "" 64 再两段各 64）
- SessionConfirmed part1 = 加密的 X25519 静态公钥(48)，part2 = 块载荷（RI 块必须第一）
- ver=2（无 PQ），packetNum=0
### 其他关键常量
- 包类型：SessionRequest=0 Created=1 Confirmed=2 Data=6 PeerTest=7 Retry=9 TokenRequest=10
- 块类型：DateTime=0 RouterInfo=2 I2NP=3 RelayRequest=7 RelayResponse=8 RelayIntro=9 PeerTest=10 Ack=12 Address=13 RelayTagRequest=15 RelayTag=16 NewToken=17 Padding=254
- Data 包头 16B：DestConnID(8 BE) packetNum(4 BE) type(1) flags(3)；头两 8 字词各自 XOR 头掩码（密钥：发方向 m_Address->i / 数据期 KeyDataSend+32）
- SSU2_INITIAL_RTO=540ms（坑 11）；Ack 块：ackThrough(4)+acnt(1)+[nacks(1)+acks(1)]*（HandleAck 2005-2024）
- Bob 侧 AddSession/connID 分发：SSU2.cpp ~700（首包按 intro key 解出 connID 找 pending session）
### 实验方法学（照旧）
- 攻击本体=纯网络原语（P2 泄露拿运行时地址）；/proc/<pid>/maps 与 /proc/<pid>/mem 仅作维护者侧标定仪器（evidence 归档"maps 校准数据"）
- [ ] T5 musl 二进制提取
- [ ] T6 netns 实验室
- [ ] T7 协议库+atk 脚本重建
- [ ] T8 glibc 档终局链复跑 ×2
- [ ] T9 musl 档推进
- [ ] T10 报告 MD+PDF
- [ ] T11 披露信+advisory
- [ ] T12 summary-zh
- [ ] T13 原子打包+验证

---
Task ID: T8-mech
Agent: main
Task: glibc 档终局链机制验证（R1 投毒→R2 弹出→R3 任意写）

Work Log:
- 复盘上轮 poison_test 三大根因：(1) R2/R3 content_len=100 从未触发下溢（gzip 路径无溢出）；(2) ri_write 构建后从未投递；(3) settle ack 把 R2 的块释放回 head 导致 R3 弹错块
- 源码确认关键分支：CreateRouterInfoBlock `size+5<len` 未压缩 memcpy（下溢恒真）；HandleAckRange 升序 erase=LIFO；QuickAck 走栈版 SendData 不碰池；Resend 重传会 re-key m_SentPackets
- scan 模式修复：idpref[3:] 匹配（freelist next 指针覆盖 payload[0..7]，污染 idpref 前 3 字节，全 idpref 匹配看不到 FREE 块）
- groom 编舞：批1(10)→ack→批2(8 回收)→ack→probeC 链遍历（拓扑排序还原 freelist 全序）→批3 nonce 锚定（chain idx→pkt 映射 8/8）
- 原子编舞修正：ack(Y)+ack(X) 同包 + R1/R2/R3 背靠背 fire，**R1/R2 的包绝不 ack**（否则块回 head、R3 弹错）
- RI_POISON=1664（pad 覆盖投毒点 RI[1531]），Q=X+1400&~0xf（全死区零损伤）

Stage Summary:
- **R1 投毒实证**：溢出后 Y.next==Q、Y.size==0x605（/proc/mem 直读验证）
- **R3 任意写实证**：marker "R3WROTEHERE!" 精确落 Q+605（X+1997），markers 双命中确认 R1/X+605 + R3/Q+605 两次独立写入
- 泄露公式复证：LEAK 3140B = 1664+5+1455+16 ✓
- Bob 存活到取证完成后才 double free（intro 尾砸 Y+1536 处下一块 size，ROP 版无此问题）
- 工件：scripts/atk_chain_v1.py（全链）、lab/ev/chain_v1_result.txt、ev/last_run.out
- 待办：ROP 版（泄露标定栈几何→Q 对准 HandlePayload:1842 返回槽→canary 复刻+ROP→root RCE ×2）

---
Task ID: T8-rce1
Agent: main
Task: glibc 档终局链 ROP 起爆 → 第一次 root RCE

Work Log:
- atk_p6_terminal.py 完整链跑通：groom→链遍历→nonce锚定→外科泄露(补丁写回原值零损伤)→calibrate(指针残留法定位R：retaddr值8字节needle在冻结栈搜索单一命中+自洽校验)→canary从泄露[R-64]精确提取(leak/live双验证)→ROP投毒
- 攻克五个关键坑：
  (1) idpref不能用identity pad开头(cmd烘入后全零)→改用ed_pub区(RI[352:384],SIG_OFF=357)
  (2) R3 memcpy覆盖CreateRelayIntroBlock等继续路径的历史栈槽→ret sled铺RI[X_RET-456..X_RET-8]
  (3) canary槽用pop rdi跳板绕过(pop弹掉canary值不跳转)@X_RET-72
  (4) sled槽必须与栈槽同余mod 8(SLED_START=X_RET-456, X_RET=2000)
  (5) G_RET旧银行值PIE+0x6e在r--段不可执行(SIGINFO code=2 ACCERR实锤)→改pop_rdi gadget第二字节PIE+0x7ee55
- 关键参数终值：X_RET=2000、RI_BIG=2170、pop_rdi@PIE+0x7ee54、pop_rsi@PIE+0xb473e、pop_rdx@PIE+0x1f1ba2、execve@libc+0xddb50、R1chk投毒验证每轮通过(Y.next==Q、Y.size==0x605)
- core dump解析器(parse_core.py)拿崩溃现场：rsp/rip/寄存器/栈镜像——定位r--段不可执行的确凿证据(SIGINFO addr=ret gadget地址、code=2)

Stage Summary:
- *** 第一次独立 root RCE 取证三件套落盘 ***
- /tmp/vuln01_rce_1.txt：uid=0(root) gid=0(root) groups=0(root)、whoami=root、uname、date、PWNED-BY-VULN01-RUN-1
- 起爆后0.3s完成取证；工件在 lab/ev/rce_run1/(标记文件、timeline_stdout、bob.log、leak.bin、calib.json)
- 待办：run 2 独立复现 → musl → 报告打包

---
Task ID: T8-rce2
Agent: main
Task: 第二次独立 root RCE 复现

Work Log:
- atk_p6_terminal.py --run 2 全新 Bob 实例（runner 每次 rm -rf bob-data 重建）
- 起爆后 0.3s 取证完成

Stage Summary:
- *** 第二次独立 root RCE 取证落盘 ***：uid=0(root)/whoami=root/PWNED-BY-VULN01-RUN-2/时间戳 10:50:10（与 run1 隔 34 秒、完全独立实例）
- T8 完成：glibc 档两次独立 root RCE ✓
- 待办：T9 musl → T10-13 报告打包

---
Task ID: T9-musl
Agent: main
Task: musl 档推进

Work Log:
- gadget 实测备齐（exec 段字节扫描）：pop rdi @ +0x62386、pop rsi @ +0x8a72e、pop rdx @ +0x411ace（readelf LOAD@0x46000 E）
- musl loader 1.2.3 从 Debian pool 解包可得（/tmp/muslx/lib/x86_64-linux-musl/libc.so 可执行自检）
- 环境性阻断：i2pd-musl 依赖 musl 版 libssl/libcrypto/libz/boost 全链（alpine 构建），本机无 root 无法安装 musl 运行时，逐包提取超出本轮预算 → musl 档在本实验室不可执行
- 结构性阻断（报告如实记录）：stripped 无符号 → glibc 档依赖的返回槽锚定（nm needle）不可用；紧凑栈布局几何不可平移
- atk_p7_musl.py 已生成（glibc 编舞移植+MUSL BLOCKERS 文档化，跑到 R1 投毒检查点）

Stage Summary:
- musl 档如实定级：未完成 RCE；协议/堆编舞分配器无关可平移；gadget 齐备；环境+锚定双阻断；双绕过路线（短载荷/两段写）保留在报告 4.1
