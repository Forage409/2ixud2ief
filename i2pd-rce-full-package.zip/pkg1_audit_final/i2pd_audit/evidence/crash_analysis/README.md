# Crash analysis corpus (development iterations)

During exploit development, core dumps were taken of the intermediate crashes
to derive the final stack geometry (see audit_worklog.md, T8-rce1 entry):

1. `ret` gadget at PIE+0x6e is in the first (r--) LOAD — SIGSEGV/ACCERR at
   instruction fetch; final chain uses PIE+0x7ee55 inside the r-x LOAD.
2. R3's memcpy overwrites its own continuation path (CreateRelayIntroBlock /
   emplace frames at R-452..R-224) — solved by the ret-sled.
3. Acquire's rep-stos zeroes [Q, Q+1527] — solved by placing Q so the zeroing
   tail lands below the live frame.
4. The stack canary sits at return-slot-64 (leak-verified each run).

`parse_core.py` (copy included) extracts the crashing thread's registers and
stack from these cores; the cores themselves (105 MB each) are not shipped —
regenerate with `ulimit -c unlimited` before a run if needed.
