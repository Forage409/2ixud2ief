#!/bin/bash
# run_in_lab.sh — run one experiment inside the unshare -Urn lab namespace.
# Usage: run_in_lab.sh <script.py> [args...]
# stdout+stderr tee'd to /home/z/my-project/lab/ev/last_run.out; Bob log copied out.
set -u
LAB=/home/z/my-project/lab
SCRIPT="$1"; shift || true
OUT="${OUT:-/home/z/my-project/lab/ev/last_run.out}"

unshare -Urn bash -c '
  set -u
  LAB="'"$LAB"'"
  SCRIPT="'"$SCRIPT"'"
  ARGS="'"$*"'"
  . "$LAB/../scripts/lab_common.sh"
  netns_up || exit 1
  bob_start || exit 1
  python3 "$SCRIPT" $ARGS
  RC=$?
  cp "$LAB/bob-data/i2pd.log" "$LAB/ev/bob_last.log" 2>/dev/null
  bob_stop
  exit $RC
' 2>&1 | tee "$OUT"
echo "[runner] done, output in $OUT, bob log in $LAB/ev/bob_last.log"
