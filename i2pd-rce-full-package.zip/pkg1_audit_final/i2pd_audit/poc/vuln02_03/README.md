# VULN-02 / VULN-03 — same underflow at HandlePeerTest (msg1 :2503, msg3 :2622)

These two sinks share VULN-01's exact call shape (see `verify_underflow_sinks.py`,
a runnable static pattern proof against the 2.61.0 source tree).

**Honest status:** identified in source audit; end-to-end exploitation NOT
performed. The relay path (VULN-01) is strictly more accessible and was
priorized for the demonstrated chain. Fix is identical to VULN-01: validate
block length before the unsigned subtraction.
