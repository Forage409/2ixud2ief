#!/usr/bin/env python3
"""verify_underflow_sinks.py — source-audit verifier for VULN-02/VULN-03.

FOR MAINTAINER REPRODUCTION ONLY (audit evidence; no network capability at all).

Proves from the 2.61.0 source tree that the same unsigned-underflow call shape
as VULN-01 (HandleRelayRequest, empirically exploited end-to-end) exists at
the two HandlePeerTest sinks. This is a static pattern proof; exploitation of
these two variants was NOT performed (the relay path is strictly more
accessible and was prioritized) — see report Section 3.
Usage: python3 verify_underflow_sinks.py [path/to/SSU2Session.cpp]
"""
import re, sys, os

SRC = sys.argv[1] if len(sys.argv) > 1 else \
    os.environ.get("I2PD_SRC", "lab/i2pd/libi2pd/SSU2Session.cpp")

def main():
    if not os.path.exists(SRC):
        sys.exit("source not found: %s (pass path as argv[1])" % SRC)
    lines = open(SRC, encoding="utf-8", errors="replace").read().splitlines()
    pat = re.compile(r"CreateRouterInfoBlock\s*\(\s*packet->payload\s*,\s*"
                     r"m_MaxPayloadSize\s*-\s*len\s*-\s*32")
    hits = []
    for i, ln in enumerate(lines, 1):
        if pat.search(ln):
            fn = "?"
            for j in range(i - 1, max(0, i - 120), -1):
                m = re.match(r"\s*(?:void|bool|uint\w+|size_t)\s+SSU2Session::(\w+)", lines[j-1])
                if m: fn = m.group(1); break
            hits.append((i, fn, ln.strip()))
    print("source: %s" % SRC)
    print("underflow-shaped CreateRouterInfoBlock calls: %d" % len(hits))
    for i, fn, ln in hits:
        print("  line %d  in SSU2Session::%s" % (i, fn))
        print("    %s" % ln)
    print("\nVERDICT:")
    names = {fn for _, fn, _ in hits}
    for want, vid in [("HandleRelayRequest", "VULN-01"),
                      ("HandlePeerTest", "VULN-02/03")]:
        print("  %s (%s): %s" % (vid, want, "PRESENT" if want in names else "NOT FOUND"))
    print("\nNOTE: VULN-01 sink empirically exploited end-to-end (report S5);")
    print("      VULN-02/03 sinks are pattern-identical; exploitation NOT performed.")
    return 0 if len(hits) >= 3 else 1

if __name__ == "__main__":
    sys.exit(main())
