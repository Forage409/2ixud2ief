# VULN-04 — SendData transmits uninitialized stack on AEAD failure

Reproduction: run `../vuln01/smoke2.py` in the lab (see root README for the
runner). It delivers an oversized RouterInfo, fires the underflow relay
request, and captures the leaked packet (4292-4295 bytes with a 2816 B RI;
3.6 KB with the terminal 2170 B RI). The parsed pointer corpus for the
archived run is in `../../evidence/leaks/`.

Mechanism: Crypto.cpp:649-653 returns false without touching the output
buffer when msgLen exceeds the 1500-byte stack buffer; SSU2Session.cpp:1695-
1718 SendData ignores the return and transmits `payload[len+16]` regardless.
