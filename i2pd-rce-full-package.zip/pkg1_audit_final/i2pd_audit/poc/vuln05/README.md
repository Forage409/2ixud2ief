# VULN-05 — MemoryPool freelist poisoning → arbitrary-address allocation

Reproduction: run `../vuln01/atk_chain_v1.py` in the lab. It performs the full
groom → chain-walk → nonce-anchored double-ack → R1 poison → R2 pop → R3
write choreography with Q aimed at a deterministic heap dead-zone, and verifies
the marker string lands at exactly Q+605 (write-what-where confirmed in
isolation from control-flow hijack).

Key empirical checkpoints printed by the run:
- R1chk: `Y.next == Q` and `Y.size == 0x605` (poison + surgical size restore)
- RESULT: `WRITE VERIFIED AT Q+605`
