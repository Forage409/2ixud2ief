# VULN-06 — RouterInfo acceptance imposes no effective size ceiling

Verifier: `../vuln01/smoke2.py` already demonstrates the acceptance side (a
2816 B RouterInfo is accepted, stored, and later served to the VULN-01 sink);
`atk_chain_v1.py` demonstrates size control up to 2170 B with fully
controlled content (identity padding + address-mapping padding carry the
exploit payload). The audit's terminal chain relies on this: the ROP chain
itself travels inside an accepted RouterInfo.
