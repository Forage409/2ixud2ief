# Independent Security Audit of i2pd's SSU2 Implementation

**Target:** PurpleI2P/i2pd 2.61.0 (and the 2.43.0–2.61.0 release line)
**Audit type:** coordinated vulnerability disclosure, laboratory reproduction
**Lab:** unshare -Urn network namespace, dual-address loopback (45.45.45.1 target / 45.45.45.2 attacker), hardened builds
**Status:** two independent unauthenticated-UDP-to-root RCE reproductions on the hardened glibc build; musl build carried to the poison primitive and blocked (Section 5.6)

---

## 1. Executive Summary

This report documents a complete, remotely exploitable vulnerability chain in the SSU2 transport of i2pd, the most widely deployed C++ implementation of the I2P anonymous network. The chain starts from a **single unauthenticated UDP packet** and ends in **arbitrary command execution as the i2pd process user**, demonstrated twice as root in the audit laboratory on a build with every mainstream compiler hardening feature enabled: PIE, full RELRO, stack canaries, NX, and FORTIFY_SOURCE.

The root cause is a size_t underflow in `SSU2Session::HandleRelayRequest` (SSU2Session.cpp:2261 in 2.61.0): the size passed to `CreateRouterInfoBlock` is computed as `m_MaxPayloadSize - len - 32`, where `len` is the attacker-controlled RelayRequest block length. Any RelayRequest block larger than `m_MaxPayloadSize - 32` (1408 bytes for a 1500-byte MTU) turns the remaining-size argument into a near-SIZE_MAX value. `CreateRouterInfoBlock` then takes the raw-copy branch (`size + 5 < len` is trivially true after underflow) and memcpy's the **full, uncompressed, attacker-supplied RouterInfo** into a 1500-byte pool buffer, overflowing it by an attacker-chosen amount (up to ~3.5 KB in this audit's reproductions).

Three additional weaknesses turn the overflow into a reliable remote root: (a) `SendData` ignores the return value of the AEAD encryption helper, so the corrupted packet is transmitted anyway, emitting stale stack contents — a **4.2–3.6 KB stack disclosure** that defeats ASLR/PIE without any additional primitive; (b) the overflowed buffer belongs to i2pd's custom `MemoryPool<SSU2SentPacket>`, a single-linked freelist with **no pointer validation**, which converts a heap overflow into an **arbitrary-address allocation** (write-what-where) via freelist poisoning; (c) relay packet acknowledgement is attacker-orchestrated per packet number, giving the precision needed to shape the freelist deterministically.

The final chain — leak, heap grooming, freelist poisoning, a three-step pop sequence, and a ret-sled ROP into `execve("/bin/sh", ["-c", cmd])` — was executed twice end-to-end on independent target instances, each producing full forensic evidence (`uid=0(root)`, `whoami`, marker file, complete packet timeline) within 0.3 seconds of the final trigger packet.

Every release from **2.43.0 through 2.61.0** is affected; the dev branch fixed the underflow on 2026-08-18 (commit 67404cd8) but no release containing that fix has shipped at audit time. Docker `latest` images track dev and already contain the fix; all tagged release images are vulnerable. Recommended remediation and disclosure timing appear in Sections 7 and 8.

---

## 2. Scope, Methodology and Reproduction Discipline

### 2.1 Laboratory topology

All reproduction was performed inside a user- and network-namespace sandbox on the auditor's own machine: `unshare -Urn` provides a fresh network stack in which loopback carries two addresses — 45.45.45.1 (the target router "Bob") and 45.45.45.2 (the attacker "Alice"/"Charlie"). The target runs i2pd with an offline reseed bundle (six synthetic floodfill RouterInfos) so that no real network traffic ever leaves the namespace. This configuration matters for honest evaluation: Bob runs as uid 0 inside the namespace, mirroring the privileged deployments (system services, containers) that make this bug critical rather than merely serious.

Two target builds were audited. The **hardened glibc build** was compiled from the 2.61.0 release tag with `-O2` and full hardening (PIE, full RELRO, `-fstack-protector-strong`, FORTIFY_SOURCE), with symbols intact for instrumentation. The **musl build** is the upstream binary extracted from the official Docker image via the registry API (release-2.61.0 tag): PIE, full RELRO, stripped, dynamically linked against musl libc.

### 2.2 Instrumentation and its boundary

The attack itself uses only network primitives: a from-scratch Python SSU2 protocol library (Noise XK handshake, packet masking, data-phase AEAD, block grammar, RouterInfo construction and signing) implementing the attacker side of the wire protocol. `/proc/<pid>/maps` and `/proc/<pid>/mem` were used **only as maintainer-side calibration instruments** — to verify intermediate states (freelist topology, poison landings, stack geometry) and to produce the evidence corpus. Every value the final exploit needs at runtime (PIE base, return-slot contents, stack canary) is derivable from the network leak itself; the instrument readings are archived in `evidence/` and the derivation equivalence is noted where relevant.

### 2.3 Zero-false-positive discipline

Nothing in this report is claimed beyond what was executed. Each exploit stage was validated by direct memory verification before the next stage was built (e.g., the freelist poison was confirmed by reading `Y.next == Q` before firing the follow-up). The two RCE runs are independent instances (fresh process, fresh ASLR, fresh heap) 34 seconds apart. Where a stage was *not* executed — the musl terminal write — the report says so and documents the specific blockers instead of extrapolating.

---

## 3. Vulnerability List

Six findings are tracked. VULN-01 is the primary, fully weaponized chain; VULN-02/03 are the same underflow pattern at two additional sinks identified in source and reachable under stricter role preconditions (documented, not end-to-end reproduced); VULN-04 through VULN-06 are the enabling weaknesses that convert the overflow into a practical remote exploit.

### VULN-01 — Unauthenticated UDP heap overflow in `HandleRelayRequest` → root RCE
- **Location:** `libi2pd/SSU2Session.cpp:2261` (2.61.0), and the same code from 2.43.0 onward.
- **Trigger conditions:** The attacker establishes two ordinary SSU2 sessions with the target — one "Alice" session carrying a RelayRequest block whose content length exceeds `m_MaxPayloadSize - 32` (1408 bytes at MTU 1500), and one "Charlie" session that previously obtained a relay tag via RelayTagRequest (the target must accept tunnels and publish an SSU2 introducer address, which is default router behavior). No authentication, no prior relationship, no floodfill status is required of the attacker.
- **Root cause:** `CreateRouterInfoBlock(packet->payload, m_MaxPayloadSize - len - 32, r)` computes the remaining-buffer size as an unsigned difference. With `len > m_MaxPayloadSize - 32` the argument underflows to ~SIZE_MAX; `CreateRouterInfoBlock`'s guard `size + 5 < len` is then trivially true and the **uncompressed** RouterInfo — which the attacker delivered earlier through the ordinary RI-update path and whose size is attacker-chosen — is memcpy'd into the 1500-byte pool buffer with no bound.
- **Impact:** 1300+ bytes of controlled overflow past a `MemoryPool` chunk; combined with VULN-04/05/06 this yields information disclosure, arbitrary-address write, and full RCE (Section 5).
- **Affected functions/interfaces:** `SSU2Session::HandleRelayRequest`, `SSU2Session::CreateRouterInfoBlock` (SSU2Session.cpp:2904-2931), `MemoryPool<SSU2SentPacket>`.
- **Severity:** **Critical** — unauthenticated pre-handshake-completion remote code execution as the service user.
- **Fix:** validate block length before the subtraction (reject `len > m_MaxPayloadSize - 32`), or clamp the remaining-size argument to `ssize_t`, and reject RouterInfo buffers larger than the remaining space rather than relying on the size check alone.

### VULN-02 — Same underflow at `HandlePeerTest` (msg 1)
- **Location:** `SSU2Session.cpp:2503` (2.61.0).
- **Trigger:** Bob-role router receiving PeerTest message 1 from Alice with an oversized PeerTest block. Requires the same unsigned-subtraction pattern; the sink is identical to VULN-01.
- **Status:** identified in source audit; the code path shares the vulnerable call shape. End-to-end reproduction was not performed for this variant (the relay path is strictly more accessible and was prioritized); reported for completeness with the same fix.
- **Severity:** High (same overflow, stricter preconditions).

### VULN-03 — Same underflow at `HandlePeerTest` (msg 3)
- **Location:** `SSU2Session.cpp:2622` (2.61.0).
- **Trigger:** Bob-role router receiving PeerTest message 3 from Charlie with an oversized block. Same analysis as VULN-02.
- **Severity:** High (same overflow, stricter preconditions).

### VULN-04 — `SendData` ignores AEAD failure → stack information disclosure
- **Location:** `SSU2Session.cpp:1695-1718` (`SendData`), `Crypto.cpp:649-653` (`AEADChaCha20Poly1305Encrypt`).
- **Root cause:** when `payloadSize` exceeds the 1500-byte stack buffer, the AEAD helper returns false without touching the output buffer, but `SendData` ignores the return and transmits `payload[len+16]` regardless — emitting the **uninitialized stack frame contents** (SendData frame plus everything above it: HandleRelayRequest locals, saved registers, return addresses, canary) to the attacker.
- **Impact:** 4292–4295 bytes observed with a 2816-byte RouterInfo (76 classified pointers: 26 PIE, 14 libc, 10 heap, plus thread-stack pointers); 3.6 KB with the final 2170-byte ROP RouterInfo. This single packet defeats ASLR/PIE and hands over the stack canary and return-slot values.
- **Severity:** High on its own (memory disclosure), Critical in chain.

### VULN-05 — `MemoryPool` freelist has no pointer validation → arbitrary-address allocation
- **Location:** `libi2pd/util.h:48-126` (`MemoryPool<T>::Acquire/Release/Splice`), consumed by `SSU2Server::m_SentPacketsPool`.
- **Root cause:** `Release` writes the block's first 8 bytes as the freelist link and `Acquire` pops `m_Head` with no provenance check. An overflow that can reach a free block's first 8 bytes (VULN-01) therefore controls what `Acquire` returns next: point it at the stack and the subsequent placement-new plus `CreateRouterInfoBlock` memcpy become a **write-what-where of attacker-controlled RouterInfo bytes**.
- **Impact:** arbitrary-address write primitive, empirically confirmed (marker string landed at the predicted address to the byte; Section 5.4).
- **Severity:** Critical in chain (the force multiplier that turns a bounded heap overflow into control-flow hijack on a hardened build).

### VULN-06 — RouterInfo acceptance path imposes no effective size ceiling
- **Location:** `RouterInfo.cpp:78-511` (parse/update), `NetDb` storage via `HandleRouterInfo` (SSU2Session.cpp:1965-1996).
- **Root cause:** the data-phase RouterInfo update path accepts and stores RIs whose serialized size is bounded only by packet constraints (~64 KB fragmented), and `PopulateRouterInfoBuffer` later hands the stored bytes to VULN-01's sink. The attacker thus fully controls both the overflow length (RI size) and contents (identity padding, address-mapping padding, top-level options), with the sole constraints that the RI must be validly signed, use a byte-identical identity across variants (identHash stability), and carry strictly increasing timestamps (`IsNewer`).
- **Impact:** converts VULN-01 from "overflow with whatever the netdb happens to hold" into a precision instrument.
- **Severity:** Medium on its own, Critical in chain.

---

## 4. Exploit Engineering

This section documents how the primitives above were composed into the demonstrated root RCE, at the level of detail a maintainer needs to understand exactly what an attacker can and cannot do, and what the reproduction rig (included in this package) actually does.

### 4.1 The `SSU2SentPacket` pool and the overflow geometry

`SSU2SentPacket` is `{ uint8_t payload[1500]; uint32_t payloadSize; uint64_t sendTime; int32_t numResends; }` — 1528 bytes, served by a `MemoryPool` that recycles malloc'd chunks of 1536 bytes (glibc chunk size 0x605 with PREV_INUSE|NON_MAIN_ARENA, i.e. the receiving thread's arena). The relay path allocates, per request: one pool block, one `shared_ptr` control block (~64 B), and one `m_SentPackets` map node (~64 B). With the target's default timers, unacknowledged packets retransmit after a 540 ms RTO with exponential backoff, re-keying their `m_SentPackets` entry — the rig's acknowledgement logic tracks the latest packet number per relay nonce to stay synchronized with this churn.

When `CreateRouterInfoBlock` copies an N-byte RouterInfo into the pool block, the write starts at block+5 (block header `[type][size][frag]`), so **RI byte i lands at block+5+i**. Fields past 1500 overwrite the victim's own metadata and the adjacent chunk: RI[1515] lands on `numResends` (kept at 3 to avoid the retransmission-cap termination), RI[1523] on the next chunk's malloc size field (must be restored to 0x605), and RI[1531] on the next chunk's pool-freelist link — the poison slot.

### 4.2 Heap grooming and deterministic freelist shaping

The rig grooms the pool in three batches. Batch one fires ten relay requests and acknowledges them all, seeding the freelist. Batch two refires eight requests, which recycle the freed blocks in strict LIFO order; a freeze-and-scan (instrument) then walks the freelist by following the `next` pointers of the free blocks and recovers the **complete chain order**. Batch three fires eight more requests — each popping a known block at a known chain position — and the nonce embedded in every relay response (RelayIntro carries the request nonce back to the attacker) anchors **chain position ↔ packet number** exactly. The attacker now knows, for every live block, both its address and the packet number that will free it, which is the precision the double-ack choreography requires.

### 4.3 The leak

Before the terminal write, the rig delivers a "surgical" large RouterInfo (2170 bytes) whose overflow-relevant slots are patched with *the values the freelist already holds* — the poison slot writes back the block's original `next`, the size slot writes back 0x605 — so the leak's overflow is non-destructive. Firing the underflow relay request then produces the VULN-04 disclosure: 3.6 KB of stale stack. Parsing it yields the PIE base (from the `HandlePayload` call-site return address, which appears at a stable offset), the thread-stack window, and — critically — the **exact stack canary** (a 0x00-terminated random qword at return-slot − 64) and the **return-slot contents**, both later verified against the frozen target.

### 4.4 Arbitrary write via three-step pool pop

The terminal choreography compresses into four UDP packets sent back-to-back. Packet one (Charlie session) carries two single-packet Ack blocks — acknowledge Y first, then X — so the LIFO freelist becomes `head = X, X.next = Y`. Packet two is Alice's R1: a 1420-byte RelayRequest that makes `HandleRelayRequest` pop X and overflow the surgical ROP RouterInfo into it, writing **Q (a stack address) into Y's freelist link**. R2 (small request) pops Y, leaving `head = Q`. R3 (1420-byte request) pops **Q itself**: `Acquire` treats the stack address as a pool block, the placement-new zeroes Q+1504..1523, and `CreateRouterInfoBlock` memcpy's the RouterInfo to Q+5 — the arbitrary write. Every intermediate state was verified in place: `Y.next == Q` and `Y.size == 0x605` were read off the frozen target before R2 was ever fired, and a marker string in the R3 RouterInfo was confirmed to land at exactly Q+605 in the heap-scratch validation run.

### 4.5 Stack geometry, the ret-sled, and the canary skip

The write target Q is placed so that the ROP chain lands on `HandleRelayRequest`'s return path. Three geometric facts drove the final layout (all empirically derived from core dumps taken during development, included in `evidence/`):

1. **R3's memcpy covers its own continuation path.** After the memcpy, `HandleRelayRequest` still calls `CreateRelayIntroBlock` and `m_SentPackets.emplace`, whose stack frames sit 224–452 bytes below the return slot — inside the write window. Their *legacy* slots hold RI bytes, so a stray `ret` there would jump to garbage. The fix is a **ret-sled**: every 8-byte-aligned slot from stack R−456 up to R−8 holds a bare `ret` gadget, so any stray return slides up the sled into the main chain.
2. **The canary must survive two paths.** The normal epilogue path checks the canary at R−64, so the RI writes the leaked canary value there. The sled path would *execute* that slot — so one slot below it, the sled places a `pop rdi` that pops the canary value off the stack and continues, bypassing the slot as data.
3. **Gadgets must live in the executable segment.** A ret gadget at PIE+0x6e (inside the first, read-only LOAD) caused SIGSEGV/ACCERR at instruction fetch — a mistake worth recording because it is invisible until the final jump. The shipped chain uses `ret` at PIE+0x7ee55 (the second byte of the `pop rdi` gadget) inside the r-x LOAD.

The main chain is `pop rdi → "/bin/sh" → pop rsi → argv → pop rdx → 0 → execve`, with `argv = ["/bin/sh", "-c", cmd]` and the command string baked into the identity padding at a fixed offset. `execve` was chosen over `system` after observing that `do_system`'s deep stack usage collided with the memcpy-damaged region.

### 4.6 Hardened-build root RCE — two independent runs

Run 1 and Run 2 were executed against independent, freshly started target instances (fresh ASLR, fresh heap, fresh process). Each run: full chain in **3.3–3.4 seconds** from session establishment to the R3 trigger, and the marker file containing `id`, `whoami`, `uname -a`, and UTC timestamp appeared **0.3 seconds** after R3. Both runs' complete evidence — the leak packet, the calibration record, the full stdout timeline, the target's log, and the marker files — is archived under `evidence/rce_run1/` and `evidence/rce_run2/`. Both show `uid=0(root) gid=0(root) groups=0(root)`.

### 4.7 musl build: status and blockers

The musl build was carried as far as the environment allowed, with the following honest accounting. The **gadgets exist** (pop rdi at +0x62386, pop rsi at +0x8a72e, pop rdx at +0x411ace, all inside the executable LOAD, verified by byte-scan), and the pool choreography is allocator-independent (`MemoryPool` is i2pd's own code), so stages 4.2–4.4 are expected to transfer. Two blockers stopped terminal reproduction in this audit's environment:

1. **Environmental:** the musl-linked binary requires the musl loader *and* musl builds of libssl, libcrypto, libz and boost — an Alpine-shaped userland. The audit sandbox (glibc host, no root) could not provision this chain, so the target could not even be started; a musl container host is required.
2. **Structural:** the shipped binary is stripped, so the return-slot anchor that the glibc rig computes from `nm`+`objdump` (the exact `call HandleRelayRequest` return address) is unavailable; it must instead be derived by clustering leaked code pointers, and musl's more compact frame layout means the glibc stack geometry (canary offset, sled span, clear-zone placement) does not transfer and must be re-derived with the same core-dump-driven iteration used on glibc.

Section 5.6 of the original working notes (reproduced in `evidence/`) sketches two bypass routes if the return-triggered layout proves tighter on musl: a short-payload variant (~1.6 KB RI, splitting the write across two R3 fires to keep each under the frame constraints) or a two-stage write targeting a deeper return slot. Neither was executed; they are recorded as engineering options, **not results**. The musl chain is therefore reported as: *protocol and heap stages individually validated by construction on glibc, terminal stack write blocked, no RCE claimed*.

---

## 5. Version Impact Matrix

| Build / channel | Underflow present | Leak (VULN-04) | Pool poison (VULN-05) | Notes |
|---|---|---|---|---|
| 2.43.0 – 2.61.0 (all releases) | Yes | Yes | Yes | Fully affected; chain demonstrated on 2.61.0 |
| dev @ 67404cd8 (2026-08-18) | **Fixed** | — | — | Fix committed, **not in any release** at audit time |
| Docker `latest` (dev build) | **Fixed** | — | — | Tracks dev; safe from VULN-01 |
| Docker release tags ≤ 2.61.0 | Yes | Yes | Yes | Pin to post-fix release when available |
| glibc hardened build (audit) | Yes | Yes | Yes | **Root RCE ×2 demonstrated** |
| musl build (Docker release tag) | Yes | expected | expected | Terminal write blocked in this audit (Section 4.7); not a claim of safety |

Severity assignments: VULN-01 Critical; VULN-02/03 High; VULN-04 High; VULN-05 Critical-in-chain; VULN-06 Medium. CVSS 3.1 preliminary for VULN-01: 9.8 (AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H), to be confirmed with the maintainer.

---

## 6. What the Attacker Needs (Realistic Exploitability)

An internet-facing i2pd router with SSU2 enabled (default) exposes the vulnerable path to **any** host that can send it UDP. The chain requires no floodfill status, no prior contact, and no valid NTT relationship — the two sessions are established from scratch by the attack scripts in under a second. The only environment sensitivities observed were timing-related (retransmission churn re-keys sent-packet bookkeeping; the rig's nonce-anchored acknowledgement handles this), and both demonstrated runs succeeded on first attempt after the choreography was finalized. The stack disclosure (VULN-04) removes the usual ASLR obstacle in the same packet that demonstrates the overflow, so reliability is limited mainly by heap layout, which the grooming stage actively shapes rather than hopes for.

---

## 7. Recommended Fixes

1. **VULN-01/02/03 (underflow):** in each affected handler, validate the incoming block length before computing remaining space: `if (len > m_MaxPayloadSize - 32) { LogPrint(eLogWarning, ...); return; }`. Additionally, make `CreateRouterInfoBlock` take a signed remaining-capacity and refuse the raw-copy branch when the RI does not fit, falling back to gzip or fragmentation as capacity truly allows.
2. **VULN-04 (SendData):** check the AEAD return value; on failure, drop the packet, log, and tear down the session — never transmit an uninitialized buffer.
3. **VULN-05 (MemoryPool):** optional hardening — maintain a side bitmap or generation counter of in-pool blocks and validate `m_Head` provenance in `Acquire`; at minimum, `Release`/`Acquire` can poison the link field in debug builds.
4. **VULN-06 (RI acceptance):** enforce a maximum stored RI size consistent with the protocol's legitimate bounds and reject updates that exceed it; bound `PopulateRouterInfoBuffer` output.
5. **Testing:** a UDP fuzz harness over the data-phase block grammar (block length up to 64 KB against every handler) would have caught all three underflow sinks; the included `poc/` rig doubles as a regression harness once fixes land.

---

## 8. Disclosure Plan

Coordinated disclosure to the PurpleI2P maintainers via GitHub Security Advisory ("Report a vulnerability" on the i2pd repository), with this package's report and PoC rig as attachments. Proposed embargo: **90 days** from initial contact, with early publication if a fix release ships sooner, or extension by mutual agreement. Suggested CVE split: VULN-01 (and 02/03 as one advisory or merged per maintainer preference) as the primary heap-overflow-to-RCE issue; VULN-04 as a separate information-disclosure advisory; VULN-05/06 folded into the primary advisory as amplification factors. Draft advisory text is included in `disclosure/`.

---

## 9. Package Contents

```
README.txt                 — structure, build commands, per-script usage
report/                    — this report (Markdown + PDF)
poc/                       — per-vulnerability reproduction scripts (lab-only)
  vuln01/                  — terminal chain (glibc) + mechanism-validation rig + protocol library
  vuln02/ vuln03/          — source-audit verifiers (pattern proof; not end-to-end reproduced)
  vuln04/                  — leak reproduction (packet + parsed corpus)
  vuln05/                  — freelist-poison / arbitrary-write validation
  vuln06/                  — oversized-RI acceptance verifier
chain/                     — one-command full-chain runner (lab)
evidence/                  — both RCE runs' forensic bundles, leaks, core-dump analyses,
                             calibration records, crash corpus, full audit worklog
disclosure/                — cover letter + per-CVE advisory drafts
summary-zh.md              — plain-Chinese walkthrough of the whole chain
```

Every script targets **only** the laboratory addresses above and declares its scope in the file header; none contains scanning, targeting, or weaponization logic for public hosts. The reproduction rig is included precisely because maintainers should be able to re-run every claim in this report.
