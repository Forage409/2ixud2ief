# i2pd 2.61.0 Independent Security Audit — Deliverables

**Baseline:** release tag 2.61.0 (commit 635b013a) — pinned to deployment reality (Docker `latest`, Debian 13, Ubuntu 24.04/25.04, OpenWrt, Alpine all ship ≤ 2.61.0)
**Date:** 2026-09-20 · **Disclosure:** coordinated, 90-day embargo

## Contents

| Path | What it is |
|---|---|
| `report/i2pd-security-audit-2026-09.pdf` | Full audit report (18 pp, English) |
| `report/i2pd-security-audit-2026-09.md` | Same report in Markdown |
| `disclosure/disclosure-letter-en.txt` | Ready-to-submit GitHub Security Advisory draft |
| `摘要-zh.md` | Plain-language Chinese summary |
| `poc/vuln-01-ssu2-relayrequest-heapoverflow/` | **Critical** — SSU2 heap overflow: one-click `poc_b5.py`, evil-peer patch kit, lab script |
| `poc/vuln-02-ntcp2-m3p2-nullderef/` | **High** — NTCP2 NULL deref: `poc_ntcp2.py` + patch + lab script |
| `poc/vuln-03-ecies-handlepayload-oob/` | **Medium** — ECIES OOB read: `poc_c2.py` + C++ source |
| `poc/vuln-04-leaseset2-verifysig-underflow/` | **Low-Med** — LS2 heap underflow: `poc_ls2.py` + 108-byte minimized input |
| `poc/vuln-05-webconsole-unauth/` | **Medium (design)** — unauth shutdown demo: `demo_webconsole.py` |
| `poc/vuln-06-routerinfo-update-oob/` | **Low (latent)** — `poc_c1.py` + C++ source |
| `poc/fuzzing-harnesses/` | 3 libFuzzer harnesses + seed corpus + build script |
| `evidence/` | Raw crash logs (ASan/glibc), captured pages, official Docker binary |

## Quick start (reproduce the critical finding)

```bash
# Prereq: audit environment at /home/z/my-project/audit with builds/{asan,evil}/i2pd
python3 poc/vuln-01-ssu2-relayrequest-heapoverflow/poc_b5.py asan
# → expect: "复现成功 — VULN-01 SSU2 远程堆溢出 (越界写 2600 字节...)"
```

All victim binaries are built from the pristine 2.61.0 tag; attacker-side modifications
live only in the evil-peer build (`evil_patches.py` / `evil_ntcp2_patch.py`).

## Affected version matrix (summary)

| Finding | First affected | Last affected | Fixed on dev |
|---|---|---|---|
| VULN-01 | 2.43.0 (2022-07) | **2.61.0** | 67404cd8 (unreleased) |
| VULN-02 | 2.55.0 (2024-12) | **dev HEAD** | — |
| VULN-03 | 2.30.0 (2020-01) | 2.61.0 | 575acd6f (unreleased) |
| VULN-04 | ≤2.61.0 | **dev HEAD** | — |
| VULN-05 | n/a (image design) | current | — |
| VULN-06 | ≤2.61.0 | dev HEAD | — |
