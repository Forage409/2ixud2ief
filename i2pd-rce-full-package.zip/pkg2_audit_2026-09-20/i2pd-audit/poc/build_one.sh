#!/bin/bash
# 用法: build_one.sh <flavor>  — 可重入，已编译的 .o 自动续用
source /home/z/my-project/audit/env.sh
flavor=$1
if [ ! -d $BUILDS/$flavor/libi2pd ]; then
  cp -r $REPO $BUILDS/$flavor
fi
cd $BUILDS/$flavor
case $flavor in
  pristine)
    make -j2 USE_UPNP=no CXX=clang++ LDFLAGS="-L$BOOST_LIBRARYDIR" ;;
  asan)
    make -j2 USE_UPNP=no CXX=clang++ \
      CXXFLAGS="-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer -fno-optimize-sibling-calls" \
      LDFLAGS="-L$BOOST_LIBRARYDIR -fsanitize=address,undefined" ;;
  distro)
    make -j2 USE_UPNP=no CXX=clang++ \
      CXXFLAGS="-g -O2 -fPIE -fstack-protector-strong -Wformat -Werror=format-security -fcf-protection -D_FORTIFY_SOURCE=2" \
      LDFLAGS="-L$BOOST_LIBRARYDIR -pie -Wl,-z,relro -Wl,-z,now" ;;
esac
echo "BUILD-EXIT: $?"
ls -la i2pd 2>/dev/null
