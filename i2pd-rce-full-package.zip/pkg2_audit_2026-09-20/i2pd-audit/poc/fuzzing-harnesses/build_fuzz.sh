#!/bin/bash
# 构建 fuzz harness + 生成种子 + 运行 libFuzzer 短跑
source /home/z/my-project/audit/env.sh
FUZZ=/home/z/my-project/audit/fuzz
cd $FUZZ/harnesses

# ---- 编译三个 harness (asan 档 libi2pd + fuzzer 插桩的 harness 本体) ----
for h in routerinfo leaseset2 http; do
  clang++ -g -O1 -std=c++20 -fsanitize=address,fuzzer-no-link -fno-omit-frame-pointer \
    -I$BUILDS/asan/libi2pd -I$BUILDS/asan/libi2pd_client \
    fuzz_$h.cpp $BUILDS/asan/libi2pd.a $BUILDS/asan/libi2pdlang.a \
    -L$BOOST_LIBRARYDIR -lssl -lcrypto -lz -lboost_program_options -lpthread -latomic \
    -fsanitize=fuzzer -o $FUZZ/fuzz_$h 2>&1 | rg "error" | head -3
  echo "[$h] built: $(ls -la $FUZZ/fuzz_$h 2>/dev/null | awk '{print $5}')"
done

# ---- 种子: 靶场真实 RI + 合成边界样本 ----
mkdir -p $FUZZ/seeds/ri $FUZZ/seeds/ls $FUZZ/seeds/http
# 真实 RouterInfo 文件 (合法对端产生的真实数据)
for f in $BUILDS/lab-b5-asan/target/router.info $BUILDS/lab-b5-asan/evil/router.info \
         $BUILDS/lab-b5-pristine/target/router.info $BUILDS/lab-ntcp2-asan/target/router.info \
         $BUILDS/lab-ntcp2-asan/evil/router.info; do
  [ -f "$f" ] && cp "$f" $FUZZ/seeds/ri/$(basename $(dirname $(dirname $f)))-$(basename $f)-$(md5sum "$f" | cut -c1-6).ri
done
python3 - << 'PYEOF'
import struct, os
d = '/home/z/my-project/audit/fuzz/seeds/ri'
# 边界畸变种子: 截断/长度字段畸变
if os.listdir(d):
    base = open(sorted(os.listdir(d) and [os.path.join(d,f) for f in os.listdir(d)][0])[0] if False else os.path.join(d, os.listdir(d)[0]), 'rb').read()
    open(os.path.join(d, 'trunc-half.ri'), 'wb').write(base[:len(base)//2])
    open(os.path.join(d, 'trunc-50.ri'), 'wb').write(base[:50])
    open(os.path.join(d, 'numaddr-255.ri'), 'wb').write(base[:391+8] + b'\xff' + base[400:])
    open(os.path.join(d, 'ts-zero.ri'), 'wb').write(base[:391] + b'\x00'*8 + base[399:])
# LS2 最小合成种子 (storeType 1: LS2)
ls_dir = '/home/z/my-project/audit/fuzz/seeds/ls'
# header: flags(1) + publishTs(8) + expires(8) + numLeases(1) + lease(44)*n + props
ls2 = b'\x00' + struct.pack('>Q', 1789000000) + struct.pack('>Q', 1789900000) + b'\x01' + b'\x11'*44 + b'\x00\x00'
open(os.path.join(ls_dir, 'min-ls2.bin'), 'wb').write(ls2)
open(os.path.join(ls_dir, 'zero-lease.bin'), 'wb').write(ls2[:17] + b'\x00'*4)
open(os.path.join(ls_dir, 'trunc.bin'), 'wb').write(ls2[:10])
# MetaLS2 / Encrypted 变体头
open(os.path.join(ls_dir, 'meta.bin'), 'wb').write(b'\x00' + struct.pack('>Q',1789000000) + struct.pack('>H',10) + b'A'*8)
open(os.path.join(ls_dir, 'enc.bin'), 'wb').write(b'\x01' + b'\x22'*32 + b'\x00'*40)
# HTTP 种子
h = '/home/z/my-project/audit/fuzz/seeds/http'
open(os.path.join(h,'get.txt'),'wb').write(b"GET / HTTP/1.1\r\nHost: localhost\r\nUser-Agent: curl/8\r\nAccept: */*\r\n\r\n")
open(os.path.join(h,'proxy.txt'),'wb').write(b"GET http://i2p-projekt.i2p/ HTTP/1.1\r\nHost: i2p-projekt.i2p\r\n\r\n")
open(os.path.join(h,'resp.txt'),'wb').write(b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\nTransfer-Encoding: chunked\r\n\r\n3\r\nabc\r\n0\r\n\r\n")
open(os.path.join(h,'helper.txt'),'wb').write(b"GET /?i2paddresshelper=abc HTTP/1.1\r\nHost: x\r\n\r\n")
print("seeds ready:", len(os.listdir(d)), len(os.listdir(ls_dir)), len(os.listdir(h)))
PYEOF
echo "SEEDS-READY"
