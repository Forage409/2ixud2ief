// Fuzz harness: i2pd HTTP 解析 (webconsole/HTTPProxy/AddressBook 订阅共用)
#include "HTTP.h"
#include "Log.h"
#include <cstddef>
#include <cstdint>
#include <string>

static bool g_init = false;

extern "C" int LLVMFuzzerTestOneInput (const uint8_t * data, size_t size)
{
	if (!g_init)
	{
		i2p::log::Logger().SetLogLevel ("none");
		g_init = true;
	}
	if (size < 1 || size > 65536) return 0;
	try
	{
		std::string s ((const char *)data, size);
		i2p::http::HTTPReq req;
		req.parse (s);
		i2p::http::URL url;
		url.parse (s);
		i2p::http::HTTPRes res;
		res.parse (s);
	}
	catch (...) { }
	return 0;
}
