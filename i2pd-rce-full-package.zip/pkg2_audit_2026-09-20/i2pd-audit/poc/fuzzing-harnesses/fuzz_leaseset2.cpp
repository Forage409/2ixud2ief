// Fuzz harness: i2pd LeaseSet2 解析 (floodfill 存储/查找必达)
#include "LeaseSet.h"
#include "Identity.h"
#include "Crypto.h"
#include "Log.h"
#include <cstddef>
#include <cstdint>
#include <memory>

static bool g_init = false;

extern "C" int LLVMFuzzerTestOneInput (const uint8_t * data, size_t size)
{
	if (!g_init)
	{
		i2p::log::Logger().SetLogLevel ("none");
		i2p::crypto::InitCrypto (false);
		g_init = true;
	}
	if (size < 10 || size > 4096) return 0;
	try
	{
		for (int storeType = 1; storeType <= 7; storeType++) // LS2 类型 1..7, 3=MetaLS2 5=Encrypted
		{
			i2p::data::LeaseSet2 ls ((uint8_t)storeType, data, size, false, nullptr);
			volatile bool b = ls.IsExpired ();
			(void)b;
		}
	}
	catch (...) { }
	return 0;
}
