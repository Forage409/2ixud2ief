// Fuzz harness: i2pd RouterInfo 解析 (NetDb/floodfill 必达路径)
// LLVMFuzzerTestOneInput: bytes -> RouterInfo(buf, len) + Update 路径
#include "RouterInfo.h"
#include "Identity.h"
#include "Crypto.h"
#include "Log.h"
#include "I2PEndian.h"
#include <cstddef>
#include <cstdint>
#include <memory>

static bool g_init = false;
static std::shared_ptr<i2p::data::RouterInfo> g_ri;

extern "C" int LLVMFuzzerTestOneInput (const uint8_t * data, size_t size)
{
	if (!g_init)
	{
		i2p::log::Logger().SetLogLevel ("none");
		i2p::crypto::InitCrypto (false);
		g_init = true;
	}
	if (size < 40 || size > i2p::data::MAX_RI_BUFFER_SIZE) return 0;
	try
	{
		auto ri = std::make_shared<i2p::data::RouterInfo> (data, size);
		// 模拟 NetDb::AddRouterInfo 的更新路径 (C1 所在路径)
		if (g_ri && ri)
		{
			if (g_ri->GetIdentHash () == ri->GetIdentHash () && g_ri->IsNewer (data, size))
				g_ri->Update (data, size);
		}
		else
			g_ri = ri;
		// 访问解析产物以阻止死代码消除
		volatile bool b = ri->IsUnreachable ();
		volatile auto a = ri->GetAddresses ();
		(void)b; (void)a;
	}
	catch (...) { }
	return 0;
}
