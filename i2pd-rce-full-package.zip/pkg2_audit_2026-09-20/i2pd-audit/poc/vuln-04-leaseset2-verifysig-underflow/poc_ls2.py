#!/usr/bin/env python3
"""
VULN-04 PoC — i2pd LeaseSet2::VerifySignature 1 字节堆下溢读写 (fuzzer 发现)
漏洞: libi2pd/LeaseSet.cpp:393 (2.61.0)  buf[-1] 假设 "buf 在 DatabaseStore 消息内" 不总成立
用法: python3 poc_ls2.py   (需要 /home/z/my-project/audit/fuzz/fuzz_leaseset2 与最小化样本)
判定: ASan heap-buffer-overflow READ 1 byte, 位于 N-byte region 前 1 字节 → 复现成功
说明: 生产调用点当前均传 I2NP 池缓冲(假设成立), 属潜在缺陷/防御纵深; 公有构造函数直调即触发
"""
import os, sys, subprocess

FUZZ = '/home/z/my-project/audit/fuzz'
REPRO = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ls2-min-crash-input')

def main():
    fz = f'{FUZZ}/fuzz_leaseset2'
    inp = REPRO if os.path.exists(REPRO) else f'{FUZZ}/findings/ls2-min'
    for f in [fz, inp]:
        assert os.path.exists(f), f'缺少 {f}'
    env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1')
    r = subprocess.run([fz, inp], capture_output=True, text=True, env=env, timeout=120)
    out = r.stdout + r.stderr
    hit = 'heap-buffer-overflow' in out and 'bytes before' in out
    print(out[:1500])
    if hit:
        print('\n[+] 复现成功 — VULN-04 LeaseSet2 VerifySignature 堆下溢 (读写各 1 字节, 写入值为 storeType)')
        return 0
    print('\n[-] 未复现')
    return 1

if __name__ == '__main__':
    sys.exit(main())
