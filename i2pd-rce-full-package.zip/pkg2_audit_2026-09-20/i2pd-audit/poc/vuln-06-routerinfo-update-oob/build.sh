#!/bin/bash
# PoC-C1 构建脚本 — 链接 asan 档 libi2pd
source /home/z/my-project/audit/env.sh
cd /home/z/my-project/audit/poc/c1_update_oob
clang++ -g -O1 -std=c++20 -fsanitize=address,undefined -fno-omit-frame-pointer \
  -I$BUILDS/asan/libi2pd -I$BUILDS/asan/libi2pd_client \
  poc_c1.cpp \
  $BUILDS/asan/libi2pd.a $BUILDS/asan/libi2pdlang.a \
  -L$BOOST_LIBRARYDIR -lssl -lcrypto -lz -lboost_program_options -lpthread -latomic \
  -o poc_c1 2>&1 | head -20
echo "BUILD: $?"
