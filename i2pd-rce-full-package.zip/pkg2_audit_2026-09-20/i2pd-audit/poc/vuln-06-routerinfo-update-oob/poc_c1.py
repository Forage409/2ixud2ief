#!/usr/bin/env python3
"""
VULN-06 PoC — i2pd RouterInfo::Update 负长度 OOB 读 (单元级, 潜在缺陷)
漏洞: libi2pd/RouterInfo.cpp:95 (2.61.0)  int l = len - sigLen 无负数检查
用法: python3 poc_c1.py   (首次自动编译)
判定: ASan 报告 Verify 对越界内存做哈希 → 复现成功
定级说明(诚实): 远程路径被 IsNewer 长度下限(≥identityLen+8≈399)与 RSA 插入拒绝双重门控,
  非签名长度≤132 无法同时满足两关 → 当前网络路径不可达, 报告为潜在缺陷
"""
import os, sys, subprocess
os.environ['PATH'] = '/home/z/my-project/audit/tools/usr/usr/lib/llvm-19/bin:/home/z/.venv/bin:' + os.environ.get('PATH','')

DIR = os.path.dirname(os.path.abspath(__file__))
AUDIT = '/home/z/my-project/audit'
BUILDS = f'{AUDIT}/builds'
SRC = os.path.join(DIR, 'poc_c1.cpp')

BUILD_CMD = ('clang++ -g -O1 -std=c++20 -fsanitize=address,undefined -fno-omit-frame-pointer '
    f'-I{BUILDS}/asan/libi2pd -I{BUILDS}/asan/libi2pd_client {SRC} '
    f'{BUILDS}/asan/libi2pd.a {BUILDS}/asan/libi2pdlang.a '
    f'-L{AUDIT}/tools/usr/usr/lib/x86_64-linux-gnu -lssl -lcrypto -lz '
    '-lboost_program_options -lpthread -latomic -o poc_c1')

def main():
    binp = os.path.join(DIR, 'poc_c1')
    if not os.path.exists(binp) or os.path.getmtime(SRC) > os.path.getmtime(binp):
        print('[*] 编译 PoC...')
        r = subprocess.run(BUILD_CMD, shell=True, capture_output=True, text=True, cwd=DIR)
        if r.returncode != 0:
            print(r.stdout[-1200:] + r.stderr[-1200:]); sys.exit(2)
    env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1:symbolize=1')
    r = subprocess.run([binp], capture_output=True, text=True, env=env, timeout=60)
    out = r.stdout + r.stderr
    print(out[:1400])
    if 'ERROR: AddressSanitizer' in out:
        print('\n[+] 复现成功 — VULN-06 RouterInfo::Update 越界读 (代码级缺陷实锤, 远程被门控)')
        return 0
    print('\n[-] 未复现')
    return 1

if __name__ == '__main__':
    sys.exit(main())
