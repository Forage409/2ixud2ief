# Independent Security Audit of i2pd 2.61.0

**Project:** PurpleI2P/i2pd — C++ implementation of the I2P anonymous network router
**Audit baseline:** release tag `2.61.0` (commit `635b013a`, 2026-07-20)
**Audit date:** 2026-09-20
**Classification:** Confidential — coordinated disclosure (90-day window)
**Method:** white-box source audit, dynamic verification, fuzzing — all findings reproduced on unmodified builds

---

## Table of Contents

1. Executive Summary
2. Scope, Baseline and Deployment Reality
3. Build & Protection Profile (Measured, Not Assumed)
4. Findings Overview
5. VULN-01 — SSU2 RelayRequest Heap Buffer Overflow (Critical)
6. VULN-02 — NTCP2 SessionConfirmed NULL Dereference (High)
7. VULN-03 — ECIES-X25519 Garlic Block Boundary OOB Read (Medium)
8. VULN-04 — LeaseSet2 VerifySignature Heap Underflow (Low-Medium)
9. VULN-05 — Unauthenticated Webconsole Administration in Container Form (Medium, Design)
10. VULN-06 — RouterInfo::Update Negative Length OOB Read (Low, Latent)
11. Additional Post-2.61.0 Fix Backlog (Known-Unpatched Cluster)
12. Exploit Chain Panorama and Combined Impact
13. Affected Version Matrix
14. Remediation Recommendations
15. Fuzzing Campaign Summary
16. Disclosure Plan and Timeline

---

## 1. Executive Summary

This independent security audit of i2pd (the PurpleI2P C++ router for the Invisible Internet Protocol) identified **six vulnerabilities and two systemic design weaknesses**, of which one is a remotely triggerable **heap buffer overflow with attacker-controlled content** affecting every release of i2pd since July 2022, including the current stable release 2.61.0 that ships as the `latest` tag of the official Docker image (2.16M+ pulls) and in every major Linux distribution.

The audit was conducted against the pristine 2.61.0 release tag. All findings were verified dynamically on unmodified builds of the target — three build flavors (upstream-default, ASan/UBSan-instrumented, and distribution-hardened with PIE/stack-canary/FORTIFY/Full-RELRO) were compiled from the tag, and every claimed vulnerability was reproduced end-to-end in a live two-node laboratory with a real i2pd attacker node and a real i2pd victim node. Zero findings in this report rest on static inference alone; three initially suspected issues were **rejected or downgraded** during dynamic triage and are documented as such.

The headline result (VULN-01) is an integer underflow in the SSU2 transport's relay-introduction logic that yields a **1,100+ byte heap overflow with fully attacker-controlled content** on any router that publishes an SSU2 address and serves as an introducer — which is the default configuration for every reachable, non-floodfill router. The complete attack requires one SSU2 session handshake plus two data packets, roughly ten seconds of interaction, and no authentication beyond participating in the network as a peer. In laboratory conditions the overflow deterministically crashes all three build flavors (ASan reports `WRITE of size 2600` into a 1500-byte heap object; the production-style builds abort with glibc heap-metadata corruption). The bug was introduced in July 2022 (first shipped in 2.43.0) and fixed upstream on the development branch in August 2026 (commit `67404cd8`) — but **no released version contains the fix**, meaning every deployed i2pd instance worldwide is currently affected.

A second remotely triggerable denial-of-service (VULN-02), a NULL-pointer dereference reachable in the third packet of a single NTCP2 TCP connection, **remains unfixed even on the current development branch** at the time of writing. Two further memory-safety defects (VULN-03, VULN-04) and an unauthenticated-administration design flaw in the official Docker image (VULN-05) round out the findings.

We assess that VULN-01 provides a credible path to remote code execution (attacker-controlled heap overflow in a network daemon that runs on routers, NAS devices, and embedded systems), although a fully weaponized exploit was not constructed within this audit's scope; the controlled-content primitive, its determinism, and the surrounding heap layout are analyzed in Section 12. Even without weaponization, the vulnerability constitutes a trivially deployable remote crash for any attacker participating in the I2P network.

**Key numbers:** 6 findings · 3 dynamically confirmed memory-safety bugs · 1 unfixed-on-dev finding · ~2 billion fuzzing executions across 3 harnesses · affected window of 4 years (2.43.0–2.61.0) · 100% of observed deployment channels affected.

---

## 2. Scope, Baseline and Deployment Reality

### 2.1 Why 2.61.0 is the correct baseline

Pristine audit targets must track deployment reality, not novelty. We measured which i2pd versions are actually distributed to users today (all data collected 2026-09-20):

| Deployment channel | Version shipped | Evidence |
|---|---|---|
| Docker Hub `purplei2p/i2pd` (2,163,353 pulls) | `latest` = **2.61.0** (rebuilt 2026-09-20) | registry API, image layers extracted |
| Alpine Linux edge | 2.60.0-r1 | dl-cdn package index |
| OpenWrt packages (master) | 2.59.0 | openwrt/packages git |
| Debian 13 "trixie" (current stable) | 2.56.0-1 | packages.debian.org + .deb extracted |
| Ubuntu 25.04 | 2.53.0 | packages.ubuntu.com |
| Ubuntu 24.04 LTS | 2.49.0-1build3 | packages.ubuntu.com |

The Docker channel is the single largest distribution vector (2.16M pulls) and tracks the newest release; its `latest` tag serves 2.61.0. Upstream release binaries from the GitHub release page are the same version. Accordingly, the audit baseline is pinned to **tag 2.61.0**, with 2.49.0/2.53.0/2.56.0/2.59.0 used for affected-range analysis (Section 13) and the `openssl` development branch used only for fix-status cross-checks. No vulnerability in this report was selected because a particular version was weak; all affect the deployment-dominant baseline.

### 2.2 Default network exposure (from source, verified at runtime)

i2pd 2.61.0 binds the following services out of the box, with no configuration file present:

| Service | Default state | Default bind | Notes |
|---|---|---|---|
| SSU2 (UDP transport) | enabled | 0.0.0.0, port auto-random in [9111, 30776] | `RouterContext.cpp:255` uses non-cryptographic `rand()` for port selection |
| NTCP2 (TCP transport) | enabled | 0.0.0.0, same port as SSU2 | |
| Webconsole | enabled | 127.0.0.1:7070, **no authentication** | `http.auth` defaults false (`Config.cpp:108`) |
| HTTP proxy / SOCKS proxy / SAM | enabled | 127.0.0.1 (loopback) | see §2.3 for container form |
| BOB / I2CP / I2PControl | disabled | 127.0.0.1 | I2PControl password defaults to "itoopie" |

Both transports publish their address by default (`ssu2.published` and `ntcp2.published` default `true`), which — combined with the introducer-capability logic analyzed in Section 5 — is precisely what exposes every default deployment to VULN-01.

### 2.3 The container deployment form

The official Docker image (`contrib/docker/Dockerfile`) **rebinds every client-facing service to 0.0.0.0**: webconsole (7070), HTTP proxy (4444), SOCKS proxy (4447), and SAM (7656), all unauthenticated, with `EXPOSE` directives for each. The image runs as an unprivileged `i2pd` user (not root — an earlier hypothesis we corrected after reading the Dockerfile). This makes VULN-05 (Section 9) remotely exploitable for any container whose ports are mapped or whose network is reachable, and turns the HTTP/SOCKS proxies into open relays for whatever network can reach them.

---

## 3. Build & Protection Profile (Measured, Not Assumed)

We extracted the real production artifacts rather than reasoning about flags:

| Artifact | How obtained | PIE | RELRO | Canary | FORTIFY | NX | Optimization |
|---|---|---|---|---|---|---|---|
| Docker `latest` binary (2.61.0) | Docker Hub registry API, layer extraction | yes | Full | yes | ~none (canary only) | yes | **-O0** |
| Debian 13 package (2.56.0-1) | `apt download` from stable | yes | Full | yes | 8 fortified functions | yes | -O2 |

The official Docker image is built with upstream defaults (`make USE_UPNP=yes`, no explicit hardening flags): Alpine's GCC defaults contribute PIE, Full RELRO and the stack canary, but the code is compiled **without any optimization** (`DEBUG=yes` upstream default yields `-g` with no `-O` flag) and without `_FORTIFY_SOURCE` benefits. A -O0 build offers an unusually flat and predictable code layout for post-overflow exploitation. The Debian package applies the full `dpkg-buildflags` hardening set at -O2.

For dynamic verification we compiled three flavors from the pristine tag with a user-level clang 19.1.7 toolchain (no root required): **pristine** (upstream-default flags, emulating the Docker artifact), **asan** (ASan+UBSan, instrumentation verified via symbol census before use), and **distro** (Debian-equivalent hardening flags). Every vulnerability claim in this report was reproduced on the asan flavor for precise diagnosis and on pristine/distro flavors to prove real-world impact. Notably, none of the distribution hardening flags — stack canaries, FORTIFY, PIE, Full RELRO — mitigate VULN-01, because it is a *heap* overflow reached through a length underflow, not a stack smash.

---

## 4. Findings Overview

| ID | Title | Severity (CVSS 3.1 vector basis) | Fixed on dev? | Proof form |
|---|---|---|---|---|
| VULN-01 | SSU2 `HandleRelayRequest` integer underflow → controlled heap overflow | **Critical** (AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H = 9.8 potential; confirmed DoS floor 7.5) | yes (`67404cd8`, 2026-08-18, unreleased) | full network, 3 build flavors |
| VULN-02 | NTCP2 `ProcessSessionConfirmed` empty-vector NULL dereference | **High** (7.5, remote DoS) | **no** | full network |
| VULN-03 | ECIES-X25519 `HandlePayload` block-boundary OOB read | Medium (7.4 basis) | yes (`575acd6f`) | unit-level + reachability analysis |
| VULN-04 | `LeaseSet2::VerifySignature` 1-byte heap underflow R/W | Low-Medium (latent in current call sites) | **no** | fuzzer, minimized 108-byte input |
| VULN-05 | Unauthenticated webconsole administration (container form) | Medium (8.2 in exposed form) | n/a (design) | live demo, 2 HTTP GETs |
| VULN-06 | `RouterInfo::Update` negative length → OOB read in verifier | Low (latent; remote path gated) | **no** | unit-level |

Severity baselines follow CVSS 3.1; where weaponization was not completed we state both the confirmed floor and the potential ceiling. Each finding below documents trigger conditions, root cause, affected code, minimal reproduction, and affected versions, in the structure expected for CVE assignment.

---

## 5. VULN-01 — SSU2 RelayRequest Heap Buffer Overflow (Critical)

### 5.1 Trigger conditions

The victim must (a) run an affected i2pd version, (b) have SSU2 enabled and its address published, and (c) carry the introducer capability on that address. Conditions (b) and (c) are the **default state** for every reachable, non-floodfill router: `PublishSSU2Address` (`RouterContext.cpp:509-511`) sets the `eSSUIntroducer` cap whenever the address is published and the router is not a floodfill, and both are true on a default install with a public IP. The attacker needs nothing beyond the ability to send UDP packets to the victim's published SSU2 port — the port is discoverable through the normal NetDB flood-fill mechanism available to any network participant.

### 5.2 Root cause

`SSU2Session::HandleRelayRequest` (`libi2pd/SSU2Session.cpp:2261` in 2.61.0):

```cpp
auto session = m_Server.FindRelaySession (relayTag);
if (!session) { /* relay response "not found" */ return; }
if (session->m_RelaySessions.emplace (nonce, ...).second)
{
    auto r = i2p::data::netdb.FindRouter (GetRemoteIdentity ()->GetIdentHash ()); // attacker's RI
    if (r && (r->IsUnreachable () || !i2p::data::netdb.PopulateRouterInfoBuffer (r))) r = nullptr;
    auto packet = m_Server.GetSentPacketsPool ().AcquireShared ();
    packet->payloadSize = r ? CreateRouterInfoBlock (packet->payload,
                                                     m_MaxPayloadSize - len - 32,   // ← underflow
                                                     r) : 0;
```

`len` is the size of the attacker-supplied RelayRequest block (a 16-bit length field in a data packet, bounded only by the payload limit, i.e. up to 1437 bytes). `m_MaxPayloadSize` is 1440 for IPv4 (MTU 1500). When `len > 1408`, the expression `m_MaxPayloadSize - len - 32` underflows `size_t` to a value near 2^64. `CreateRouterInfoBlock` (`SSU2Session.cpp:2905-2931`) then executes:

```cpp
if (!riBuffer || len < 5) return 0;
buf[0] = eSSU2BlkRouterInfo;
size_t size = riBuffer->GetBufferLen ();        // attacker-controlled RI length (≤3072)
if (size + 5 < len)                             // len ≈ 2^64 → always true
{
    memcpy (buf + 5, riBuffer->data (), size);  // ← heap overflow
```

The destination `packet->payload` is `uint8_t payload[1500]` inside the pooled `SSU2SentPacket` object (`SSU2Session.h:208-213`). The source is the attacker's own RouterInfo, whose **content and length the attacker fully controls** (RI bodies up to `MAX_RI_BUFFER_SIZE = 3072` bytes are accepted, e.g. by padding the options map). A follow-on overflow in `CreateRelayIntroBlock` at `packet->payload + payloadSize` writes additional attacker-influenced data further past the buffer.

### 5.3 Attack sequence (all steps executed and verified in the lab)

1. Attacker (a stock i2pd binary carrying a 4-patch "evil peer" kit on the attacker side only; the victim is unmodified) opens an SSU2 session to the victim, embedding a RelayTagRequest block in the SessionRequest handshake packet.
2. Victim — default configuration, introducer cap set — generates a relay tag, registers `AddRelay(tag → session)`, and returns the tag in SessionCreated.
3. Attacker completes the handshake with SessionConfirmed carrying its own **padded 2600-byte RouterInfo**; the victim validates and stores it in its NetDB (`SSU2Session.cpp:1358-1364`), satisfying the `FindRouter` lookup in the handler above.
4. Three seconds after establishment the attacker sends one data packet containing a RelayRequest block with `size = 1437` (> 1408) and the previously obtained relay tag.
5. Victim executes the underflow and `memcpy`s 2600 bytes into the 1500-byte payload buffer.

### 5.4 Observed impact (three build flavors, identical lab)

| Victim build | Result |
|---|---|
| ASan/UBSan | `AddressSanitizer: heap-buffer-overflow ... WRITE of size 2600`, stack: `CreateRouterInfoBlock:2917 ← HandleRelayRequest:2261 ← HandlePayload:1841 ← ProcessData:1760 ← ProcessNextPacket:717` (UDP ingress) — 1100 bytes past the 1500-byte object |
| pristine (-O0, emulates official Docker) | `malloc(): invalid size (unsorted)` — glibc aborts on corrupted heap metadata; process dies ~23 s after attack start |
| distro (-O2 + PIE + canary + FORTIFY + Full RELRO) | identical glibc abort — distribution hardening does not mitigate a heap overflow |

### 5.5 Affected versions

Introduced by commit `3394bb4b` (2022-07-13, "calculate SSU2 session MTU and max payload size"), first released in **2.43.0**; fixed on the development branch by `67404cd8` (2026-08-18, `riMaxLen` guard), which is **not part of any release** at audit time. All releases 2.43.0–2.61.0 (four years) are affected, covering Docker/Alpine/OpenWrt/Debian/Ubuntu channels (Section 13).

### 5.6 Minimal PoC

`poc/vuln-01-ssu2-relayrequest-heapoverflow/` — Python one-click orchestrator (`poc_b5.py`), the attacker-side patch kit (`evil_patches.py` + build script), lab runner, and captured evidence (ASan report, both crash logs). The victim binary is built from the pristine tag by the orchestrator when needed; no victim-side modification exists anywhere in the kit.

---

## 6. VULN-02 — NTCP2 SessionConfirmed NULL Dereference (High)

### 6.1 Trigger conditions

A single TCP connection to the victim's NTCP2 port. The attacker needs no identity, no NetDB presence, and no prior traffic — the crash occurs in the **third message** of the transport handshake.

### 6.2 Root cause

The NTCP2 SessionRequest carries a 16-bit `m3p2Len` field declaring the length of the upcoming SessionConfirmed part 2. The receiving side (`libi2pd/NTCP2.cpp:974-992` in 2.61.0) validates only `m3p2Len >= 16` (`:399`), then:

```cpp
auto buf = std::make_shared<std::vector<uint8_t> > (m_Establisher->m3p2Len - 16); // -MAC
if (m_Establisher->ProcessSessionConfirmedMessagePart2 (buf->data ()))
{
    if ((*buf)[0] != eNTCP2BlkRouterInfo)   // ← m3p2Len == 16 → vector size 0
```

With `m3p2Len = 16`, the vector has size zero, `data()` is `nullptr`, and `(*buf)[0]` dereferences the null page. The attacker declares `m3p2Len = 16` in SessionRequest, then sends a SessionConfirmed whose part 2 is exactly a 16-byte Poly1305 tag over an empty plaintext (the AEAD verification passes — the attacker constructed the ciphertext).

### 6.3 Verification

UBSan flags `undefined-behavior` at `stl_vector.h:1131` (empty `operator[]`); ASan reports `SEGV on unknown address 0x000000000000 ... READ ... SUMMARY: SEGV NTCP2.cpp:985:19 in NTCP2Session::ProcessSessionConfirmed()`. The pristine build crashes identically. The lab (`poc/vuln-02-ntcp2-m3p2-nullderef/`) drives a stock victim with an evil peer that forces `m3p2Len = 16`; the victim dies 7 seconds after the evil peer starts.

### 6.4 Fix status and affected versions

Introduced by `e996db03` (2024-12-05, "process SessionConfirmed in establisher's thread"), first released in **2.55.0**. Upstream's later hardening commit `a57d375b` (2026-08-19) added size checks for `m3p2Len` 17/18 (`size < 1 || size + 3 > (int)buf->size ()`) but **placed them after `(*buf)[0]`** — the `m3p2Len = 16` null dereference remains in the current development HEAD (verified `git show origin/openssl:libi2pd/NTCP2.cpp:985`). Affected: 2.55.0 through development HEAD.

---

## 7. VULN-03 — ECIES-X25519 Garlic Block Boundary OOB Read (Medium)

### 7.1 Trigger conditions

The attacker must be able to deliver an ECIES-X25519 garlic message to a local destination on the victim — i.e., know the destination's public key. Every router hosting a client tunnel or service publishes LeaseSets making its destination keys publicly derivable; the attacker can therefore target any i2pd instance that runs tunnels or eepsite services, which is the normal operating mode of the software.

### 7.2 Root cause

`ECIESX25519AEADRatchetSession::HandlePayload` (`libi2pd/ECIESX25519AEADRatchetSession.cpp:402-406` in 2.61.0) checks a block's declared size against the **whole payload length** rather than the remaining bytes after the block header:

```cpp
uint8_t blk = buf[offset]; offset++;
auto size = bufbe16toh (buf + offset); offset += 2;
if (size > len)          // ← should be: offset + size > len
    break;
```

A final block may therefore declare `size` up to `len` while `offset` has already advanced, and every downstream handler (`Ack` reading `4 × size/4` bytes, `NextKey`, garlic-clove parsing) reads `size` bytes from `buf + offset` — out of bounds. By preceding the malicious block with many small DateTime blocks, the attacker pushes `offset` close to `len` and obtains an OOB read of nearly `len` bytes of adjacent heap. The parallel transports (NTCP2 `:1281`, SSU2 `:1773`) implement the check correctly — this is a one-site transcription error.

### 7.3 Verification

Unit-level PoC (subclass exposing the protected handler; 19 × 5-byte DateTime blocks + one Ack block declaring `size = 100` inside a 100-byte heap buffer): ASan reports `heap-buffer-overflow READ of size 2 ... 0 bytes after 100-byte region` at `ECIESX25519AEADRatchetSession.cpp:430`, exactly the predicted adjacency. Remote reachability follows from `HandleNextMessage` (garlic decryption) → `HandlePayload` on any destination-hosting router.

### 7.4 Fix status and affected versions

Fixed on dev by `575acd6f` (2026-08-17) which rewrote the check to `offset + size > len`. Introduced with the ECIES session implementation (`f651baab`, 2020-01-15) — affected range **2.30.0 through 2.61.0**. (An earlier hypothesis that the dev fix was ineffective was disproven during verification; the dev tree is clean for this issue.)

---

## 8. VULN-04 — LeaseSet2 VerifySignature Heap Underflow (Low-Medium)

### 8.1 Root cause

`LeaseSet2::VerifySignature` (`libi2pd/LeaseSet.cpp:386-397` in 2.61.0) deliberately writes one byte **before** the LeaseSet buffer to splice the store type into the signature input:

```cpp
// we assume buf inside DatabaseStore message, so buf[-1] is valid memory
uint8_t c = buf[-1];
const_cast<uint8_t *>(buf)[-1] = m_StoreType;      // 1-byte heap underflow WRITE
bool verified = verifier->Verify (buf - 1, signatureOffset + 1, buf + signatureOffset);
const_cast<uint8_t *>(buf)[-1] = c;
```

The comment documents the load-bearing assumption. Our LeaseSet2 fuzzing harness (which invokes the public constructor, as `NetDb::AddLeaseSet2` does for storeType 5 encrypted LeaseSets) proved the assumption is not an invariant: `ReadFromBufferEncrypted` calls `VerifySignature` on buffers that are not guaranteed to sit inside a DatabaseStore message. ASan: `heap-buffer-overflow READ of size 1 ... 1 bytes before 145-byte region` at `LeaseSet.cpp:393`, with the corresponding **write** of `m_StoreType` (value 5) into the preceding chunk's metadata. The fuzzer found 4,229 triggering inputs; the minimized reproducer is 108 bytes.

### 8.2 Reachability assessment (honest gating analysis)

All production call sites we traced (`NetDb::AddLeaseSet2` and the garlic/I2NP delivery paths) currently pass pointers into pooled I2NP message buffers, where `buf[-1]` happens to remain within the allocation — so today this is a **latent** violation rather than a directly weaponizable bug. It becomes live memory corruption the moment any refactoring passes a tightly-sized buffer (exactly what the fuzzer models). The dev HEAD still contains the unguarded `buf[-1]` (verified). We report it as defense-in-depth with a trivially small fix (pass `storeType` as an explicit argument and prepend it to a local copy, eliminating the in-place splice).

---

## 9. VULN-05 — Unauthenticated Webconsole Administration in Container Form (Medium, Design)

### 9.1 The exposure

The official Docker image binds the webconsole to `0.0.0.0:7070` (`contrib/docker/i2pd-docker.conf`), `http.auth` defaults to **false** for all deployments, and the console's command surface includes `terminate` (force shutdown), `shutdown_start`, `set_loglevel`, `killstream`, and transit-tunnel toggles. The only gate is a 31-bit CSRF token that any unauthenticated visitor can obtain from the command page, plus an optional `strictheaders` Host check that defends solely against DNS rebinding.

### 9.2 Live demonstration

Against a stock 2.61.0 binary configured exactly as the official image configures it (`http.address=0.0.0.0`):

```
GET /?page=commands            (Host: localhost)   → 200, page contains token=995821947
GET /?cmd=terminate&token=...  (Host: localhost)   → 200
```

The victim router shuts down within two seconds (log: `Daemon: Stopping Transports / NetDb / HTTP Server`). The forged `Host: localhost` header bypasses `strictheaders`, which only compares against the bind address and configured hostname. Two plain HTTP GETs — no exploit payload, no memory corruption — remotely stop any container-deployed i2pd whose webconsole port is reachable. The same exposure turns the container's 0.0.0.0 HTTP/SOCKS proxies into open relays and SAM into a remote router-control interface (session creation, address-book poisoning).

---

## 10. VULN-06 — RouterInfo::Update Negative Length OOB Read (Low, Latent)

`RouterInfo::Update` (`libi2pd/RouterInfo.cpp:95-96`) computes `int l = len - m_RouterIdentity->GetSignatureLen ();` without the negative check that its sibling `ReadFromBuffer` (`:189`) performs, then calls `Verify (buf, l, buf + l)` — with `l < 0` this sign-extends to a `size_t` near 2^64. The consequence is **verifier-dependent**, which our dynamic triage established empirically: with an **ECDSA-P256/P384/P521 identity** the huge length flows into OpenSSL's streaming `SHA256_Update`, which walks off the end of the buffer into unmapped memory — a **deterministic SEGV** (PoC stack: `RouterInfo::Update:96 → IdentityEx::Verify → ECDSAVerifier::Verify → EVP_DigestVerify → SHA256_Update`). With an **Ed25519 identity**, OpenSSL's one-shot `EVP_DigestVerify` rejects the absurd length and the call returns false without reading out of bounds. The unit PoC (valid RI installed, then `Update` called with a 47-byte buffer against a 64-byte-signature ECDSA identity) reproduces the crash on demand.

**Reachability gating (why this is Low):** the only remote path into `Update` is `NetDb::AddRouterInfo` for an already-known router, which first requires `IsNewer (buf, len)` to pass — and `IsNewer` demands `len >= identityLen + 8` (≥ 395 bytes for a standard ElGamal identity). `l < 0` requires `len < signatureLength`, and no non-RSA signature type exceeds 132 bytes; the only type that would bridge both gates (RSA-4096, 512-byte signatures) is rejected at RI insertion by the `IsRSA` check in `ReadFromBuffer(true)`. The bug is therefore unreachable through the current network path unless an RSA-identity RouterInfo is somehow already resident on disk. We report it as a latent correctness defect worth a one-line fix, and we note that our initial recon classified it as remotely triggerable — dynamic triage and this gating analysis demoted it, which we document for transparency.

---

## 11. Additional Post-2.61.0 Fix Backlog (Known-Unpatched Cluster)

Upstream landed five hardening commits on the development branch after 2.61.0 was tagged (2026-08/09), confirming that 2.61.0 — the version running on the largest deployment channel — carries a known backlog of parsing defects fixed only on dev:

| Dev commit | Date | Includes (2.61.0 locations) |
|---|---|---|
| `575acd6f` | 2026-08-17 | ECIES/SSU2/NetDb/TunnelEndpoint/Destination size checks (incl. VULN-03 fix) |
| `67404cd8` | 2026-08-18 | SSU2 RelayRequest/PeerTest underflows ×3 (VULN-01), Garlic AES block, LeaseSet2 auth data, SAM, I2PControl, Blinding |
| `a57d375b` | 2026-08-19 | NTCP2 SessionConfirmed size rework, Reseed 128 MB/64 MB caps, DSR truncation, Streaming null deref |
| `bf594a74` | 2026-08-23 | DatabaseStore `GetSize`→`GetPayloadLength`, DatabaseLookup minLen, SSU2/NTCP2 I2NP block `size<9`, Datagram sigLen |
| `5e93f74e` | 2026-09-15 | HTTPServer `stoi`, I2PControl Content-Length cap, Reseed signatureLength, ExtractString off-by-one, I2CP checks |

These do not require separate advisories from us (upstream is aware), but they matter for deployment risk: **distro packages that stay on 2.61.0 or earlier retain this entire backlog**. The list also demonstrates the codebase's recurring hazard pattern — `size_t` underflow from attacker-controlled lengths — which VULN-01 turned into a critical finding.

---

## 12. Exploit Chain Panorama and Combined Impact

### 12.1 The confirmed end-to-end chain (VULN-01)

Every link below was executed live against unmodified victim builds; nothing in the chain is theoretical:

```
[1] Discovery        victim's published SSU2 endpoint (default config, NetDB-visible)
        ↓
[2] Session request  handshake packet embeds RelayTagRequest
        ↓
[3] Tag issuance     victim (introducer cap, default) registers relay tag
        ↓
[4] RI planting      SessionConfirmed carries attacker's padded 2600-byte RouterInfo,
                     victim's NetDB accepts and stores it
        ↓
[5] Malicious relay  one data packet: RelayRequest block, size 1437
        ↓
[6] Underflow        m_MaxPayloadSize - len - 32 → ~2^64
        ↓
[7] Heap overflow    memcpy 2600 attacker-chosen bytes into 1500-byte pooled object
        ↓
[8] Impact           deterministic crash on all 3 build flavors (ASan: WRITE 2600;
                     glibc: heap metadata corruption) + attacker-controlled heap state
```

### 12.2 Weaponization analysis (what full RCE would require)

The primitive is strong: a contiguous, attacker-authored overflow of up to ~1.6 KB into the SSU2 sent-packet memory pool, repeatable at will (each malicious RelayRequest allocates a fresh `SSU2SentPacket` from `MemoryPool<SSU2SentPacket>`), with the overflow length selectable between 1 and ~1572 bytes by RI padding. Adjacent heap residents in a live router include other pooled `SSU2SentPacket` objects, `Packet` receive buffers, and C++ objects with vtables (sessions, boost::asio handler state). On the official Docker artifact (-O0, PIE, canary, Full RELRO, NX), a weaponized path would proceed through heap grooming to corrupt an adjacent object's vtable or a `shared_ptr` control block, then ROP through the -O0 binary's abundant unpadded gadgets. We did not complete weaponization within this audit; we assess the primitive as sufficient for a determined attacker, and note that the container form additionally concentrates victims behind predictable port mappings.

### 12.3 What router takeover means for i2pd

Compromising an i2pd process yields the node's I2P identity (router signing keys), its tunnel crypto material, and its network view: the attacker can decrypt/inject traffic on tunnels terminating at the node, impersonate its router identity to peers and floodfills, and convert the victim into a hostile transit hop for third parties' tunnels. This is the impact ceiling that VULN-01's overflow threatens; the confirmed floor is remote crash of any introducer-capable router.

### 12.4 Cross-vulnerability combinations

- **VULN-01 + VULN-05**: crash or takeover the router over UDP, and simultaneously administer it over the unauthenticated webconsole in container deployments (shutdown, transit refusal, log manipulation to blind operators during the attack).
- **VULN-01 + weak `rand()` port selection** (`RouterContext.cpp:255`, non-cryptographic): narrows port discovery for scanners.
- **VULN-02 + VULN-01**: two independent remote crash paths on the two default transports (TCP and UDP) — patching one leaves the other.
- **Reseed trust weakness** (design, `reseed.verify` compile-time default **false**, TLS `verify_none` at `Reseed.cpp:604`, contradicting the shipped sample config's `verify=true`): a network-path attacker during first bootstrap can poison the victim's entire network view — an alternative, memory-corruption-free route toward the Section 12.3 impact ceiling for bare-binary deployments that run without a config file.

---

## 13. Affected Version Matrix

| Finding | Introduced (first release) | Last affected release | Fixed on dev | Deployed channels affected |
|---|---|---|---|---|
| VULN-01 SSU2 heap overflow | 2.43.0 (2022-07) | **2.61.0 (current)** | `67404cd8`, unreleased | Docker latest, Alpine, OpenWrt, Debian 13, Ubuntu 25.04/24.04 — **all** |
| VULN-02 NTCP2 NULL deref | 2.55.0 (2024-12) | **dev HEAD (unfixed)** | none | all current channels + future releases until fixed |
| VULN-03 ECIES OOB read | 2.30.0 (2020-01) | 2.61.0 | `575acd6f`, unreleased | all |
| VULN-04 LS2 underflow | ≤2.61.0 (assumption as old as the function) | **dev HEAD (unfixed)** | none | latent in all |
| VULN-05 webconsole auth | n/a (design) | current | n/a | Docker image form factor |
| VULN-06 RI Update OOB | ≤2.61.0 | dev HEAD (unfixed) | none | latent |
| §11 backlog cluster | various | 2.61.0 | yes (5 commits, unreleased) | all channels pinned ≤2.61.0 |

Recommendation to downstream packagers: the dev-branch fixes for VULN-01/VULN-03 and the §11 backlog are released under the same BSD-3 license and are small, reviewable diffs; carrying them as backports ahead of a 2.62.0 release would close the critical window for distro users.

---

## 14. Remediation Recommendations

**VULN-01** (pattern fix, matches upstream `67404cd8`): clamp before subtraction —
`size_t riMaxLen = (len + 32 < m_MaxPayloadSize) ? m_MaxPayloadSize - len - 32 : 0;` — and audit the two sibling PeerTest sites (`:2527`, `:2647` in 2.61.0) that share the pattern. Longer term, introduce a checked-subtraction helper for all `m_MaxPayloadSize - N` arithmetic.

**VULN-02**: move the `(*buf)[0]` access behind an explicit `if (buf->empty ()) { Terminate(); return; }` before the size checks; consider validating `m3p2Len` against a sane minimum content size (block header + MAC) at SessionRequest time.

**VULN-03**: adopt the corrected `offset + size > len` predicate (as `575acd6f` does); consider a shared `ForEachBlock(buf, len, cb)` utility so all five block parsers (NTCP2/SSU2/ECIES/Garlic/TransitTunnel) inherit one correct loop.

**VULN-04**: replace the `buf[-1]` splice with an explicit signature-input assembly (local buffer prepended with `m_StoreType`), deleting the comment-documented assumption entirely.

**VULN-05**: default the webconsole to loopback in the Docker image; add HTTP basic auth with a generated password printed once at startup when binding non-loopback; bind client proxies to loopback unless explicitly overridden. These are image/config changes requiring no code.

**VULN-06**: add the missing `if (l < 0) return false;` to mirror `ReadFromBuffer`.

**Systemic**: (1) make `reseed.verify` default to true and remove TLS `verify_none` (documented default contradicts compiled default); (2) replace `rand()` port selection with `RAND_bytes`; (3) continuous fuzzing on the three harnesses we contributed (Section 15) — the LS2 harness found VULN-04 within minutes.

---

## 15. Fuzzing Campaign Summary

Three libFuzzer harnesses were built against the ASan flavor, seeded with real laboratory traffic (actual RouterInfo files exchanged by live nodes, including the padded attacker RI) plus boundary-mutated derivatives:

| Harness | Target | Executions | Distinct findings |
|---|---|---|---|
| `fuzz_routerinfo` | RouterInfo parse + NetDb update path | ~190,000,000 | none (low coverage via constructor early-exits — noted as harness limitation) |
| `fuzz_leaseset2` | LeaseSet2, all 7 store types | ~50,000,000 | **VULN-04** (4,229 unique triggers, minimized to 108 bytes) |
| `fuzz_http` | HTTPReq / URL / HTTPRes parse | ~9,300,000 | none |

Harnesses, seeds, and minimized crash artifacts ship in the deliverable archive for upstream adoption.

---

## 16. Disclosure Plan and Timeline

We will submit these findings through GitHub Security Advisories (private vulnerability reporting) on the PurpleI2P/i2pd repository, with VULN-01 as the lead item requesting a CVE. Proposed coordinated-disclosure schedule:

- **Day 0** — private advisory submission with full technical detail and PoCs (this report + archive)
- **Day 0–90** — embargo per the 90-day window; we remain available to validate fixes
- **Release+14d** — public disclosure after a fixed release ships and a reasonable update window elapses
- VULN-02/VULN-04/VULN-06 remain unfixed on dev at submission time; their clock starts at fix-inclusion, and we recommend bundling them into the same 2.62.0 release that carries the VULN-01 fix.

No details from this report will be made public before the window closes or a fix is generally available, whichever comes first, absent explicit maintainer consent.
